# Installation and Production Guide
### Khalil Noor Kashemul Uloom Noorani KG Madrasa Management System

This document outlines the detailed system architecture, production-ready directory layouts, installation configurations, database setup steps, and security guidelines to deploy this software effectively.

---

## 1. System Folder Structure

The application follows a modular, high-cohesion layout separating client rendering, system interfaces, and persistent server models.

```text
khalil-noor-madrasha/
│
├── .env.example             # Environment variable declarations (API credentials, app urls)
├── package.json             # Runtime execution scripts, node services, building pipelines
├── schema.sql               # Full, ANSI-compliant MySQL database creation structure 
├── server.ts                # Express full-stack proxy controller and data routing APIs
├── tsconfig.json            # Strict TypeScript compilation guidelines
├── vite.config.ts           # React transpilation and bundling instructions
│
├── data/
│   ├── db.json              # Active file-persistent JSON database fallback for prototyping
│   └── installation.md      # This complete staging configuration reference
│
├── src/
│   ├── main.tsx             # DOM injection entrypoint
│   ├── App.tsx              # Main system routing container
│   ├── index.css            # Micro-animations, Bangla fonts, Glassmorphic utility layers
│   │
│   ├── types.ts             # Strict, absolute system interfaces
│   │
│   └── components/
│       ├── Header.tsx       # Sticky dynamic layout containing auth buttons and navigation links
│       ├── Footer.tsx       # Core footer containing contacts, map locator reference
│       ├── Hero.tsx         # Banner system featuring stats, soft logo animations
│       ├── Objectives.tsx   # "উদ্দেশ্য ও উপদেশ" rich editable details
│       ├── StudentSection.tsx # Digital student lists, filters, roster directories
│       ├── TeacherSection.tsx # Faculty profiles, educational qualifications, contacts
│       ├── ReportSection.tsx # Analytical grids, exam performance report queries, PDF/Print
│       ├── LibrarySection.tsx # Multi-category inventory systems with custom lending cards
│       ├── AdmissionSection.tsx # Admission form with gated mobile payment step-flows (bKash/Nagad)
│       ├── GallerySection.tsx # Instant grid gallery containing item categorization and previews
│       ├── ContactSection.tsx # Message inbox submissions, direct dials, locations
│       ├── AuthModal.tsx    # Multi-factor authentication dialog panels
│       └── Dashboard.tsx    # Multi-Role Dashboard layouts (Admin, Teacher, Student, Guardian)
```

---

## 2. Production Stack Deployment (PHP + MySQL)

For running this applet as a standard PHP school application, utilize the structured SQL database in `schema.sql` paired with an Apache or Nginx server.

### Step 1: Database Setup
1. Open your hosting panel (such as cPanel, DirectAdmin, or local XAMPP phpMyAdmin).
2. Create a new SQL client database named `madrasha_db`.
3. Select the `Import` tab, choose the `schema.sql` file provided in the project root, and click **Import / Go**.
4. This instantly prepares all 14 structured tables (`users`, `students`, `teachers`, `attendance`, `reports`, `admissions`, etc.), builds relations, indexes primary indices for high-volume searching, and seals standard credentials.

### Step 2: Connection Configuration (PHP API Proxy)
Prepare a central DB controller config (e.g., `db_connect.php`) to link the interface forms:

```php
<?php
// db_connect.php
$servername = "localhost";
$username = "your_db_username";
$password = "your_db_password";
$dbname = "madrasha_db";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Database Connection Failed: " . $e->getMessage());
}
?>
```

### Step 3: Deployment of Static Client Files
1. Run `npm run build` locally to trigger full code transpilation.
2. The compiler places all ready-to-serve index files, script codes, animations, and icons into the `/dist` bundle.
3. Move `/dist` content directly to your target directory on your public web server (`/public_html` or `/var/www/html`).

---

## 3. Node Full-Stack Live Stack (Docker/Cloud Run Environment)

If deploying the system as a Node.js full-stack platform, it automatically utilizes the reactive API controllers and persistence.

### Running Local Development
```bash
# Install core dependencies
npm install

# Start high-speed server and runtime client hotloading
npm run dev
```

### Production Build compilation
Execute the integrated bundler pipeline:
```bash
npm run build
```
This triggers **Vite UI assets assembly** and compiles the Express proxy `server.ts` into a unified ESM-compliant `dist/server.cjs` file, ready to deploy inside Docker containers on port `3000`.

---

## 4. Operational Safety and Security Rule-Set

1. **SQL Injection Protection**: The system abstracts all database records using strict parameter binding and structured TypeScript APIs. If deploying PHP replicas, **always** employ PDO Prepared Statements with dynamic placeholders.
2. **Strict Admin Panel Gate**: Access is hard-encrypted to:
   - **Admin Email**: `khalilenurmadrasha65@gmail.com`
   Any access containing non-admin parameters is automatically directed to the Student/Guardian/Teacher console.
3. **Password Security**: For production registries, utilize strong hashing layers (such as **BCrypt** with salt workfactors $\ge 10$) to preserve student data.
