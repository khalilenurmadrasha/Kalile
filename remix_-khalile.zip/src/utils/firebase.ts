import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { 
  getFirestore, doc, getDocFromServer, getDoc, getDocs, setDoc, 
  collection, query, where, addDoc, updateDoc, deleteDoc, onSnapshot, orderBy 
} from "firebase/firestore";
import firebaseConfig from "../../firebase-applet-config.json";

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth();

// Test Connection on load
async function testConnection() {
  try {
    await getDocFromServer(doc(db, "settings", "config"));
    console.log("Firebase connection established successfully!");
  } catch (error) {
    if (error instanceof Error && error.message.includes("client is offline")) {
      console.warn("Please check your Firebase configuration or network connectivity.");
    } else {
      console.warn("Firebase test connection warning:", error);
    }
  }
}
testConnection();

// Operation Types
export enum OperationType {
  CREATE = "create",
  UPDATE = "update",
  DELETE = "delete",
  LIST = "list",
  GET = "get",
  WRITE = "write",
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

// Error Handler conformant to SKILL.md
export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error("Firestore Error Detailed: ", JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Firestore operations wraps with error handlers
export const firebaseAPI = {
  async getSettings() {
    try {
      const snap = await getDoc(doc(db, "settings", "config"));
      if (snap.exists()) return snap.data();
      return null;
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, "settings/config");
    }
  },

  async saveSettings(data: any) {
    try {
      await setDoc(doc(db, "settings", "config"), data, { merge: true });
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, "settings/config");
    }
  },

  async getCollection(collName: string) {
    try {
      const q = query(collection(db, collName));
      const snap = await getDocs(q);
      return snap.docs.map(d => ({ id: d.id, ...d.data() }));
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, collName);
    }
  },

  async createDoc(collName: string, id: string, data: any) {
    try {
      await setDoc(doc(db, collName, id), { ...data, id });
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `${collName}/${id}`);
    }
  },

  async deleteDoc(collName: string, id: string) {
    try {
      await deleteDoc(doc(db, collName, id));
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `${collName}/${id}`);
    }
  },

  async updateDoc(collName: string, id: string, data: any) {
    try {
      await updateDoc(doc(db, collName, id), data);
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `${collName}/${id}`);
    }
  }
};
