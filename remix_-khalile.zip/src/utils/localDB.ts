import { 
  Teacher, Student, LibraryBook, Notice, GalleryItem, 
  AdmissionForm, ExamResult, AttendanceRecord, SystemSettings, ContactMessage 
} from "../types";

export const DEFAULT_SETTINGS: SystemSettings = {
  websiteName: "Khalil Noor Kashemul Uloom Noorani KG Madrasa",
  banglaName: "খলিলে নূর কাশেমুল উলুম নূরানী কেজি মাদ্রাসা",
  address: "ঢেমুশিয়া, বাজারপাড়া, চকরিয়া, কক্সবাজার",
  email: "khalilenurmadrasha65@gmail.com",
  phone: "01812345678",
  introduction: "খলিলে নূর কাশেমুল উলুম নূরানী কেজি মাদ্রাসা কক্সবাজার জেলার চকরিয়া উপজেলার ঢেমুশিয়া ইউনিয়নে অবস্থিত একটি স্বনামধন্য দ্বীনি ও আধুনিক শিক্ষাপ্রতিষ্ঠান। এখানে অভিজ্ঞ শিক্ষক মণ্ডলী দ্বারা নূরানী পদ্ধতিতে শিশুদের কুরআন ও কেজি কারিকুলামে জেনারেল শিক্ষা প্রদান করা হয়।",
  targetMissions: [
    "কুরআন মাজীদ সহীহ-শুদ্ধভাবে তেলাওয়াত ও হিফজ করার যোগ্যতা অর্জন করানো।",
    "আধুনিক জেনারেল শিক্ষার সমন্বয়ে শিক্ষার্থীদের আদর্শ সুনাগরিক হিসেবে গড়ে তোলা।",
    "শিশুদের নৈতিকতা ও উন্নত ইসলামী চরিত্র গঠনে সর্বোচ্চ জোর দেওয়া।"
  ],
  islamicEducation: "আমাদের মাদ্রাসায় নূরানী তালীমুল কুরআন বোর্ডের নিয়মে শিশুদের তাজবীদ সহকারে কুরআন তেলাওয়াত, মাসনুন দোয়া, আকাইদ ও ফিকাহ শিক্ষা অত্যন্ত যত্নের সাথে দেওয়া হয়ে থাকে।",
  moralEducation: "জেনারেল শিক্ষার পাশাপাশি আদব-কায়দা, মা-বাবার প্রতি দায়িত্ব, সত্যবাদিতা এবং ইসলামি আদর্শ অনুশীলনের মাধ্যমে শিক্ষার্থীদের সুপ্ত প্রতিভা ও মানবিক গুণাবলীর বিকাশ ঘটানো হয়।",
  advices: "প্রিয় দ্বীনি অভিভাবকবৃন্দ, আপনার স্নেহের সন্তানকে দ্বীনি ও আধুনিক পরিবেশের সমন্বয়ে গড়ে তুলতে আজই যোগাযোগ করুন। তাদের উজ্জ্বল ভবিষ্যৎ বিনির্মাণে আমাদের পাশে থাকুন।",
  showLiveClock: true,
  liveClockFormat: "12hour",
  showDate: true,
  dateFormat: "both",
  primaryAccentColor: "#059669",
  secondaryAccentColor: "#d97706",
  fontFamily: "noto-bengali",
  fontSizeLevel: "medium",
  premiumStyleMode: "glass",
  headingWeight: "bold"
};

export const INITIAL_TEACHERS: Teacher[] = [
  {
    id: "t_1",
    name: "মাওলানা হাফেজ মোঃ ছিদ্দিকুল্লাহ",
    designation: "মুহতামিম / প্রধান শিক্ষক",
    qualification: "কামিল (হাদীস), হাফেজ-এ-কুরআন",
    phone: "01823456781",
    biography: "মাদ্রাসার সার্বিক উন্নয়নে দ্বীনি নিষ্ঠার সাথে দায়িত্ব পালন করছেন।",
    email: "mohammad.siddik@gmail.com",
    photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200"
  },
  {
    id: "t_2",
    name: "হাফেজ মোঃ আব্দুল হাই",
    designation: "সহকারী শিক্ষক (নূরানী বিভাগ)",
    qualification: "ফাযিল, নূরানী প্রশিক্ষণপ্রাপ্ত",
    phone: "01823456782",
    biography: "নূরানী পদ্ধতিতে শিশুদের পরম যত্ন সহকারে প্রাথমিক দ্বীনি শিক্ষা দান করেন।",
    email: "abdul.hai@gmail.com",
    photo: "https://images.unsplash.com/photo-1628157582853-a796fa650a6a?auto=format&fit=crop&q=80&w=200"
  },
  {
    id: "t_3",
    name: "জনাব মেহেরুন্নেসা লাকী",
    designation: "শিক্ষিকা (কেজি ও জেনারেল বিভাগ)",
    qualification: "বি.এ (সম্মান), বি.এড",
    phone: "01823456783",
    biography: "বাংলা, ইংরেজি এবং গণিত বিষয়াবলি আধুনিক উপায়ে চমৎকারভাবে পড়ান।",
    email: "meherun.lucky@gmail.com",
    photo: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200"
  }
];

export const INITIAL_STUDENTS: Student[] = [
  {
    id: "s_1",
    photo: "https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=150",
    name: "মোঃ সাজ্জাদ হোসাইন কায়সার",
    roll: "১০১",
    class: "Play",
    session: "২০২৬",
    guardianName: "মোঃ জুনাইদ",
    guardianPhone: "01711112221",
    address: "বাজারপাড়া, ঢেমুশিয়া, চকরিয়া, কক্সবাজার",
    gender: "Male",
    dob: "২০২০-০২-১৫"
  },
  {
    id: "s_2",
    photo: "https://images.unsplash.com/photo-1518887570146-0612132dd618?auto=format&fit=crop&q=80&w=150",
    name: "ফাতেমা আরিশা জেরিন",
    roll: "১০২",
    class: "Nursery",
    session: "২০২৬",
    guardianName: "মোঃ নুরুল আমিন",
    guardianPhone: "01711112222",
    address: "पश्चिम ढेमुरिया, चक्रिया",
    gender: "Female",
    dob: "২০১৯-০৫-২০"
  },
  {
    id: "s_3",
    photo: "https://images.unsplash.com/photo-1503919545889-aef636e10ad4?auto=format&fit=crop&q=80&w=150",
    name: "মোঃ মোস্তফা কামাল",
    roll: "২০১",
    class: "First",
    session: "২০২৬",
    guardianName: "মোঃ কামাল উদ্দিন",
    guardianPhone: "01711112223",
    address: "বাজারপাড়া, চকরিয়া",
    gender: "Male",
    dob: "২০১৮-০৯-০৫"
  },
  {
    id: "s_4",
    photo: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?auto=format&fit=crop&q=80&w=150",
    name: "আয়েশা সিদ্দিকা তানিয়া",
    roll: "৩০১",
    class: "Second",
    session: "২০২৬",
    guardianName: "হাফেজ মোঃ ইউনুস",
    guardianPhone: "01711112224",
    address: "ঢেমুশিয়া চিলখালী, চকরিয়া",
    gender: "Female",
    dob: "২০১৭-১২-১২"
  }
];

export const INITIAL_BOOKS: LibraryBook[] = [
  { id: "b_1", bookName: "সহজ নূরানী কায়দা", author: "মাওলানা ক্বারী বেলায়েত হোসাইন", category: "কুরআন মাজীদ", class: "Play", availability: true, totalQuantity: 50, borrowedQuantity: 12, coverPhoto: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=120" },
  { id: "b_2", bookName: "এসো আরবী শিখি", author: "মাওলানা আবু তাহের মেসবাহ", category: "আরবি", class: "First", availability: true, totalQuantity: 30, borrowedQuantity: 6, coverPhoto: "https://images.unsplash.com/photo-1513001900722-370f803f498d?auto=format&fit=crop&q=80&w=120" },
  { id: "b_3", bookName: "আমার বাংলা বই - প্রথম শ্রেণী", author: "এনসিটিবি", category: "বাংলা", class: "First", availability: true, totalQuantity: 40, borrowedQuantity: 5, coverPhoto: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&q=80&w=120" },
  { id: "b_4", bookName: "প্রাথমিক গণিত - দ্বিতীয় শ্রেণী", author: "এনসিটিবি", category: "গণিত", class: "Second", availability: true, totalQuantity: 35, borrowedQuantity: 2, coverPhoto: "https://images.unsplash.com/photo-1596495578065-6e0763fa1141?auto=format&fit=crop&q=80&w=120" },
  { id: "b_5", bookName: "ইসলামিক শিশু শিক্ষা খাতা ও ডাস্টার সেট", author: "মাদ্রাসা প্রকাশনা", category: "খাতা", class: "Play", availability: true, totalQuantity: 100, borrowedQuantity: 0, coverPhoto: "https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&q=80&w=120" }
];

export const INITIAL_NOTICES: Notice[] = [
  {
    id: "n_1",
    title: "২০২৬ শিক্ষাবর্ষে নূরানী কেজি বিভাগে নতুন ভর্তি কার্যক্রম চলছে",
    content: "সম্মানিত অভিভাবক ও সুধী সমাজ, আমাদের খলিলে নূর কাশেমুল উলুম নূরানী কেজি মাদ্রাসায় প্লে, নার্সারী ও প্রথম থেকে তৃতীয় শ্রেণী পর্যন্ত সীমিত আসনে ছাত্র-ছাত্রী ভর্তি চলছে। বিস্তারিত তথ্যের জন্য যোগাযোগ করুন অথবা অনলাইন পোর্টালে আবেদন সম্পন্ন করুন। অনলাইন আবেদনের সময় বিকাশ/নগদ এর মাধ্যমে ফি পরিশোধ করা বাধ্যতামূলক।",
    date: "২০২৬-০৫-২৫",
    category: "Admission",
    important: true
  },
  {
    id: "n_2",
    title: "প্রথম সাময়িক পরীক্ষা গ্রহণের নোটিশ",
    content: "আগামী ১৫ই জুন ২০২৬ থেকে সকল শ্রেণীর প্রথম সাময়িক পরীক্ষা শুরু হতে যাচ্ছে। পরীক্ষার সিলেবাস ও সময়সূচী ইতিমধ্যে নোটিশ বোর্ডে ও শিক্ষার্থীদের ডায়েরীতে প্রদান করা হয়েছে। শিক্ষার্থীদের শতভাগ উপস্থিতি ও অভিভাবকদের নিবিড় তদারকি কামনা করছি।",
    date: "২০২৬-০৫-৩০",
    category: "Exam",
    important: true
  },
  {
    id: "n_3",
    title: "পবিত্র ঈদুল আযহা উপলক্ষে মাদ্রাসা বন্ধের ঘোষণা",
    content: "পবিত্র ঈদুল আযহা উপলক্ষে আগামী ৪ঠা জুন থেকে ১৪ই জুন ২০২৬ পর্যন্ত মাদ্রাসার সকল দ্বীনি ও কেজি শ্রেণীর পাঠদান বন্ধ থাকবে। ১৫ই জুন রোজ সোমবার থেকে নির্ধারিত সময়ে নিয়মিত ক্লাস ও পরীক্ষা আরম্ভ হবে।",
    date: "২০২৬-০৬-০১",
    category: "Holiday",
    important: false
  }
];

export const INITIAL_GALLERY: GalleryItem[] = [
  { id: "g_1", url: "https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&q=80&w=600", category: "Campus", title: "মাদ্রাসার মনোরম দ্বীনি পরিবেশ", date: "২০২৬-০১-১৫" },
  { id: "g_2", url: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=600", category: "Classroom", title: "নূরানী পদ্ধতিতে শিশুদের ক্লাস গ্রহণ", date: "২০২৬-০২-১০" },
  { id: "g_3", url: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&q=80&w=600", category: "Event", title: "বাৎসরিক ইসলামিক কুইজ প্রতিযোগিতা", date: "২০২৬-৩-০৫" },
  { id: "g_4", url: "https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&q=80&w=600", category: "Sports", title: "শিক্ষার্থীদের ইসলামিক খেলাধুলা", date: "২০২৬-০৩-২০" }
];

export const INITIAL_ADMISSIONS: AdmissionForm[] = [
  {
    id: "adm_1",
    studentName: "মোঃ আরাফাত সিদ্দিক",
    fatherName: "মোঃ সালাহউদ্দিন",
    motherName: "বিলকিস বেগম",
    dob: "২০২১-০৪-১২",
    class: "Play",
    gender: "Male",
    phone: "01819876543",
    address: "বাজারপাড়া, ঢেমুশিয়া",
    photoUrl: "https://images.unsplash.com/photo-1503919545889-aef636e10ad4?auto=format&fit=crop&q=80&w=150",
    paymentMethod: "bKash",
    transactionId: "BKX987HFE2",
    amount: 1200,
    paymentStatus: "Verified",
    submissionDate: "২০২৬-০৫-২৮"
  }
];

export const INITIAL_EXAM_RESULTS: ExamResult[] = [
  {
    id: "r_1",
    studentId: "s_1",
    studentName: "মোঃ সাজ্জাদ হোসাইন কায়সার",
    roll: "১০১",
    class: "Play",
    term: "First Term",
    subjectGrades: { quran: 95, bangla: 88, english: 85, math: 92, arabic: 90, moral: 98 },
    totalMarks: 548,
    grade: "A+",
    gpa: 5.0,
    remarks: "চমৎকার ফলাফল। কুরআন পাঠে অত্যন্ত মনোযোগী।",
    createdAt: "২০২৬-০৫-২৫"
  },
  {
    id: "r_2",
    studentId: "s_3",
    studentName: "মোঃ মোস্তফা কামাল",
    roll: "২০১",
    class: "First",
    term: "First Term",
    subjectGrades: { quran: 88, bangla: 78, english: 80, math: 85, arabic: 84, moral: 90 },
    totalMarks: 505,
    grade: "A",
    gpa: 4.5,
    remarks: "খুব ভালো, হাতের লেখা আরও সুন্দর করা প্রয়োজন।",
    createdAt: "২০২৬-০৫-২৫"
  }
];

export const INITIAL_ATTENDANCE: AttendanceRecord[] = [
  { id: "att_1", studentId: "s_1", studentName: "মোঃ সাজ্জাদ হোসাইন কায়সার", roll: "১০১", class: "Play", date: "2026-06-01", status: "Present" },
  { id: "att_2", studentId: "s_2", studentName: "ফাতেমা আরিশা জেরিন", roll: "১০২", class: "Nursery", date: "2026-06-01", status: "Present" },
  { id: "att_3", studentId: "s_3", studentName: "মোঃ মোস্তফা কামাল", roll: "২০১", class: "First", date: "2026-06-01", status: "Absent" },
  { id: "att_4", studentId: "s_4", studentName: "আয়েশা সিদ্দিকা তানিয়া", roll: "৩০১", class: "Second", date: "2026-06-01", status: "Present" }
];

export const INITIAL_PAYMENTS = [
  { id: "p_1", studentName: "মোঃ আরাফাত সিদ্দিক", class: "Play", method: "bKash", txid: "BKX987HFE2", amount: 1200, type: "Admission Fee", date: "২০২৬-০৫-২৮", status: "Verified" },
  { id: "p_2", studentName: "মোঃ সাজ্জাদ হোসাইন কায়সার", class: "Play", method: "Nagad", txid: "NGD6652GFT", amount: 800, type: "Tuition Fee", date: "২০২৬-০৫-৩০", status: "Verified" }
];

export const INITIAL_CONTACT_MESSAGES: ContactMessage[] = [
  { id: "c_1", name: "মোহাম্মদ ইউসুফ", phone: "01824123412", message: "আসসালামু আলাইকুম, প্লে শ্রেণীর ক্লাস কি সকাল ৮টা থেকে শুরু হয়? অনুগ্রহ করে জানাবেন।", date: "২০২৬-০৫-৩১", read: false }
];

// Local state check helper
export function isStaticOrFailedEnv() {
  const isHostStatic = window.location.hostname.includes("netlify.app") || 
                       window.location.hostname.includes("github.io") || 
                       window.location.hostname.includes("web.app") || 
                       window.location.hostname.includes("firebaseapp.com");
  return isHostStatic || localStorage.getItem("use_local_storage_db") === "true";
}

export function forceLocalStorageDB() {
  localStorage.setItem("use_local_storage_db", "true");
}

// Initialise Database values inside LocalStorage if not existing
export function getLocalValue<T>(key: string, initialValue: T): T {
  const item = localStorage.getItem(`madrasha_db_${key}`);
  if (item === null) {
    localStorage.setItem(`madrasha_db_${key}`, JSON.stringify(initialValue));
    return initialValue;
  }
  try {
    return JSON.parse(item);
  } catch {
    return initialValue;
  }
}

export function setLocalValue<T>(key: string, value: T) {
  localStorage.setItem(`madrasha_db_${key}`, JSON.stringify(value));
}
