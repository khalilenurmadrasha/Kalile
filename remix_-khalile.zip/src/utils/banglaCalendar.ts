/**
 * Utility functions for Bengali digits, months, and Bangla Academy date calculations (বঙ্গাব্দ)
 */

export const convertToBanglaDigits = (numStr: string | number): string => {
  const banglaDigits = ["০", "১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯"];
  return String(numStr).replace(/[0-9]/g, (digit) => banglaDigits[parseInt(digit)]);
};

export const getBanglaDayName = (dayIndex: number): string => {
  const banglaDays = [
    "রবিবার",
    "সোমবার",
    "মঙ্গলবার",
    "বুধবার",
    "বৃহস্পতিবার",
    "শুক্রবার",
    "শনিবার"
  ];
  return banglaDays[dayIndex];
};

export const getBanglaMonthNameBytes = (monthIndex: number): string => {
  const banglaMonths = [
    "বৈশাখ",
    "জ্যৈষ্ঠ",
    "আষাঢ়",
    "শ্রাবণ",
    "ভাদ্র",
    "আশ্বিন",
    "কার্তিক",
    "অগ্রহায়ণ",
    "পৌষ",
    "মাঘ",
    "ফাল্গুন",
    "চৈত্র"
  ];
  return banglaMonths[monthIndex];
};

/**
 * Calculates Bengali Date based on Bangla Academy Revised Calendar
 * Year starts on 14 April (1 Boishakh).
 */
export const getBengaliDate = (date: Date): { day: number; month: string; year: number } => {
  const day = date.getDate();
  const month = date.getMonth(); // 0-indexed (0 is Jan, 11 is Dec)
  const year = date.getFullYear();

  let bDay = 1;
  let bMonth = "";
  let bYear = year - 593; // Bengali Era begins in 593/594 AD

  // Helper definition of month days in Bangla calendar
  // Boishakh to Bhadra are 31 days. Rest are 30 days. Falgun is 30 days (31 in leap year).
  const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);

  // Simple calendar mapping based on day-of-year or monthly transition dates
  // April 14 is 1st Boishakh
  if (month === 0) { // Jan
    if (day <= 18) {
      bDay = day + 12;
      bMonth = "পৌষ";
    } else {
      bDay = day - 18;
      bMonth = "মাঘ";
    }
    bYear = year - 594;
  } else if (month === 1) { // Feb
    if (day <= 18) {
      bDay = day + 13;
      bMonth = "মাঘ";
    } else {
      bDay = day - 18;
      bMonth = "ফাল্গুন";
    }
    bYear = year - 594;
  } else if (month === 2) { // Mar
    // Falgun ends on March 14 (Revised Bangla Academy)
    const limit = 14;
    if (day <= limit) {
      bDay = day + 15 + (isLeapYear ? 1 : 0);
      bMonth = "ফাল্গুন";
    } else {
      bDay = day - limit;
      bMonth = "চৈত্র";
    }
    bYear = year - 594;
  } else if (month === 3) { // Apr
    if (day <= 13) {
      bDay = day + 17;
      bMonth = "চৈত্র";
      bYear = year - 594;
    } else {
      bDay = day - 13;
      bMonth = "বৈশাখ";
      bYear = year - 593;
    }
  } else if (month === 4) { // May
    if (day <= 14) {
      bDay = day + 17;
      bMonth = "বৈশাখ";
    } else {
      bDay = day - 14;
      bMonth = "জ্যৈষ্ঠ";
    }
  } else if (month === 5) { // Jun
    if (day <= 15) {
      bDay = day + 17;
      bMonth = "জ্যৈষ্ঠ";
    } else {
      bDay = day - 15;
      bMonth = "আষাঢ়";
    }
  } else if (month === 6) { // Jul
    if (day <= 16) {
      bDay = day + 15;
      bMonth = "আষাঢ়";
    } else {
      bDay = day - 16;
      bMonth = "শ্রাবণ";
    }
  } else if (month === 7) { // Aug
    if (day <= 17) {
      bDay = day + 15;
      bMonth = "শ্রাবণ";
    } else {
      bDay = day - 17;
      bMonth = "ভাদ্র";
    }
  } else if (month === 8) { // Sep
    if (day <= 18) {
      bDay = day + 14;
      bMonth = "ভাদ্র";
    } else {
      bDay = day - 18;
      bMonth = "আশ্বিন";
    }
  } else if (month === 9) { // Oct
    if (day <= 19) {
      bDay = day + 12;
      bMonth = "আশ্বিন";
    } else {
      bDay = day - 19;
      bMonth = "কার্তিক";
    }
  } else if (month === 10) { // Nov
    if (day <= 19) {
      bDay = day + 11;
      bMonth = "কার্তিক";
    } else {
      bDay = day - 19;
      bMonth = "অগ্রহায়ণ";
    }
  } else if (month === 11) { // Dec
    if (day <= 19) {
      bDay = day + 11;
      bMonth = "অগ্রহায়ণ";
    } else {
      bDay = day - 19;
      bMonth = "পৌষ";
    }
  }

  return { day: bDay, month: bMonth, year: bYear };
};

/**
 * Formats time string in Bengali language
 */
export const formatTimeBangla = (date: Date): string => {
  let period = "রাত";
  const hours = date.getHours();
  const minutes = date.getMinutes();
  const seconds = date.getSeconds();

  if (hours >= 4 && hours < 6) period = "ভোর";
  else if (hours >= 6 && hours < 12) period = "সকাল";
  else if (hours >= 12 && hours < 16) period = "দুপুর";
  else if (hours >= 16 && hours < 18) period = "বিকাল";
  else if (hours >= 18 && hours < 20) period = "সন্ধ্যা";

  // convert to 12 hour value for displaying periods
  const displayHours = hours % 12 || 12;

  const minStr = String(minutes).padStart(2, "0");
  const secStr = String(seconds).padStart(2, "0");

  return `${period} ${convertToBanglaDigits(displayHours)} টা ${convertToBanglaDigits(minStr)} মিনিট ${convertToBanglaDigits(secStr)} সেকেন্ড`;
};
