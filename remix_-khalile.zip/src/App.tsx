import React, { useState, useEffect } from "react";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Hero from "./components/Hero";
import Objectives from "./components/Objectives";
import GallerySection from "./components/GallerySection";
import TeacherSection from "./components/TeacherSection";
import StudentSection from "./components/StudentSection";
import ReportSection from "./components/ReportSection";
import LibrarySection from "./components/LibrarySection";
import AdmissionSection from "./components/AdmissionSection";
import ContactSection from "./components/ContactSection";
import Dashboard from "./components/Dashboard";
import AuthModal from "./components/AuthModal";

import { 
  User, Teacher, Student, Notice, AttendanceRecord, ExamResult, 
  LibraryBook, AdmissionForm, SystemSettings, ContactMessage, GalleryItem
} from "./types";
import {
  isStaticOrFailedEnv, forceLocalStorageDB, getLocalValue, setLocalValue,
  DEFAULT_SETTINGS, INITIAL_TEACHERS, INITIAL_STUDENTS, INITIAL_BOOKS,
  INITIAL_NOTICES, INITIAL_GALLERY, INITIAL_ADMISSIONS, INITIAL_EXAM_RESULTS,
  INITIAL_ATTENDANCE, INITIAL_PAYMENTS, INITIAL_CONTACT_MESSAGES
} from "./utils/localDB";

function getContrastColor(hex: string) {
  if (!hex || hex.length < 6) return "#ffffff";
  const cleanHex = hex.replace("#", "");
  const r = parseInt(cleanHex.substring(0, 2), 16);
  const g = parseInt(cleanHex.substring(2, 4), 16);
  const b = parseInt(cleanHex.substring(4, 6), 16);
  const brightness = (r * 299 + g * 587 + b * 114) / 1000;
  return brightness > 140 ? "#0f172a" : "#ffffff";
}

export default function App() {
  const [currentTab, setTab] = useState<string>("home");
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem("theme") === "dark" || 
      (!("theme" in localStorage) && window.matchMedia("(prefers-color-scheme: dark)").matches);
  });

  // Global Data States
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [books, setBooks] = useState<LibraryBook[]>([]);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [admissions, setAdmissions] = useState<AdmissionForm[]>([]);
  const [results, setResults] = useState<ExamResult[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [contacts, setContacts] = useState<ContactMessage[]>([]);
  const [payments, setPayments] = useState<any[]>([]);
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  
  // App Settings Loaded from backend
  const [settings, setSettings] = useState<SystemSettings>({
    websiteName: "Khalil Noor Kashemul Uloom Noorani KG Madrasa",
    banglaName: "খলিলে নূর কাশেমুল উলুম নূরানী কেজি মাদ্রাসা",
    address: "ঢেমুশিয়া, বাজারপাড়া, চকরিয়া, কক্সবাজার",
    email: "khalilenurmadrasha65@gmail.com",
    phone: "01812345678",
    introduction: "খলিলে নূর কাশেমুল উলুম নূরানী কেজি মাদ্রাসা কক্সবাজার জেলার চকরিয়া উপজেলার...",
    targetMissions: [],
    islamicEducation: "",
    moralEducation: "",
    advices: "",
    showLiveClock: true,
    liveClockFormat: "12hour",
    showDate: true,
    dateFormat: "both"
  });

  // Auth States
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const cached = localStorage.getItem("currentUser");
    return cached ? JSON.parse(cached) : null;
  });
  
  const [authModal, setAuthModal] = useState<{ open: boolean; mode: "login" | "register" }>({
    open: false,
    mode: "login"
  });

  // Sync Themes
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  }, [darkMode]);

  // Read Core API Data on mount with robust client-side storage fallback
  const loadLocalStorageData = () => {
    setSettings(getLocalValue<SystemSettings>("settings", DEFAULT_SETTINGS));
    setTeachers(getLocalValue<Teacher[]>("teachers", INITIAL_TEACHERS));
    setStudents(getLocalValue<Student[]>("students", INITIAL_STUDENTS));
    setBooks(getLocalValue<LibraryBook[]>("books", INITIAL_BOOKS));
    setNotices(getLocalValue<Notice[]>("notices", INITIAL_NOTICES));
    setAdmissions(getLocalValue<AdmissionForm[]>("admissions", INITIAL_ADMISSIONS));
    setResults(getLocalValue<ExamResult[]>("results", INITIAL_EXAM_RESULTS));
    setAttendance(getLocalValue<AttendanceRecord[]>("attendance", INITIAL_ATTENDANCE));
    setPayments(getLocalValue<any[]>("payments", INITIAL_PAYMENTS));
    setContacts(getLocalValue<ContactMessage[]>("contacts", INITIAL_CONTACT_MESSAGES));
    setGallery(getLocalValue<GalleryItem[]>("gallery", INITIAL_GALLERY));
  };

  const fetchAllData = async () => {
    if (isStaticOrFailedEnv()) {
      console.log("Static/offline hosting environment detected. Initializing with localized micro-database.");
      loadLocalStorageData();
      return;
    }

    try {
      const fetchJson = async (url: string) => {
        const r = await fetch(url);
        const contentType = r.headers.get("content-type");
        if (!r.ok || !contentType || !contentType.includes("application/json")) {
          throw new Error(`Non-JSON or error response from ${url}`);
        }
        return r.json();
      };

      const [
        settingsRes, teachersRes, studentsRes, booksRes, 
        noticesRes, admissionsRes, resultsRes, attendanceRes, paymentsRes, contactsRes, galleryRes
      ] = await Promise.all([
        fetchJson("/api/settings"),
        fetchJson("/api/teachers"),
        fetchJson("/api/students"),
        fetchJson("/api/books"),
        fetchJson("/api/notices"),
        fetchJson("/api/admissions"),
        fetchJson("/api/results"),
        fetchJson("/api/attendance"),
        fetchJson("/api/payments"),
        fetchJson("/api/contacts"),
        fetchJson("/api/gallery")
      ]);

      setSettings(settingsRes);
      setTeachers(teachersRes);
      setStudents(studentsRes);
      setBooks(booksRes);
      setNotices(noticesRes);
      setAdmissions(admissionsRes);
      setResults(resultsRes);
      setAttendance(attendanceRes);
      setPayments(paymentsRes);
      setContacts(contactsRes);
      setGallery(galleryRes);

      // Save to localStorage for robust offline access
      setLocalValue("settings", settingsRes);
      setLocalValue("teachers", teachersRes);
      setLocalValue("students", studentsRes);
      setLocalValue("books", booksRes);
      setLocalValue("notices", noticesRes);
      setLocalValue("admissions", admissionsRes);
      setLocalValue("results", resultsRes);
      setLocalValue("attendance", attendanceRes);
      setLocalValue("payments", paymentsRes);
      setLocalValue("contacts", contactsRes);
      setLocalValue("gallery", galleryRes);
    } catch (err) {
      console.warn("Express API server offline/unreachable. Activating local client-side database layer:", err);
      forceLocalStorageDB();
      loadLocalStorageData();
    }
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  // Sync session caching
  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem("currentUser", JSON.stringify(user));
    setTab("dashboard");
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem("currentUser");
    setTab("home");
  };

  // REST API mutation proxies with robust fallback and double-write backup
  const handleAddNotice = async (noti: { title: string; content: string; category: string; important: boolean }) => {
    const backupNotice: Notice = {
      ...noti,
      category: noti.category as any,
      id: "n_" + Date.now(),
      date: new Date().toLocaleDateString("bn-BD", { year: "numeric", month: "long", day: "numeric" }).replace(/[\/\-]/g, " ")
    };

    if (isStaticOrFailedEnv()) {
      const updated = [backupNotice, ...notices];
      setNotices(updated);
      setLocalValue("notices", updated);
      return true;
    }

    try {
      const res = await fetch("/api/notices", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(noti)
      });
      const data = await res.json();
      if (data.success) {
        setNotices(prev => [data.notice, ...prev]);
        setLocalValue("notices", [data.notice, ...notices]);
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  const handleDeleteNotice = async (id: string) => {
    if (isStaticOrFailedEnv()) {
      const updated = notices.filter(n => n.id !== id);
      setNotices(updated);
      setLocalValue("notices", updated);
      return true;
    }

    try {
      const res = await fetch(`/api/notices/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        const updated = notices.filter(n => n.id !== id);
        setNotices(updated);
        setLocalValue("notices", updated);
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  const handleAddStudent = async (stud: Omit<Student, "id">) => {
    const backupStudent: Student = {
      ...stud,
      id: "s_" + Date.now()
    };

    if (isStaticOrFailedEnv()) {
      const updated = [...students, backupStudent];
      setStudents(updated);
      setLocalValue("students", updated);
      return true;
    }

    try {
      const res = await fetch("/api/students", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(stud)
      });
      const data = await res.json();
      if (data.success) {
        const updated = [...students, data.student];
        setStudents(updated);
        setLocalValue("students", updated);
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  const handleDeleteStudent = async (id: string) => {
    if (isStaticOrFailedEnv()) {
      const updated = students.filter(s => s.id !== id);
      setStudents(updated);
      setLocalValue("students", updated);
      return true;
    }

    try {
      const res = await fetch(`/api/students/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        const updated = students.filter(s => s.id !== id);
        setStudents(updated);
        setLocalValue("students", updated);
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  const handleAddTeacher = async (teacher: Omit<Teacher, "id">) => {
    const backupTeacher: Teacher = {
      ...teacher,
      id: "t_" + Date.now()
    };

    if (isStaticOrFailedEnv()) {
      const updated = [...teachers, backupTeacher];
      setTeachers(updated);
      setLocalValue("teachers", updated);
      return true;
    }

    try {
      const res = await fetch("/api/teachers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(teacher)
      });
      const data = await res.json();
      if (data.success) {
        const updated = [...teachers, data.teacher];
        setTeachers(updated);
        setLocalValue("teachers", updated);
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  const handleDeleteTeacher = async (id: string) => {
    if (isStaticOrFailedEnv()) {
      const updated = teachers.filter(t => t.id !== id);
      setTeachers(updated);
      setLocalValue("teachers", updated);
      return true;
    }

    try {
      const res = await fetch(`/api/teachers/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        const updated = teachers.filter(t => t.id !== id);
        setTeachers(updated);
        setLocalValue("teachers", updated);
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  const handleAddBook = async (book: Omit<LibraryBook, "id">) => {
    const backupBook: LibraryBook = {
      ...book,
      id: "b_" + Date.now()
    };

    if (isStaticOrFailedEnv()) {
      const updated = [...books, backupBook];
      setBooks(updated);
      setLocalValue("books", updated);
      return true;
    }

    try {
      const res = await fetch("/api/books", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(book)
      });
      const data = await res.json();
      if (data.success) {
        const updated = [...books, data.book];
        setBooks(updated);
        setLocalValue("books", updated);
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  const handleDeleteBook = async (id: string) => {
    if (isStaticOrFailedEnv()) {
      const updated = books.filter(b => b.id !== id);
      setBooks(updated);
      setLocalValue("books", updated);
      return true;
    }

    try {
      const res = await fetch(`/api/books/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        const updated = books.filter(b => b.id !== id);
        setBooks(updated);
        setLocalValue("books", updated);
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  const handleBorrowBook = async (bookId: string, userName: string) => {
    if (isStaticOrFailedEnv()) {
      const updated = books.map(b => {
        if (b.id === bookId) {
          const borrowed = (b.borrowedQuantity || 0) + 1;
          const av = borrowed < b.totalQuantity;
          return { ...b, borrowedQuantity: borrowed, availability: av };
        }
        return b;
      });
      setBooks(updated);
      setLocalValue("books", updated);
      return true;
    }

    try {
      const res = await fetch("/api/books/borrow", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          bookId,
          userId: currentUser?.id || "walk-in-usr",
          userName,
          userRole: currentUser?.role || "guardian"
        })
      });
      const data = await res.json();
      if (data.success) {
        const updated = books.map(b => b.id === bookId ? data.book : b);
        setBooks(updated);
        setLocalValue("books", updated);
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  const handleReturnBook = async (bookId: string) => {
    if (isStaticOrFailedEnv()) {
      const updated = books.map(b => {
        if (b.id === bookId) {
          const borrowed = Math.max(0, (b.borrowedQuantity || 0) - 1);
          return { ...b, borrowedQuantity: borrowed, availability: true };
        }
        return b;
      });
      setBooks(updated);
      setLocalValue("books", updated);
      return true;
    }

    try {
      const res = await fetch("/api/books/return", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bookId })
      });
      const data = await res.json();
      if (data.success) {
        const updated = books.map(b => b.id === bookId ? data.book : b);
        setBooks(updated);
        setLocalValue("books", updated);
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  const handleRegisterAdmission = async (form: any) => {
    if (isStaticOrFailedEnv()) {
      const newAdm = { 
        ...form, 
        id: "adm_" + Date.now(), 
        paymentStatus: "Verified", 
        submissionDate: new Date().toLocaleDateString("bn-BD", { year: "numeric", month: "long", day: "numeric" }).replace(/[\/\-]/g, " ")
      };
      
      const updatedAdms = [newAdm, ...admissions];
      setAdmissions(updatedAdms);
      setLocalValue("admissions", updatedAdms);

      // Create student automatically
      const newStud: Student = {
        id: "s_" + Date.now(),
        name: form.studentName,
        roll: String(100 + students.length + 1),
        class: form.class || "Play",
        session: new Date().getFullYear().toString(),
        guardianName: form.fatherName || form.motherName || "অভিভাবক",
        guardianPhone: form.phone,
        address: form.address || "চকরিয়া, কক্সবাজার",
        gender: form.gender || "Male",
        photo: form.photoUrl || "https://images.unsplash.com/photo-1503919545889-aef636e10ad4?auto=format&fit=crop&q=80&w=150",
        dob: form.dob || "২০২১-০১-০১"
      };

      const updatedStuds = [...students, newStud];
      setStudents(updatedStuds);
      setLocalValue("students", updatedStuds);

      // Create payment
      const newPay = {
        id: "p_" + Date.now(),
        studentName: form.studentName,
        class: form.class || "Play",
        method: form.paymentMethod || "bKash",
        txid: form.transactionId || "TXID" + Date.now(),
        amount: Number(form.amount || 1200),
        type: "Admission Fee",
        date: new Date().toLocaleDateString("bn-BD", { year: "numeric", month: "long", day: "numeric" }).replace(/[\/\-]/g, " "),
        status: "Verified"
      };
      const updatedPays = [newPay, ...payments];
      setPayments(updatedPays);
      setLocalValue("payments", updatedPays);
      return true;
    }

    try {
      const res = await fetch("/api/admissions/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      if (data.success) {
        const updatedAdms = [data.admission, ...admissions];
        const updatedStuds = [...students, data.student];
        setAdmissions(updatedAdms);
        setStudents(updatedStuds);
        setLocalValue("admissions", updatedAdms);
        setLocalValue("students", updatedStuds);
        
        // Refresh payments
        try {
          const pRes = await fetch("/api/payments");
          if (pRes.ok) {
            const pData = await pRes.json();
            setPayments(pData);
            setLocalValue("payments", pData);
          }
        } catch {}
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  const handleAddResult = async (resObj: any) => {
    const backupRes = { 
      ...resObj, 
      id: "r_" + Date.now(), 
      createdAt: new Date().toLocaleDateString("bn-BD", { year: "numeric", month: "long", day: "numeric" }).replace(/[\/\-]/g, " ")
    };

    if (isStaticOrFailedEnv()) {
      const updated = [backupRes, ...results];
      setResults(updated);
      setLocalValue("results", updated);
      return true;
    }

    try {
      const res = await fetch("/api/results", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(resObj)
      });
      const data = await res.json();
      if (data.success) {
        const updated = [data.result, ...results];
        setResults(updated);
        setLocalValue("results", updated);
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  const handleAddPayment = async (payObj: any) => {
    const backupPay = {
      ...payObj,
      id: "p_" + Date.now(),
      date: new Date().toLocaleDateString("bn-BD", { year: "numeric", month: "long", day: "numeric" }).replace(/[\/\-]/g, " ")
    };

    if (isStaticOrFailedEnv()) {
      const updated = [backupPay, ...payments];
      setPayments(updated);
      setLocalValue("payments", updated);
      return true;
    }

    try {
      const res = await fetch("/api/payments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payObj)
      });
      const data = await res.json();
      if (data.success) {
        const updated = [data.payment, ...payments];
        setPayments(updated);
        setLocalValue("payments", updated);
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  const handleAddAttendanceBulk = async (records: any[]) => {
    if (isStaticOrFailedEnv()) {
      const newRecords = records.map((r, idx) => ({ 
        ...r, 
        id: `att_${Date.now()}_${idx}` 
      }));
      const updated = [...newRecords, ...attendance];
      setAttendance(updated);
      setLocalValue("attendance", updated);
      return true;
    }

    try {
      const res = await fetch("/api/attendance/bulk", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ records })
      });
      const data = await res.json();
      if (data.success) {
        // Reload fresh attendance
        try {
          const aRes = await fetch("/api/attendance");
          if (aRes.ok) {
            const aData = await aRes.json();
            setAttendance(aData);
            setLocalValue("attendance", aData);
          }
        } catch {}
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  const handleImportCSVStudents = async (csvText: string) => {
    if (isStaticOrFailedEnv()) {
      const rows = csvText.split("\n").filter(r => r.trim());
      const imported: Student[] = [];
      const startRoll = 100 + students.length + 1;
      
      rows.forEach((row, index) => {
        if (index === 0 && (row.toLowerCase().includes("name") || row.includes("নাম"))) return;
        const cols = row.split(",").map(c => c.trim().replace(/^"|"$/g, ""));
        if (cols.length >= 2) {
          imported.push({
            id: "s_csv_" + Date.now() + "_" + index,
            name: cols[0],
            roll: cols[1] || String(startRoll + index),
            class: cols[2] || "Play",
            session: cols[3] || new Date().getFullYear().toString(),
            guardianName: cols[4] || "অভিভাবক",
            guardianPhone: cols[5] || "01700000000",
            address: cols[6] || "চকরিয়া, কক্সবাজার",
            gender: "Male",
            photo: "https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=150"
          });
        }
      });

      if (imported.length > 0) {
        const updated = [...students, ...imported];
        setStudents(updated);
        setLocalValue("students", updated);
        return true;
      }
      return false;
    }

    try {
      const res = await fetch("/api/students/import-csv", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ csvText })
      });
      const data = await res.json();
      if (data.success) {
        setStudents(data.students);
        setLocalValue("students", data.students);
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  const handleSendMessage = async (msg: { name: string; phone: string; message: string }) => {
    const backupMsg: ContactMessage = {
      ...msg,
      id: "c_" + Date.now(),
      date: new Date().toLocaleDateString("bn-BD", { year: "numeric", month: "long", day: "numeric" }).replace(/[\/\-]/g, " "),
      read: false
    };

    if (isStaticOrFailedEnv()) {
      const updated = [backupMsg, ...contacts];
      setContacts(updated);
      setLocalValue("contacts", updated);
      return true;
    }

    try {
      const res = await fetch("/api/contacts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(msg)
      });
      const data = await res.json();
      if (data.success) {
        const updated = [data.message, ...contacts];
        setContacts(updated);
        setLocalValue("contacts", updated);
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  const handleReadContact = async (id: string) => {
    if (isStaticOrFailedEnv()) {
      const updated = contacts.map(c => c.id === id ? { ...c, read: true } : c);
      setContacts(updated);
      setLocalValue("contacts", updated);
      return true;
    }

    try {
      const res = await fetch(`/api/contacts/read/${id}`, { method: "POST" });
      const data = await res.json();
      if (data.success) {
        const updated = contacts.map(c => c.id === id ? { ...c, read: true } : c);
        setContacts(updated);
        setLocalValue("contacts", updated);
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  const handleUpdateSettings = async (settsObj: Partial<SystemSettings>) => {
    if (isStaticOrFailedEnv()) {
      const updated = { ...settings, ...settsObj };
      setSettings(updated);
      setLocalValue("settings", updated);
      return true;
    }

    try {
      const res = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settsObj)
      });
      const data = await res.json();
      if (data.success) {
        setSettings(data.settings);
        setLocalValue("settings", data.settings);
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  const handleAddGalleryItem = async (item: { url: string; title: string; category: string }) => {
    const backupItem: GalleryItem = {
      ...item,
      category: item.category as any,
      id: "g_" + Date.now(),
      date: new Date().toLocaleDateString("bn-BD", { year: "numeric", month: "long", day: "numeric" }).replace(/[\/\-]/g, " ")
    };

    if (isStaticOrFailedEnv()) {
      const updated = [backupItem, ...gallery];
      setGallery(updated);
      setLocalValue("gallery", updated);
      return true;
    }

    try {
      const res = await fetch("/api/gallery", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(item)
      });
      const data = await res.json();
      if (data.success) {
        const updated = [data.galleryItem, ...gallery];
        setGallery(updated);
        setLocalValue("gallery", updated);
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  const handleDeleteGalleryItem = async (id: string) => {
    if (isStaticOrFailedEnv()) {
      const updated = gallery.filter(g => g.id !== id);
      setGallery(updated);
      setLocalValue("gallery", updated);
      return true;
    }

    try {
      const res = await fetch(`/api/gallery/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        const updated = gallery.filter(g => g.id !== id);
        setGallery(updated);
        setLocalValue("gallery", updated);
        return true;
      }
    } catch (err) {
      console.error(err);
    }
    return false;
  };

  // Core Switch board page mapper
  const renderCurrentTab = () => {
    switch (currentTab) {
      case "objectives":
        return (
          <Objectives 
            settings={settings} 
            onUpdateSettings={handleUpdateSettings} 
            currentUser={currentUser} 
          />
        );
      case "gallery":
        return (
          <GallerySection 
            gallery={gallery}
            onAddGallery={handleAddGalleryItem}
            onDeleteGallery={handleDeleteGalleryItem}
            currentUser={currentUser}
          />
        );
      case "teachers":
        return (
          <TeacherSection 
            teachers={teachers} 
            onAddTeacher={handleAddTeacher} 
            onDeleteTeacher={handleDeleteTeacher} 
            currentUser={currentUser} 
          />
        );
      case "students":
        return (
          <StudentSection 
            students={students} 
            onAddStudent={handleAddStudent} 
            onDeleteStudent={handleDeleteStudent} 
            currentUser={currentUser} 
          />
        );
      case "reports":
        return (
          <ReportSection 
            students={students} 
            results={results} 
            attendance={attendance} 
          />
        );
      case "library":
        return (
          <LibrarySection 
            books={books} 
            onAddBook={handleAddBook} 
            onDeleteBook={handleDeleteBook} 
            onBorrowBook={handleBorrowBook} 
            onReturnBook={handleReturnBook} 
            currentUser={currentUser} 
          />
        );
      case "admission":
        return (
          <AdmissionSection 
            onRegisterAdmission={handleRegisterAdmission} 
          />
        );
      case "contact":
        return (
          <ContactSection 
            onSendMessage={handleSendMessage} 
          />
        );
      case "dashboard":
        return currentUser ? (
          <Dashboard 
            currentUser={currentUser} 
            settings={settings}
            students={students}
            teachers={teachers}
            books={books}
            notices={notices}
            admissions={admissions}
            attendance={attendance}
            results={results}
            payments={payments}
            contacts={contacts}
            onAddNotice={handleAddNotice}
            onDeleteNotice={handleDeleteNotice}
            onAddResult={handleAddResult}
            onAddStudent={handleAddStudent}
            onDeleteStudent={handleDeleteStudent}
            onAddAttendanceBulk={handleAddAttendanceBulk}
            onImportCSVStudents={handleImportCSVStudents}
            onReadContact={handleReadContact}
            onUpdateSettings={handleUpdateSettings}
            onAddPayment={handleAddPayment}
          />
        ) : (
          <div className="py-20 text-center text-xs text-slate-500">
            ড্যাশবোর্ড ব্যবহারের জন্য অনুগ্রহ করে উপরের <strong>লগইন</strong> করুন!
          </div>
        );
      default:
        // Render Home (Hero and Notice board lists)
        return (
          <Hero 
            setTab={setTab}
            notices={notices}
            teachers={teachers}
          />
        );
    }
  };

  const headerText = getContrastColor(settings.headerBgColor || "#0f172a");

  // Dynamic Premium Styling definitions
  const fontStackMap = {
    "noto-bengali": '"Noto Sans Bengali", "Hind Siliguri", "Inter", sans-serif',
    "inter": '"Inter", sans-serif',
    "space-grotesk": '"Space Grotesk", sans-serif',
    "playfair": '"Playfair Display", serif',
    "outfit": '"Outfit", sans-serif',
    "mono": '"JetBrains Mono", monospace'
  };
  const activeFontStack = fontStackMap[settings.fontFamily || "noto-bengali"] || fontStackMap["noto-bengali"];

  const fontSizeMap = {
    "small": "13px",
    "medium": "15px",
    "large": "17px",
    "extra-large": "19px"
  };
  const activeFontSize = fontSizeMap[settings.fontSizeLevel || "medium"] || "15px";

  const speed = settings.animationDuration || "0.3s";
  const animationMode = settings.animationStyle || "smooth";
  let customTransitionRule = "";
  if (animationMode === "disabled") {
    customTransitionRule = "body, div, section, header, button, a, img, span, h1, h2, h3, h4, p, li, input, select { transition: none !important; animation: none !important; }";
  } else if (animationMode === "smooth") {
    customTransitionRule = `body, div, section, header, button, a, img, span, h1, h2, h3, h4, p, li, input, select { transition: all ${speed} ease-in-out !important; }`;
  } else if (animationMode === "bouncy") {
    customTransitionRule = `body, div, section, header, button, a, img, span, h1, h2, h3, h4, p, li, input, select { transition: all ${speed} cubic-bezier(0.175, 0.885, 0.32, 1.275) !important; }`;
  } else if (animationMode === "ultra-premium") {
    customTransitionRule = `body, div, section, header, button, a, img, span, h1, h2, h3, h4, p, li, input, select { transition: all ${speed} cubic-bezier(0.25, 1, 0.5, 1) !important; }`;
  }

  return (
    <div className="flex flex-col min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-900 dark:text-slate-100 font-sans transition-colors duration-300">
      
      <style>{`
        :root {
          --custom-web-bg: ${settings.webBgColor || '#f8fafc'};
          --custom-header-bg: ${settings.headerBgColor || '#0f172a'};
          --custom-header-text: ${headerText};
          --custom-section-bg: ${settings.sectionBgColor || '#ffffff'};
          --custom-section-text: ${settings.sectionTextColor || '#334155'};
          --custom-section-title: ${settings.sectionTitleColor || '#0f172a'};
          --custom-primary-accent: ${settings.primaryAccentColor || '#059669'};
          --custom-secondary-accent: ${settings.secondaryAccentColor || '#d97706'};
        }

        /* Apply custom premium typography font stacks and base layouts */
        body, html {
          font-family: ${activeFontStack} !important;
        }
        /* Preserve Monospace utility fonts for numbers, data grids, and codes */
        .font-mono, .font-mono *, code, pre, span.font-mono {
          font-family: "JetBrains Mono", ui-monospace, SFMono-Regular, monospace !important;
        }

        body {
          font-size: ${activeFontSize};
        }

        /* Adjust customized heading font weight */
        h1, h2, h3, h4, h5, h6, .font-heading {
          font-weight: ${settings.headingWeight === "regular" ? "400" : settings.headingWeight === "semibold" ? "600" : settings.headingWeight === "black" ? "900" : "700"} !important;
        }

        /* Dynamics Action Button & Accents styling globally override emerald colors */
        .bg-emerald-650, .bg-emerald-600, .bg-emerald-700, .bg-emerald-800 {
          background-color: var(--custom-primary-accent) !important;
        }
        .text-emerald-650, .text-emerald-600, .text-emerald-700, .dark\\:text-emerald-400 {
          color: var(--custom-primary-accent) !important;
        }
        .border-emerald-500, .border-emerald-650, .border-emerald-600 {
          border-color: var(--custom-primary-accent) !important;
        }
        .focus\\:ring-emerald-500:focus, .ring-emerald-500 {
          --tw-ring-color: var(--custom-primary-accent) !important;
          border-color: var(--custom-primary-accent) !important;
        }
        .hover\\:bg-emerald-700:hover, .hover\\:bg-emerald-600:hover {
          background-color: var(--custom-primary-accent) !important;
          filter: brightness(0.9);
        }

        /* Apply Custom transitions and speeds */
        ${customTransitionRule}

        /* Web background */
        body, 
        .bg-slate-50, 
        .dark\\:bg-slate-900, 
        #madrasha-dash-hub, 
        #objectives-page {
          background-color: var(--custom-web-bg) !important;
        }

        /* Header background overrides */
        header.sticky {
          background-color: var(--custom-header-bg) !important;
          border-bottom-color: rgba(255, 255, 255, 0.1) !important;
        }
        
        /* Header typography and buttons color */
        header.sticky h1,
        header.sticky p,
        header.sticky span:not(.bg-emerald-600):not(.bg-emerald-700):not(.bg-amber-400),
        header.sticky svg {
          color: var(--custom-header-text) !important;
        }

        header.sticky nav button:not(.bg-emerald-600) span {
          color: var(--custom-header-text) !important;
        }

        header.sticky nav button:not(.bg-emerald-600):hover {
          background-color: rgba(255, 255, 255, 0.15) !important;
        }

        /* Sections and Card backgrounds */
        .bg-white, 
        .dark\\:bg-slate-850, 
        .dark\\:bg-slate-855,
        form:not(#auth-form-body), 
        section, 
        .section,
        .bg-slate-50:not(body):not(.min-h-screen) {
          background-color: var(--custom-section-bg) !important;
        }

        /* Section Titles and Headings */
        h1, h2, h3, h4, h5, h6, .font-heading {
          color: var(--custom-section-title) !important;
        }

        /* Paragraphs and texts */
        p, 
        li, 
        .text-slate-650,
        .text-slate-600, 
        .text-slate-755,
        .text-slate-700, 
        .text-slate-500, 
        .dark\\:text-slate-300, 
        .dark\\:text-slate-400 {
          color: var(--custom-section-text) !important;
        }

        /* LAYOUT PRESET INTERACTION STYLES OVERRIDES */
        ${settings.premiumStyleMode === "flat" ? `
          .rounded-2xl, .rounded-xl, .rounded-lg, .rounded-md, .rounded-3xl {
            border-radius: 0px !important;
          }
          .shadow-3xs, .shadow-2xs, .shadow-xs, .shadow-sm, .shadow-md, .shadow-lg, .shadow-xl {
            box-shadow: none !important;
          }
        ` : settings.premiumStyleMode === "bordered" ? `
          .rounded-2xl { border-radius: 8px !important; }
          .rounded-xl { border-radius: 6px !important; }
          .shadow-3xs, .shadow-2xs, .shadow-xs, .shadow-sm, .shadow-md, .shadow-lg, .shadow-xl {
            box-shadow: none !important;
          }
          .border, .border-slate-100, .border-slate-200, .border-slate-800 {
            border: 1.5px solid var(--custom-primary-accent) !important;
          }
        ` : settings.premiumStyleMode === "glowing" ? `
          .rounded-2xl { border-radius: 20px !important; }
          .bg-white, .dark\\:bg-slate-855, section, .section {
            box-shadow: 0 10px 30px rgba(5, 150, 105, 0.08) !important;
            border-color: rgba(5, 150, 105, 0.15) !important;
          }
        ` : settings.premiumStyleMode === "glass" ? `
          .bg-white, .dark\\:bg-slate-855, section, .section {
            background: rgba(255, 255, 255, 0.72) !important;
            backdrop-filter: blur(16px) !important;
            -webkit-backdrop-filter: blur(16px) !important;
            border: 1px solid rgba(255, 255, 255, 0.4) !important;
          }
          .dark .bg-white, .dark .dark\\:bg-slate-855, .dark section, .dark .section {
            background: rgba(15, 23, 42, 0.78) !important;
            backdrop-filter: blur(16px) !important;
            -webkit-backdrop-filter: blur(16px) !important;
            border: 1px solid rgba(255, 255, 255, 0.06) !important;
          }
        ` : `
          /* minimalist */
          .shadow-3xs, .shadow-2xs, .shadow-xs, .shadow-sm, .shadow-md, .shadow-lg, .shadow-xl {
            box-shadow: none !important;
          }
          .border, .border-slate-100, .border-slate-200 {
            border-color: #f1f5f9 !important;
          }
          .dark .border, .dark .border-slate-800 {
            border-color: #334155 !important;
          }
        `}
      `}</style>

      {/* Premium Sticky Header Navigation */}
      <Header
        currentTab={currentTab}
        setTab={setTab}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        currentUser={currentUser}
        onLogout={handleLogout}
        onOpenAuth={(mode) => setAuthModal({ open: true, mode })}
        settings={settings}
      />

      {/* Primary Section Canvas */}
      <main className="flex-1">
        {renderCurrentTab()}
      </main>

      {/* Website Footer Information */}
      <Footer setTab={setTab} />

      {/* Authentication Lightbox forms Modal */}
      {authModal.open && (
        <AuthModal
          initialMode={authModal.mode}
          onClose={() => setAuthModal({ open: false, mode: "login" })}
          onLoginSuccess={handleLoginSuccess}
        />
      )}
    </div>
  );
}
