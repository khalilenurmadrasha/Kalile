import React, { useState } from "react";
import { AdmissionForm } from "../types";
import { UserCheck2, Wallet2, ShieldCheck, ClipboardCheck, ArrowRight, CornerDownRight, CheckCircle, Smartphone, HelpCircle } from "lucide-react";

interface AdmissionSectionProps {
  onRegisterAdmission: (admissionForm: Omit<AdmissionForm, "id" | "paymentStatus" | "submissionDate">) => Promise<boolean>;
}

export default function AdmissionSection({ onRegisterAdmission }: AdmissionSectionProps) {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);

  // Form Fields State
  const [studentName, setStudentName] = useState("");
  const [fatherName, setFatherName] = useState("");
  const [motherName, setMotherName] = useState("");
  const [dob, setDob] = useState("");
  const [className, setClassName] = useState<any>("Play");
  const [gender, setGender] = useState<any>("Male");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [photoUrl, setPhotoUrl] = useState("");

  // Payment State
  const [paymentMethod, setPaymentMethod] = useState<any>("");
  const [transactionId, setTransactionId] = useState("");
  const [paymentVerified, setPaymentVerified] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [amount] = useState(1500); // 1,500 BDT Standard admission fee

  // Final Response Success Receipt Details
  const [receipt, setReceipt] = useState<any>(null);

  const paymentSteps = [
    { method: "bKash", num: "01823456781", instruct: "মার্চেন্ট বিকাশ নম্বরে সেন্ড মানি অথবা পেমেন্ট করুন।" },
    { method: "Nagad", num: "01823456782", instruct: "নগদ পার্সোনাল নম্বরে সেন্ড মানি করুন।" },
    { method: "Rocket", num: "01823456782-9", instruct: "রকেট ডাচ-বাংলা পার্সোনাল নম্বরে সেন্ড মানি করুন।" },
    { method: "Bank Transfer", num: "102.120.33420", instruct: "ইসলামী ব্যাংক চকোরিয়া শাখা, সঞ্চয়ী হিসাবঃ খলিলে নূর মাদ্রাসা।" }
  ];

  const currentPaymentDetail = paymentSteps.find(p => p.method === paymentMethod);

  // Validate form details in step 1
  const handleProceedToPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentName || !fatherName || !motherName || !phone || !className) {
      alert("দয়া করে সকল বাধ্যতামূলক তথ্য পূরণ করুন!");
      return;
    }
    setStep(2);
  };

  const handleVerifyPayment = () => {
    if (!transactionId || transactionId.trim().length < 6) {
      alert("অনুগ্রহ করে বিকাশ/নগদ এর সঠিক ট্রানজেকশন আইডি প্রবেশ করান!");
      return;
    }
    setVerifying(true);
    setTimeout(() => {
      setVerifying(false);
      setPaymentVerified(true);
    }, 1500);
  };

  const handleFinalSubmit = async () => {
    if (!paymentVerified) return;

    setLoading(true);
    const mockPhoto = photoUrl || "https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=150";

    const localData = {
      studentName,
      fatherName,
      motherName,
      dob: dob || "২০২১-০১-০১",
      class: className,
      gender,
      phone,
      address: address || "চকরিয়া, কক্সবাজার",
      photoUrl: mockPhoto,
      paymentMethod,
      transactionId,
      amount
    };

    const success = await onRegisterAdmission(localData);
    setLoading(false);
    
    if (success) {
      setReceipt({
        id: "ADM-RCV-" + Math.floor(100000 + Math.random() * 900000),
        date: new Date().toISOString().split("T")[0],
        ...localData
      });
      setStep(3);
    }
  };

  return (
    <div id="enrollment-registration-flow" className="py-12 bg-slate-50 dark:bg-slate-900 min-h-screen transition-colors duration-300">
      <div className="max-w-2xl mx-auto px-4 sm:px-6">
        
        {/* Step Ticker Header */}
        <div className="bg-white dark:bg-slate-850 p-5 rounded-2xl border border-slate-150/80 dark:border-slate-800/80 shadow-3xs mb-8">
          <div className="flex justify-between items-center text-xs font-bold text-slate-400">
            <div className={`flex items-center gap-1.5 ${step >= 1 ? "text-emerald-600 dark:text-emerald-400" : ""}`}>
              <span className={`w-6 h-6 rounded-full flex items-center justify-center font-mono ${step >= 1 ? "bg-emerald-600 dark:bg-emerald-700 text-white" : "bg-slate-100"}`}>1</span>
              <span>শিক্ষার্থী তথ্য</span>
            </div>
            <CornerDownRight size={14} className="opacity-40" />
            <div className={`flex items-center gap-1.5 ${step >= 2 ? "text-emerald-600 dark:text-emerald-400" : ""}`}>
              <span className={`w-6 h-6 rounded-full flex items-center justify-center font-mono ${step >= 2 ? "bg-emerald-600 dark:bg-emerald-700 text-white" : "bg-slate-100"}`}>2</span>
              <span>পেমেন্ট ও ভেরিফাই</span>
            </div>
            <CornerDownRight size={14} className="opacity-40" />
            <div className={`flex items-center gap-1.5 ${step >= 3 ? "text-emerald-600 dark:text-emerald-400" : ""}`}>
              <span className={`w-6 h-6 rounded-full flex items-center justify-center font-mono ${step >= 3 ? "bg-emerald-600 dark:bg-emerald-700 text-white" : "bg-slate-100"}`}>3</span>
              <span>রশিদ ও নিশ্চিতকরণ</span>
            </div>
          </div>
        </div>

        {/* STEP 1: Personal Details form */}
        {step === 1 && (
          <div className="bg-white dark:bg-slate-850 rounded-2xl border border-slate-100 dark:border-slate-800 p-6 shadow-3xs">
            <div className="pb-4 mb-6 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
              <UserCheck2 className="text-emerald-500" size={18} />
              <h3 className="font-heading text-xs sm:text-sm font-black text-slate-800 dark:text-white">অনলাইন ভর্তি তথ্য ফর্ম (Admission Details)</h3>
            </div>

            <form onSubmit={handleProceedToPayment} className="flex flex-col gap-4 text-xs font-medium">
              
              <div>
                <label className="block text-slate-500 dark:text-slate-400 mb-1">শিক্ষার্থীর সম্পূর্ণ নাম (বাংলা অথবা ইংরেজি) *</label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: মোঃ আরাফাত সিদ্দিক"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-500 dark:text-slate-400 mb-1">পিতার নাম (Father's Name) *</label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: মোঃ সালাহউদ্দিন"
                    value={fatherName}
                    onChange={(e) => setFatherName(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 dark:text-slate-400 mb-1">মাতার নাম (Mother's Name) *</label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: বিলকিস বেগম"
                    value={motherName}
                    onChange={(e) => setMotherName(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-500 dark:text-slate-400 mb-1">ভর্তি ইচ্ছুক শ্রেণী (Class) *</label>
                  <select
                    value={className}
                    onChange={(e) => setClassName(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-850 text-slate-800 dark:text-white focus:outline-emerald-500"
                  >
                    <option value="Play">Play (প্লে শ্রেণী)</option>
                    <option value="Nursery">Nursery (নার্সারি)</option>
                    <option value="First">One (প্রথম শ্রেণী)</option>
                    <option value="Second">Two (দ্বিতীয় শ্রেণী)</option>
                    <option value="Third">Three (তৃতীয় শ্রেণী)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-500 dark:text-slate-400 mb-1">লিঙ্গ (Gender) *</label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-850 text-slate-800 dark:text-white focus:outline-emerald-500"
                  >
                    <option value="Male">👦 ছাত্র (Male)</option>
                    <option value="Female">👧 ছাত্রী (Female)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-500 dark:text-slate-400 mb-1">জন্ম তারিখ (Date of Birth) *</label>
                  <input
                    type="date"
                    required
                    value={dob}
                    onChange={(e) => setDob(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 dark:text-slate-400 mb-1">অভিভাবকের সচল ইমেইল বা ফোন *</label>
                  <input
                    type="tel"
                    required
                    placeholder="০১৮XXXXXXXX"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-500 dark:text-slate-400 mb-1">পাসপোর্ট সাইজ ছবির ওয়েব লিঙ্ক (Photo Web URL)</label>
                <input
                  type="url"
                  placeholder="https://images.unsplash.com/photo-..."
                  value={photoUrl}
                  onChange={(e) => setPhotoUrl(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-500 dark:text-slate-400 mb-1">সম্পূর্ণ স্থায়ী ঠিকানা *</label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: বাজারপাড়া, ঢেমুশিয়া, চকরিয়া, কক্সবাজার"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                />
              </div>

              <button
                type="submit"
                className="w-full mt-4 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>ধাপ ২ - পেমেন্ট করুন</span>
                <ArrowRight size={14} />
              </button>
            </form>
          </div>
        )}

        {/* STEP 2: Payment Gateway Selection & verification Gating */}
        {step === 2 && (
          <div className="bg-white dark:bg-slate-850 rounded-2xl border border-slate-100 dark:border-slate-800 p-6 shadow-3xs flex flex-col gap-6">
            
            <div className="pb-4 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
              <Wallet2 className="text-emerald-555 animate-bounce" size={18} />
              <h3 className="font-heading text-xs sm:text-sm font-black text-slate-850 dark:text-white">অনলাইন ভর্তি ফি পেমেন্ট গেটওয়ে (Payment Gate)</h3>
            </div>

            {/* Sum receipt indicators */}
            <div className="p-4 bg-slate-50 dark:bg-slate-900/40 rounded-xl border border-slate-100 dark:border-slate-800 text-xs">
              <div className="flex justify-between font-medium">
                <span className="text-slate-400">ভর্তিচ্ছু শিক্ষার্থী:</span>
                <span className="text-slate-750 dark:text-slate-200 font-bold">{studentName}</span>
              </div>
              <div className="flex justify-between font-medium mt-1.5">
                <span className="text-slate-400">শ্রেণী সিলেবাস ও জিপিএ:</span>
                <span className="text-slate-750 dark:text-slate-200 font-mono">Category: {className}</span>
              </div>
              <div className="flex justify-between font-medium border-t border-dashed border-slate-200 dark:border-slate-800 pt-2.5 mt-2.5 text-sm">
                <span className="font-bold text-slate-800 dark:text-white">নির্ধারিত পেমেন্ট ফি:</span>
                <span className="font-mono text-emerald-650 dark:text-emerald-400 font-bold">{amount} BDT (১,৫০০/- টাকা)</span>
              </div>
            </div>

            {/* Step Selection options */}
            <div>
              <p className="text-xs font-bold text-slate-500 dark:text-slate-400 mb-3">পছন্দসই পেমেন্ট পদ্ধতি নির্বাচন করুন *</p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {["bKash", "Nagad", "Rocket", "Bank Transfer"].map((method) => (
                  <button
                    key={method}
                    id={`pay-method-${method}`}
                    onClick={() => {
                      setPaymentMethod(method);
                      setPaymentVerified(false);
                      setTransactionId("");
                    }}
                    className={`p-3 rounded-xl border text-center font-bold text-xs transition-all flex flex-col items-center justify-center gap-2 cursor-pointer relative ${
                      paymentMethod === method
                        ? "border-emerald-600 bg-emerald-50/40 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-400"
                        : "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-900 text-slate-655"
                    }`}
                  >
                    {paymentMethod === method && (
                      <span className="absolute top-1.5 right-1.5 text-emerald-650">✓</span>
                    )}
                    <span className="text-lg">
                      {method === "bKash" ? "🌸" : method === "Nagad" ? "🔶" : method === "Rocket" ? "🌌" : "🏦"}
                    </span>
                    <span>{method}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Payment Details Prompt and dynamic verification inputs */}
            {paymentMethod && currentPaymentDetail && (
              <div className="p-5 rounded-xl border border-dashed border-emerald-500/30 bg-emerald-50/10 dark:bg-emerald-950/5 flex flex-col gap-4 text-xs">
                <div>
                  <h4 className="font-bold text-emerald-700 dark:text-emerald-400 flex items-center gap-1">
                    <Smartphone size={14} />
                    <span>{paymentMethod} ভর্তি নির্দেশাবলী:</span>
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-350 mt-1">
                    {currentPaymentDetail.instruct} পেমেন্ট করার জন্য উপরের সংশ্লিষ্ট নম্বরটি ব্যবহার করুন।
                  </p>
                  <p className="text-xs font-black text-slate-750 dark:text-white mt-1.5">
                    {paymentMethod === "Bank Transfer" ? "ব্যাঙ্ক হিসাব নম্বরঃ" : "নম্বরঃ"}{" "}
                    <span className="font-mono bg-white dark:bg-slate-900 border px-2 py-0.5 rounded-sm select-all">
                      {currentPaymentDetail.num}
                    </span>
                  </p>
                </div>

                <div className="border-t border-slate-200 dark:border-emerald-950/30 pt-4 flex flex-col gap-3">
                  <label className="block font-bold text-slate-500">পেমেন্ট সফল করার পর প্রাপ্ত ট্রানজেকশন আইডি (TxID) বসান *</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="যেমন: BKX987HFE2 অথবা NGD6652GFT"
                      value={transactionId}
                      onChange={(e) => setTransactionId(e.target.value.toUpperCase())}
                      className="flex-1 p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-900 text-slate-800 dark:text-white focus:outline-emerald-500 font-mono text-xs uppercase"
                    />
                    <button
                      type="button"
                      onClick={handleVerifyPayment}
                      disabled={verifying || paymentVerified}
                      className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg transition-all shrink-0 cursor-pointer disabled:opacity-40"
                    >
                      {verifying ? "যাচাই হচ্ছে..." : paymentVerified ? "ভেরিফাইড" : "পেমেন্ট ভেরিফাই"}
                    </button>
                  </div>

                  {paymentVerified ? (
                    <div className="bg-emerald-100 text-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-400 p-3 rounded-lg flex items-center gap-2 font-semibold">
                      <CheckCircle size={14} />
                      <span>পেমেন্ট গেটওয়ে ট্রানজেকশন সফলভাবে যাচাই করা হয়েছে। ভর্তির আবেদন সাবমিট করার জন্য প্রস্তুত!</span>
                    </div>
                  ) : (
                    <p className="text-[10px] text-slate-450 italic flex items-center gap-1">
                      <HelpCircle size={12} />
                      <span>পরীক্ষার জন্য যে কোনো অক্ষর (যেমন: <strong>TESTTXID</strong>) বসিয়ে ভেরিফাই টিপুন।</span>
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* Gated submission rules */}
            <div className="flex gap-3 justify-between items-center border-t border-slate-100 dark:border-slate-800 pt-5">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="px-4 py-2 text-xs font-bold text-slate-500 border rounded-lg hover:bg-slate-50 cursor-pointer"
              >
                পিছনে যান (Back)
              </button>

              <button
                type="button"
                id="final-admission-submit-btn"
                onClick={handleFinalSubmit}
                disabled={loading || !paymentVerified}
                className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed"
              >
                {loading ? "প্রক্রিয়াকরণ হচ্ছে..." : "ভর্তি নিশ্চিত ও ফর্ম জমা দিন"}
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Complete print-ready dynamic Receipt */}
        {step === 3 && receipt && (
          <div className="bg-white dark:bg-slate-850 rounded-2xl border border-emerald-500/20 p-6 shadow-md text-center flex flex-col gap-6 relative overflow-hidden print-card">
            
            <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 mx-auto animate-float">
              <CheckCircle size={32} />
            </div>

            <div>
              <h3 className="font-heading text-lg font-black text-slate-850 dark:text-white-800">ভর্তি আবেদন সফলভাবে গৃহীত হয়েছে!</h3>
              <p className="text-[11px] text-slate-400 mt-1">
                সম্মানিত অভিভাবক, আপনার আবেদন এবং পেমেন্ট সফলভাবে সম্পন্ন হয়েছে। রশিদ কপি নিচে দেওয়া হল।
              </p>
            </div>

            {/* Receipt copy */}
            <div className="text-left border border-slate-150 p-5 rounded-2xl bg-slate-50 dark:bg-slate-900/40 text-xs">
              <div className="text-center pb-3 border-b border-dashed border-slate-200 dark:border-slate-800 mb-4">
                <span className="font-bold text-[10px] text-slate-400 uppercase tracking-widest font-mono">Admission Receipt</span>
                <h4 className="text-sm font-bold text-slate-800 dark:text-white mt-1">খলিলে নূর নূরানী কেজি মাদ্রাসা</h4>
                <p className="text-[10px] text-slate-400 mt-0.5 font-mono">{receipt.id}</p>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between"><span className="text-slate-400">শিক্ষার্থীর নামঃ</span> <span className="font-bold">{receipt.studentName}</span></div>
                <div className="flex justify-between"><span className="text-slate-400">পিতার নামঃ</span> <span>{receipt.fatherName}</span></div>
                <div className="flex justify-between"><span className="text-slate-400">ভর্তিকৃত শ্রেণীঃ</span> <span className="font-bold">Class: {receipt.class}</span></div>
                <div className="flex justify-between"><span className="text-slate-400">মোবাইলঃ</span> <span className="font-mono">{receipt.phone}</span></div>
                <div className="flex justify-between border-t border-slate-200 dark:border-slate-800 pt-2.5 mt-2"><span className="text-slate-400">পেমেন্ট গেটওয়েঃ</span> <span className="font-bold">{receipt.paymentMethod}</span></div>
                <div className="flex justify-between"><span className="text-slate-400">ট্রানজেকশন আইডিঃ</span> <span className="font-mono font-bold text-emerald-650">{receipt.transactionId}</span></div>
                <div className="flex justify-between"><span className="text-slate-400">পরিশোধিত ফিঃ</span> <span className="font-mono font-bold text-emerald-650">{receipt.amount} BDT (পরিশোধিত)</span></div>
                <div className="flex justify-between"><span className="text-slate-400">তারিখঃ</span> <span className="font-mono text-slate-400">{receipt.date}</span></div>
              </div>
            </div>

            <div className="flex gap-4 no-print justify-center">
              <button
                onClick={() => window.print()}
                className="px-5 py-2.5 bg-slate-850 hover:bg-slate-900 text-white font-bold text-xs rounded-xl transition-all shadow-xs shrink-0 cursor-pointer"
              >
                রশিদ প্রিন্ট করুন (Print Receipt)
              </button>
              <button
                onClick={() => {
                  setStep(1);
                  setStudentName("");
                  setFatherName("");
                  setMotherName("");
                  setPhone("");
                  setPaymentMethod("");
                  setTransactionId("");
                  setPaymentVerified(false);
                  setReceipt(null);
                }}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-all cursor-pointer"
              >
                নতুন আবেদন করুন
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
