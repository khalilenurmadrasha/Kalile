import React, { useState, useEffect } from "react";
import { BookOpen, GraduationCap, Trophy, Users, Star, ArrowRight, Award, Calendar, Bell, ChevronRight, CheckCircle2 } from "lucide-react";
import { Notice, Teacher } from "../types";

interface HeroProps {
  setTab: (tab: string) => void;
  notices: Notice[];
  teachers: Teacher[];
}

export default function Hero({ setTab, notices, teachers }: HeroProps) {
  const [activeSlide, setActiveSlide] = useState(0);

  const slides = [
    {
      titleBn: "দ্বীনি শিক্ষার আলোয় আলোকিত হোক আপনাদের সন্তান",
      titleEn: "Enlighten Your Children With Islamic Knowledge",
      subtitleBn: "খলিলে নূর কাশেমুল উলুম নূরানী কেজি মাদ্রাসায় ২০২৬ শিক্ষাবর্ষে ভর্তি চলছে!",
      ctaBn: "অনলাইন ভর্তি আবেদন",
      tag: "ভর্তি চলছে"
    },
    {
      titleBn: "নূরানী তাজবিদ তালীম ও সাধারণ আধুনিক সুশিক্ষা",
      titleEn: "Sound Basic Quranic Recitation & Elementary General KG Cadets",
      subtitleBn: "চকরিয়ার ঢেমুশিয়া ইউনিয়নে দ্বীন ও আধ্যাত্মিক সুশিক্ষার এক অনন্য নির্ভরতা।",
      ctaBn: "উদ্দেশ্য ও লক্ষ্যসমূহ",
      tag: "আদর্শ আদর্শ সিলেবাস"
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const stats = [
    { icon: <Users className="text-emerald-500" size={24} />, count: "২৫০+", title: "মোট শিক্ষার্থী (Students)" },
    { icon: <GraduationCap className="text-emerald-555 animate-bounce" size={24} />, count: "১০+", title: "দক্ষ শিক্ষক (Teachers)" },
    { icon: <BookOpen className="text-teal-500" size={24} />, count: "১১+", title: "লাইব্রেরি ক্যাটাগরি (Books)" },
    { icon: <Trophy className="text-amber-500" size={24} />, count: "১০০%", title: "সাফল্যের হার (Success Rate)" }
  ];

  const courses = [
    {
      title: "নূরানী মক্তব বিভাগ (Noorani Maktab)",
      desc: "প্লে ও নার্সারি শিক্ষার্থীদের তাজবিদ সহকারে সহীহ-শুদ্ধ কুরআন তেলাওয়াত ও ইসলামিক দোয়া শেখানো হয়।",
      badge: "Play - Nursery",
      icon: "📖"
    },
    {
      title: "কেজি ক্যাডেট বিভাগ (KG Cadet)",
      desc: "বাংলা, ইংরেজি এবং গণিত বিষয়ের সমন্বয়ে প্রথম থেকে তৃতীয় শ্রেণী পর্যন্ত আধুনিক কেজি কারিকুলাম শিক্ষা দান।",
      badge: "Class 1 - 3",
      icon: "🖋️"
    },
    {
      title: "হিফজুল কুরআন প্রস্তুতিমূলক বিভাগ",
      desc: "বাচ্চাদের সুন্দর সুললিত কণ্ঠে কুরআন হিফজ করানোর উদ্দেশ্যে তাজবিদ ও নাজেরা বিভাগ।",
      badge: "Special Quran",
      icon: "🕌"
    }
  ];

  const activities = [
    "তাজবিদ সহকারে পবিত্র কুরআন বিশুদ্ধভাবে তিলাওয়াত শিক্ষা।",
    "হাতের লেখা অত্যধিক সুন্দর ও আকর্ষণীয় করার বিশেষ প্রশিক্ষণ।",
    "দৈনন্দিন মাসনুন দোয়া, মাসায়েল ও মৌলিক আকাইদ অনুধাবন।",
    "বাৎসরিক হামদ-নাত, ইসলামী কুইজ, ক্বিরাত ও বক্তৃতা প্রতিযোগিতা।"
  ];

  const testimonials = [
    { name: "মোঃ জুনাইদ", role: "ব্যবসায়ী ও অভিভাবক (চকরিয়া)", text: "আমার সন্তান সাজ্জাদ এখানে প্লে শ্রেণীতে পড়ছে। তার কুরআন রিডিং ও ব্যবহারের দৃশ্যমান উন্নতি দেখে আমি অত্যন্ত আনন্দিত। মাশআল্লাহ!", rating: 5 },
    { name: "হাফেজ মোঃ ইউনুস", role: "শিক্ষক ও অভিভাবক (ঢেমুশিয়া)", text: "মাদ্রাসার দ্বীনি শিক্ষার উপযুক্ত পরিবেশ এবং শিক্ষকমণ্ডলীর নম্র আচরণ সত্যিই প্রশংসনীয়। তারা বাচ্চাদের আধুনিক পড়াশোনাও গুরুত্ব দিয়ে শেখায়।", rating: 5 }
  ];

  const welcomePrincipal = teachers.find(t => t.designation === "মুহতামিম / প্রধান শিক্ষক") || {
    name: "মাওলানা হাফেজ মোঃ ছিদ্দিকুল্লাহ",
    designation: "মুহতামিম/প্রধান শিক্ষক",
    qualification: "কামিল হাদীস, নূরানী প্রশিক্ষক",
    biography: "মাদ্রাসার শিক্ষার্থীদের দ্বীনি মূল্যবোধ ও আধুনিক নৈতিকতায় উজ্জীবিত করতে আমরা বদ্ধপরিকর।"
  };

  const urgentNotice = notices.find(n => n.important) || notices[0];

  return (
    <div id="homepage-container" className="flex flex-col min-h-screen">
      
      {/* 1. Dynamic Hero Slideshow */}
      <section className="relative overflow-hidden bg-slate-900 border-b border-emerald-900/40 text-white min-h-[440px] flex items-center">
        {/* Background Overlay Decor */}
        <div className="absolute inset-0 opacity-15 overflow-hidden">
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-emerald-500 rounded-full blur-3xl"></div>
          <div className="absolute bottom-1/3 left-1/3 w-80 h-80 bg-teal-500 rounded-full blur-3xl"></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 flex flex-col items-center text-center">
          
          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-550/20 border border-emerald-500/30 text-emerald-400 text-xs font-semibold mb-6 animate-pulse">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>{slides[activeSlide].tag}</span>
          </div>

          <p className="font-mono text-xs sm:text-sm tracking-[0.2em] uppercase text-emerald-400 font-bold mb-3 animate-fade-in">
            {slides[activeSlide].titleEn}
          </p>
          
          <h2 className="font-heading text-2xl sm:text-4xl md:text-5xl font-extrabold leading-tight max-w-4xl tracking-tight text-white mb-4 animate-float">
            {slides[activeSlide].titleBn}
          </h2>

          <p className="text-xs sm:text-base text-slate-350 max-w-2xl mb-8 leading-relaxed">
            {slides[activeSlide].subtitleBn}
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button
              id="hero-apply-admission"
              onClick={() => setTab("admission")}
              className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-lg hover:shadow-emerald-900/35 transition-all flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <span>{slides[activeSlide].ctaBn}</span>
              <ArrowRight size={14} />
            </button>
            <button
              id="hero-view-objectives"
              onClick={() => setTab("objectives")}
              className="px-6 py-3.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
            >
              উদ্দেশ্য ও উপদেশসমূহ
            </button>
          </div>
        </div>
      </section>

      {/* Notice Board Ticker Bar */}
      {urgentNotice && (
        <div className="bg-amber-50 dark:bg-amber-950/25 border-y border-amber-200 dark:border-amber-900 px-4 py-2.5">
          <div className="max-w-7xl mx-auto flex items-center gap-3">
            <span className="flex items-center gap-1 bg-amber-600 text-white text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-sm shrink-0">
              <Bell size={10} className="animate-swing" />
              <span>জরুরী নোটিশ</span>
            </span>
            <marquee className="text-xs font-semibold text-amber-900 dark:text-amber-400 cursor-pointer" onClick={() => setTab("home")}>
              {urgentNotice.title} -- {urgentNotice.content}
            </marquee>
          </div>
        </div>
      )}

      {/* 2. Welcome Message & Animated Logo Segment */}
      <section className="py-16 bg-white dark:bg-slate-900 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Animated Logo Container Area */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center relative">
            <div className="absolute w-72 h-72 rounded-full bg-emerald-200/20 dark:bg-emerald-900/10 blur-3xl animate-pulse"></div>
            <div className="w-56 h-56 rounded-full bg-indigo-550/5 border border-slate-100 dark:border-slate-800 flex items-center justify-center p-8 relative animate-float shadow-2xs">
              
              {/* Islamic Pattern Symbol Rotator */}
              <div className="absolute inset-2 border border-dashed border-emerald-555/40 rounded-full animate-spin [animation-duration:35s]"></div>
              
              <div className="w-40 h-40 rounded-full bg-emerald-650 flex items-center justify-center text-white text-7xl shadow-xl relative">
                🕌
                <div className="absolute -bottom-1 inset-x-0 h-4 bg-yellow-450 rounded-full opacity-70 blur-xs"></div>
              </div>
            </div>
            <span className="mt-6 text-xs text-slate-400 italic">খলিলে নূর কাশেমুল উলুম নূরানী কেজি মাদ্রাসা</span>
          </div>

          {/* Welcome Text, Principal Message */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest font-mono">
              Welcome Message
            </span>
            <h2 className="font-heading text-xl sm:text-2xl font-black text-slate-800 dark:text-white leading-tight">
              সুস্বাগতম! খলিলে নূর কাশেমুল উলুম নূরানী কেজি মাদ্রাসা
            </h2>
            <div className="w-16 h-1 bg-emerald-600 dark:bg-emerald-500 rounded-full"></div>
            
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed mt-2">
              দ্বীনি শিক্ষা মানব সৃষ্টির আদি থেকে অন্ত পর্যন্ত একমাত্র মুক্তির পথ। আমাদের এই প্রতিষ্ঠান চকরিয়া বাজারপাড়ার প্রাণকেন্দ্রে একটি ব্যতিক্রমী ও যুগোপযোগী নূরানী মাদ্রাসা হিসেবে আবর্তিত। আমরা আমাদের বাচ্চাদের পবিত্র কুরআন শরীফের সহীহ তালীমের পাশাপাশি বিজ্ঞানভিত্তিক কেজি শিক্ষা, বাংলা, ইংরেজি ও গণিতের সাধারণ কারিকুলাম অত্যন্ত দক্ষতার সাথে প্রশিক্ষণপ্রাপ্ত উস্তায মণ্ডলী দ্বারা নিয়মিত ক্লাস নিয়ে থাকি।
            </p>

            {/* Principal Signature Card */}
            <div className="mt-4 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row gap-4 items-start shadow-2xs">
              <img 
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200" 
                alt="Principal"
                className="w-14 h-14 rounded-full object-cover border border-emerald-600/30 shrink-0"
              />
              <div>
                <h4 className="text-xs font-black text-slate-800 dark:text-white">{welcomePrincipal.name}</h4>
                <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold mt-0.5">{welcomePrincipal.designation}</p>
                <p className="text-[10px] text-slate-400 mt-1">{welcomePrincipal.qualification}</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-350 italic mt-2">"{welcomePrincipal.biography}"</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Statistics Counter widgets */}
      <section className="py-12 bg-slate-50 dark:bg-slate-950 border-y border-slate-100 dark:border-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, i) => (
              <div key={i} className="bg-white dark:bg-slate-900/60 p-5 rounded-2xl border border-slate-100 dark:border-slate-800/80 hover:border-emerald-500/20 transition-all text-center group shadow-2xs">
                <div className="w-12 h-12 rounded-full bg-emerald-50 dark:bg-emerald-950/45 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                  {stat.icon}
                </div>
                <h3 className="font-heading text-lg sm:text-2xl font-black text-slate-800 dark:text-white mb-1">
                  {stat.count}
                </h3>
                <p className="text-[11px] font-bold text-slate-400 tracking-tight dark:text-slate-450 uppercase">
                  {stat.title}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Featured Programs */}
      <section className="py-16 bg-white dark:bg-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center">
          
          <div className="text-center max-w-xl mb-12">
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest font-mono">Our Curriculum</span>
            <h2 className="font-heading text-xl sm:text-2xl font-black text-slate-800 dark:text-white leading-tight mt-1">
              আমাদের শিক্ষা বিভাগসমূহ (Academic Programs)
            </h2>
            <div className="w-12 h-1 bg-emerald-600 dark:bg-emerald-500 rounded-full mx-auto mt-3"></div>
            <p className="text-xs text-slate-450 dark:text-slate-450 mt-3 leading-relaxed">
              অভিজ্ঞতাসম্পন্ন সুধী উস্তাযদের তদারকির মাধ্যমে শিক্ষার্থীদের আধুনিক সমাজ ব্যবস্থার সাথে তাল মিলিয়ে ইসলাম ধর্মের গভীর জ্ঞান দান করা হয়।
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full">
            {courses.map((course, idx) => (
              <div key={idx} className="bg-slate-50 dark:bg-slate-850 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 hover:border-emerald-500/35 transition-all text-left flex flex-col gap-4 shadow-3xs group cursor-pointer hover:shadow-xs">
                <div className="w-12 h-12 rounded-xl bg-emerald-600 flex items-center justify-center text-white text-2xl shadow-md">
                  {course.icon}
                </div>
                <div>
                  <span className="text-[10px] font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-widest">{course.badge}</span>
                  <h3 className="font-heading text-xs sm:text-sm font-bold text-slate-800 dark:text-white mt-1 group-hover:text-emerald-600 transition-colors">
                    {course.title}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-350 mt-2 leading-relaxed">
                    {course.desc}
                  </p>
                </div>
                <button onClick={() => setTab("admission")} className="text-xs font-black text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1.5 mt-auto pt-4 border-t border-slate-200/40 cursor-pointer">
                  <span>ভর্তি আবেদন করুন</span>
                  <ChevronRight size={14} />
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. Activities Section */}
      <section className="py-16 bg-slate-50 dark:bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-6 flex flex-col gap-4">
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest font-mono">Co-Curriculars</span>
            <h2 className="font-heading text-xl sm:text-2xl font-black text-slate-800 dark:text-white leading-tight">
              আমাদের উল্লেখযোগ্য সুবিধাসমূহ ও কার্যক্রম
            </h2>
            <div className="w-16 h-1 bg-emerald-600 dark:bg-emerald-500 rounded-full"></div>
            
            <p className="text-xs text-slate-500 dark:text-slate-350 leading-relaxed mt-2">
              শুধু বই কেন্দ্রিক কিতাবী পড়ালেখার মাঝে সীমাবদ্ধ না রেখে আমরা বাচ্চাদের নানামুখী সৃজনশীল ও বাস্তব প্রশিক্ষণে নিয়ে থাকি।
            </p>

            <ul className="flex flex-col gap-3 mt-4">
              {activities.map((act, i) => (
                <li key={i} className="flex items-start gap-2.5 text-xs text-slate-700 dark:text-slate-250">
                  <CheckCircle2 size={16} className="text-emerald-500 mt-0.5 shrink-0" />
                  <span>{act}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-6 grid grid-cols-2 gap-4">
            <img 
              src="https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&q=80&w=400" 
              alt="Activity_1" 
              className="rounded-2xl shadow-xs border border-white/25 object-cover h-44 w-full hover:scale-103 transition-transform"
            />
            <img 
              src="https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&q=80&w=400" 
              alt="Activity_2" 
              className="rounded-2xl shadow-xs border border-white/25 object-cover h-44 w-full mt-6 hover:scale-103 transition-transform"
            />
          </div>
        </div>
      </section>

      {/* 6. Testimonials */}
      <section className="py-16 bg-white dark:bg-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-xl mb-12 mx-auto">
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest font-mono">Parents Feedback</span>
            <h2 className="font-heading text-xl sm:text-2xl font-black text-slate-800 dark:text-white leading-tight mt-1">
              অভিভাবকদের মূল্যবান মতামত (Testimonials)
            </h2>
            <div className="w-12 h-1 bg-emerald-600 dark:bg-emerald-500 rounded-full mx-auto mt-3"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {testimonials.map((t, idx) => (
              <div key={idx} className="bg-slate-50 dark:bg-slate-850 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 flex flex-col gap-4 relative">
                <div className="flex gap-1 text-amber-400">
                  {Array.from({ length: t.rating }).map((_, i) => (
                    <Star key={i} size={14} fill="currentColor" />
                  ))}
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 italic leading-relaxed">
                  "{t.text}"
                </p>
                <div className="flex items-center gap-3 border-t border-slate-200/40 pt-4 mt-2">
                  <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center font-bold text-slate-600 dark:text-slate-350">
                    {t.name[0]}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-800 dark:text-white">{t.name}</h4>
                    <p className="text-[10px] text-slate-400 mt-0.5">{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. Contact CTA Area */}
      <section className="py-12 bg-emerald-600 text-white rounded-t-[2.5rem] dark:bg-emerald-700 mt-16 text-center">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center">
          <Award size={40} className="text-yellow-400 mb-4 animate-float" />
          <h2 className="font-heading text-xl sm:text-3xl font-black">
            আপনার সন্তানকে দ্বীনি শিক্ষায় গড়ে তুলতে আমাদের পাশে থাকুন
          </h2>
          <p className="text-xs md:text-sm text-emerald-100 max-w-xl mt-3 leading-relaxed">
            প্লে থেকে তৃতীয় শ্রেণী পর্যন্ত সীমিত আসনে ভর্তি ফর্ম বিক্রি হচ্ছে। অনলাইনে এখনই রেজিস্ট্রেশন ফি ১৫০০/- টাকা পরিশোধ করে আবেদন করুন।
          </p>
          <div className="flex gap-4 mt-8 flex-wrap justify-center">
            <button
              onClick={() => setTab("admission")}
              className="px-6 py-3.5 bg-yellow-400 hover:bg-yellow-500 text-slate-900 font-bold text-xs rounded-xl shadow-lg transition-all cursor-pointer"
            >
              আজই ভর্তি আবেদন করুন
            </button>
            <button
              onClick={() => setTab("contact")}
              className="px-6 py-3.5 bg-emerald-800 hover:bg-emerald-900 border border-emerald-500/40 text-emerald-100 font-bold text-xs rounded-xl transition-all cursor-pointer"
            >
              যোগাযোগ করুন
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
