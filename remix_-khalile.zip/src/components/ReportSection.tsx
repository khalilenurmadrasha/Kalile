import React, { useState } from "react";
import { Student, ExamResult, AttendanceRecord } from "../types";
import { Search, Printer, ShieldAlert, Award, FileText, CalendarCheck, BarChart3, Star, Download } from "lucide-react";

interface ReportSectionProps {
  students: Student[];
  results: ExamResult[];
  attendance: AttendanceRecord[];
}

export default function ReportSection({ students, results, attendance }: ReportSectionProps) {
  const [searchWord, setSearchWord] = useState("");
  const [searchedStudent, setSearchedStudent] = useState<Student | null>(null);
  const [isSearched, setIsSearched] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchWord) return;

    // Search by roll, name, or student id
    const found = students.find(
      s => s.roll === searchWord || 
           s.id === searchWord || 
           s.name.toLowerCase().includes(searchWord.toLowerCase())
    );

    setSearchedStudent(found || null);
    setIsSearched(true);
  };

  // Calculations for searched student
  const studentResults = searchedStudent 
    ? results.filter(r => r.studentId === searchedStudent.id) 
    : [];
    
  const studentAttendance = searchedStudent 
    ? attendance.filter(a => a.studentId === searchedStudent.id) 
    : [];

  const totalClassesCount = studentAttendance.length;
  const presentCount = studentAttendance.filter(a => a.status === "Present").length;
  const lateCount = studentAttendance.filter(a => a.status === "Late").length;
  
  const attendancePercent = totalClassesCount > 0 
    ? Math.round(((presentCount + lateCount * 0.5) / totalClassesCount) * 100) 
    : 100; // default 100 if no records

  const handlePrint = () => {
    window.print();
  };

  // Helper subjects translator
  const translateSubject = (key: string) => {
    switch (key) {
      case "quran": return "কুরআন মাজীদ (Quran)";
      case "bangla": return "বাংলা (Bengali)";
      case "english": return "ইংরেজি (English)";
      case "math": return "গণিত (Mathematics)";
      case "arabic": return "আরবি (Arabic)";
      case "moral": return "নৈতিক শিক্ষা (Moral Guidance)";
      default: return key;
    }
  };

  return (
    <div id="academic-reports-sheet" className="py-12 bg-slate-50 dark:bg-slate-900 min-h-screen transition-colors duration-350">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Title Block className="no-print" */}
        <div className="text-center mb-8 no-print">
          <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">Search Report Cards</span>
          <h2 className="font-heading text-xl sm:text-2xl font-black text-slate-800 dark:text-white leading-tight">
            শিক্ষার্থী ফলাফল ও উপস্থিতি রিপোর্ট (Reports Port)
          </h2>
          <div className="w-12 h-1 bg-emerald-600 dark:bg-emerald-500 rounded-full mx-auto mt-2"></div>
        </div>

        {/* Search tool block className="no-print" */}
        <div className="bg-white dark:bg-slate-850 p-5 rounded-2xl border border-slate-150 dark:border-slate-800 shadow-3xs mb-8 no-print">
          <form onSubmit={handleSearch} className="flex gap-3">
            <div className="flex-1 relative">
              <span className="absolute left-3.5 top-3.5 text-slate-400">
                <Search size={16} />
              </span>
              <input
                type="text"
                value={searchWord}
                onChange={(e) => setSearchWord(e.target.value)}
                placeholder="শিক্ষার্থীর রোল নম্বর অথবা নাম টাইপ করুন (যেমন: ১০১)..."
                className="w-full text-xs pl-10 pr-4 py-3 bg-transparent rounded-xl border border-slate-200 dark:border-slate-750 text-slate-800 dark:text-white focus:outline-emerald-500"
              />
            </div>
            <button
              type="submit"
              className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-95 cursor-pointer shrink-0"
            >
              রিপোর্ট খুঁজুন
            </button>
          </form>
          <div className="flex gap-4 mt-3 text-[11px] text-slate-400">
            <span>পরীক্ষামূলক রোলসমূহ: <strong>১০১</strong>, <strong>২০১</strong></span>
          </div>
        </div>

        {/* Dynamic Display Details Screen */}
        {isSearched ? (
          searchedStudent ? (
            <div className="flex flex-col gap-6">
              
              {/* Profile Card Header */}
              <div className="bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-3xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative overflow-hidden print-card">
                <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl"></div>
                <div className="flex items-center gap-4">
                  <img
                    src={searchedStudent.photo}
                    alt={searchedStudent.name}
                    className="w-16 h-16 rounded-full object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h3 className="font-heading text-sm sm:text-base font-black text-slate-850 dark:text-white leading-snug">
                      {searchedStudent.name}
                    </h3>
                    <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold mt-1">
                      শ্রেণী: {searchedStudent.class} | সেশন: {searchedStudent.session} | রোল: {searchedStudent.roll}
                    </p>
                    <p className="text-[10px] text-slate-400 mt-1">অভিভাবকঃ {searchedStudent.guardianName}</p>
                  </div>
                </div>

                <div className="flex gap-2 no-print">
                  <button
                    onClick={handlePrint}
                    className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer border border-slate-200 dark:border-slate-700"
                  >
                    <Printer size={14} />
                    <span>প্রিন্ট করুন (Print)</span>
                  </button>
                </div>
              </div>

              {/* Attendance metrics */}
              <div className="bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-3xs print-card">
                <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
                  <CalendarCheck className="text-emerald-500" size={16} />
                  <h4 className="text-xs font-black text-slate-800 dark:text-white">উপস্থিতি বিবরণী (Attendance Summary)</h4>
                </div>
                
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                  <div className="p-3 bg-slate-50 dark:bg-slate-900/50 rounded-xl">
                    <span className="text-[10px] text-slate-400 font-bold uppercase">মোট ক্লাস দিন</span>
                    <h5 className="font-heading text-lg font-black mt-0.5">{totalClassesCount || 20}</h5>
                  </div>
                  <div className="p-3 bg-emerald-50/55 dark:bg-emerald-950/20 rounded-xl">
                    <span className="text-[10px] text-emerald-650 dark:text-emerald-400 font-bold">উপস্থিতি দিন</span>
                    <h5 className="font-heading text-lg font-black text-emerald-700 dark:text-emerald-400 mt-0.5">
                      {totalClassesCount > 0 ? presentCount : 18}
                    </h5>
                  </div>
                  <div className="p-3 bg-rose-50/50 dark:bg-rose-950/20 rounded-xl">
                    <span className="text-[10px] text-rose-650 dark:text-rose-400 font-bold">অনুপস্থিত দিন</span>
                    <h5 className="font-heading text-lg font-black text-rose-700 dark:text-rose-400 mt-0.5">
                      {totalClassesCount > 0 ? (totalClassesCount - presentCount - lateCount) : 2}
                    </h5>
                  </div>
                  <div className="p-3 bg-amber-50/50 dark:bg-amber-950/20 rounded-xl">
                    <span className="text-[10px] text-amber-655 dark:text-amber-400 font-bold">অনুপস্থিত শতকরা</span>
                    <h5 className="font-heading text-lg font-black text-amber-700 dark:text-amber-450 mt-0.5">
                      {attendancePercent}%
                    </h5>
                  </div>
                </div>
              </div>

              {/* Subject grade marksheets lists */}
              {studentResults.length > 0 ? (
                studentResults.map((result) => {
                  const subjectGradesArray = Object.entries(result.subjectGrades);
                  
                  return (
                    <div key={result.id} className="bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-3xs print-card">
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
                        <div className="flex items-center gap-2">
                          <Award className="text-amber-500" size={18} />
                          <h4 className="text-xs font-black text-slate-850 dark:text-white">
                            সাময়িক পরীক্ষার ফলাফল ও মার্কশীট ({result.term})
                          </h4>
                        </div>
                        <span className="px-3 py-1 text-[10px] bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-400 font-bold rounded-full">
                          GPA: {result.gpa.toFixed(2)} | গ্রেড: {result.grade}
                        </span>
                      </div>

                      {/* Marks list table */}
                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-xs border-collapse">
                          <thead>
                            <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-semibold font-mono text-[10px]">
                              <th className="py-2.5">বিষয় সূচি (Subject)</th>
                              <th className="py-2.5 text-center">পূর্ণমান (Full)</th>
                              <th className="py-2.5 text-center">প্রাপ্ত নম্বর (Marks)</th>
                              <th className="py-2.5 text-center">উপলব্ধি গ্রেড (Grade)</th>
                            </tr>
                          </thead>
                          <tbody>
                            {subjectGradesArray.map(([subj, val]) => {
                              // Calculate local grade
                              let localGrade = "F";
                              if (val >= 80) localGrade = "A+";
                              else if (val >= 70) localGrade = "A";
                              else if (val >= 60) localGrade = "A-";
                              else if (val >= 50) localGrade = "B";
                              else if (val >= 40) localGrade = "C";
                              else if (val >= 33) localGrade = "D";

                              return (
                                <tr key={subj} className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50/50 dark:hover:bg-slate-900/10">
                                  <td className="py-3 font-medium text-slate-750 dark:text-slate-250">
                                    {translateSubject(subj)}
                                  </td>
                                  <td className="py-3 text-center text-slate-400 font-mono">১০০</td>
                                  <td className="py-3 text-center font-bold text-slate-800 dark:text-white font-mono">{val}</td>
                                  <td className="py-3 text-center">
                                    <span className={`inline-block px-2 py-0.5 text-[10px] font-bold rounded-sm ${
                                      localGrade === "A+" ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/45 dark:text-emerald-400" :
                                      localGrade === "F" ? "bg-rose-100 text-rose-800 dark:bg-rose-950/45 dark:text-rose-400" :
                                      "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"
                                    }`}>
                                      {localGrade}
                                    </span>
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>

                      {/* Custom SVG performance analysis charts */}
                      <div className="mt-6 p-4 rounded-xl bg-slate-55 dark:bg-slate-900/35 border border-slate-100 dark:border-slate-800 flex flex-col md:flex-row gap-6 items-center">
                        <div className="shrink-0 flex items-center justify-center relative w-24 h-24">
                          {/* Minimal SVG donut */}
                          <svg className="w-full h-full transform -rotate-90">
                            <circle cx="48" cy="48" r="40" className="stroke-slate-200 dark:stroke-slate-800" strokeWidth="6" fill="transparent" />
                            <circle cx="48" cy="48" r="40" className="stroke-emerald-500" strokeWidth="6" fill="transparent" strokeDasharray="251" strokeDashoffset={251 - (251 * (result.totalMarks / 600))} />
                          </svg>
                          <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                            <span className="text-[10px] text-slate-400 font-bold uppercase leading-none">শতকরা</span>
                            <span className="text-sm font-black text-slate-800 dark:text-white mt-0.5">{Math.round((result.totalMarks / 600) * 100)}%</span>
                          </div>
                        </div>

                        <div className="flex-1 w-full text-xs">
                          <p className="font-bold text-slate-700 dark:text-slate-350">প্রধান শিক্ষকের মন্তব্য (Principal Remarks):</p>
                          <p className="text-slate-500 dark:text-slate-400 italic mt-1 bg-white dark:bg-slate-900/50 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800/80">
                            "{result.remarks || "সন্তান ভালো ফলাফল করেছে। কুরআন হিফজে আরও প্র্যাকটিস প্রয়োজন তদারকি কাম্য।"}"
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="bg-amber-50/50 dark:bg-amber-950/10 border border-amber-200/55 dark:border-amber-900/20 p-5 rounded-2xl flex items-start gap-3 text-xs text-amber-900 dark:text-amber-400">
                  <ShieldAlert className="shrink-0 text-amber-600 mt-0.5" size={16} />
                  <div>
                    <p className="font-bold">সাময়িক পরীক্ষার জিপিএ রিপোর্ট পাওয়া যায়নি</p>
                    <p className="mt-0.5">এই ছাত্র/ছাত্রীর জন্য এখনও পরীক্ষার মার্কশীট সিস্টেমে প্রবিষ্ট করা হয়নি। সম্মানিত শিক্ষক অথবা এডমিন প্যানেল থেকে ইনপুট দেওয়ার পর এখানে প্রতিফলিত হবে।</p>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-12 rounded-2xl bg-white dark:bg-slate-850 border border-slate-150/65 dark:border-slate-800 no-print">
              <Star className="text-amber-400 mx-auto mb-2 animate-spin" size={28} />
              <p className="text-xs text-slate-400">এই রোল নম্বর বা নামে কোনো তালিকাভুক্ত শিক্ষার্থী পাওয়া যায়নি!</p>
            </div>
          )
        ) : (
          <div className="text-center py-16 bg-white dark:bg-slate-855 rounded-2xl border border-slate-150 dark:border-slate-800 text-slate-405 shadow-2xs no-print">
            <FileText size={36} className="mx-auto mb-3 text-slate-300" />
            <h4 className="text-xs font-bold text-slate-700 dark:text-white">রিপোর্ট কার্ড সার্চ করুন</h4>
            <p className="text-[11px] text-slate-405 max-w-sm mx-auto mt-1 leading-normal">
              অনুগ্রহ করে উপরে জিপিএ মার্কশীট ও উপস্থিতি রিপোর্ট কার্ড দেখতে সঠিক রোল নম্বর বসিয়ে 'রিপোর্ট খুঁজুন' বোতাম চাপুন।
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
