import React, { useState, useEffect } from "react";
import { User, SystemSettings } from "../types";
import { Moon, Sun, Menu, X, LogIn, User as UserIcon, LogOut, LayoutDashboard, Settings } from "lucide-react";
import { convertToBanglaDigits, getBanglaDayName, getBengaliDate, formatTimeBangla } from "../utils/banglaCalendar";

interface HeaderProps {
  currentTab: string;
  setTab: (tab: string) => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  currentUser: User | null;
  onLogout: () => void;
  onOpenAuth: (mode: "login" | "register") => void;
  settings?: SystemSettings;
}

export default function Header({
  currentTab,
  setTab,
  darkMode,
  setDarkMode,
  currentUser,
  onLogout,
  onOpenAuth,
  settings
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const getFormattedTime = () => {
    const format = settings?.liveClockFormat || "12hour";
    if (format === "bangla") {
      return formatTimeBangla(time);
    }
    const hours = time.getHours();
    const minutes = String(time.getMinutes()).padStart(2, "0");
    const seconds = String(time.getSeconds()).padStart(2, "0");
    
    if (format === "24hour") {
      return `${hours}:${minutes}:${seconds}`;
    }
    // Default 12 hour
    const ampm = hours >= 12 ? "PM" : "AM";
    const displayHours = hours % 12 || 12;
    return `${displayHours}:${minutes}:${seconds} ${ampm}`;
  };

  const getFormattedDate = () => {
    const mode = settings?.dateFormat || "both";
    const gregorianOptions: Intl.DateTimeFormatOptions = { day: "numeric", month: "long", year: "numeric" };
    // English date format
    const englishDateString = time.toLocaleDateString("bn-BD", gregorianOptions); // For localized Bengali Gregorian like ১ জুন ২০২৬
    const englishDateEn = time.toLocaleDateString("en-US", { day: "numeric", month: "long", year: "numeric" });
    
    // Bengali date
    const bDate = getBengaliDate(time);
    const banglaDateString = `${convertToBanglaDigits(bDate.day)} ${bDate.month} ${convertToBanglaDigits(bDate.year)} বঙ্গাব্দ`;
    
    if (mode === "gregorian") {
      return `${convertToBanglaDigits(time.getDate())} ${time.toLocaleDateString("bn-BD", { month: "long" })} ${convertToBanglaDigits(time.getFullYear())} খ্রিঃ`;
    }
    if (mode === "bangla") {
      return banglaDateString;
    }
    // Both
    return `${convertToBanglaDigits(time.getDate())} ${time.toLocaleDateString("bn-BD", { month: "long" })} ${convertToBanglaDigits(time.getFullYear())} খ্রিঃ | ${banglaDateString}`;
  };

  const navItems = [
    { id: "home", labelEn: "Home", labelBn: "হোম" },
    { id: "objectives", labelEn: "Objectives", labelBn: "উদ্দেশ্য ও উপদেশ" },
    { id: "gallery", labelEn: "Gallery", labelBn: "গ্যালারি" },
    { id: "teachers", labelEn: "Teachers", labelBn: "শিক্ষক মণ্ডলী" },
    { id: "students", labelEn: "Students", labelBn: "ছাত্র-ছাত্রী" },
    { id: "reports", labelEn: "Reports", labelBn: "ফলাফল ও রিপোর্ট" },
    { id: "library", labelEn: "Library", labelBn: "লাইব্রেরী" },
    { id: "admission", labelEn: "Admission", labelBn: "অনলাইন ভর্তি" },
    { id: "contact", labelEn: "Contact", labelBn: "যোগাযোগ" }
  ];

  const dynamicNavItems = [
    { id: "home", labelEn: "Home", labelBn: "হোম" },
    ...(currentUser ? [{ id: "dashboard", labelEn: "Dashboard", labelBn: currentUser.role === "admin" ? "এডমিন প্যানেল" : "আমার পোর্টাল" }] : []),
    { id: "objectives", labelEn: "Objectives", labelBn: "উদ্দেশ্য ও উপদেশ" },
    { id: "gallery", labelEn: "Gallery", labelBn: "গ্যালারি" },
    { id: "teachers", labelEn: "Teachers", labelBn: "শিক্ষক মণ্ডলী" },
    { id: "students", labelEn: "Students", labelBn: "ছাত্র-ছাত্রী" },
    { id: "reports", labelEn: "Reports", labelBn: "ফলাফল ও রিপোর্ট" },
    { id: "library", labelEn: "Library", labelBn: "লাইব্রেরী" },
    { id: "admission", labelEn: "Admission", labelBn: "অনলাইন ভর্তি" },
    { id: "contact", labelEn: "Contact", labelBn: "যোগাযোগ" }
  ].filter((item) => {
    if (!currentUser) {
      return item.id !== "dashboard";
    }
    if (currentUser.role === "student" || currentUser.role === "guardian") {
      if (item.id === "students") return false;
      if (item.id === "admission") return false;
    }
    return true;
  });

  const handleNavClick = (tabId: string) => {
    setTab(tabId);
    setMobileMenuOpen(false);
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "admin": return "bg-rose-100 text-rose-800 dark:bg-rose-950/45 dark:text-rose-400 border border-rose-200 dark:border-rose-900";
      case "teacher": return "bg-blue-100 text-blue-800 dark:bg-blue-950/45 dark:text-blue-400 border border-blue-200 dark:border-blue-900";
      case "student": return "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/45 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-900";
      default: return "bg-purple-100 text-purple-800 dark:bg-purple-950/45 dark:text-purple-400 border border-purple-200 dark:border-purple-900";
    }
  };

  const getRoleLabel = (role: string) => {
    switch (role) {
      case "admin": return "সুপার এডমিন";
      case "teacher": return "শিক্ষক";
      case "student": return "শিক্ষার্থী";
      default: return "অভিভাবক";
    }
  };

  const hasBgPhoto = !!settings?.headerBgPhoto;
  const overlayOpacity = settings?.headerOverlayOpacity ? parseInt(settings.headerOverlayOpacity) / 100 : 0.40;

  return (
    <header 
      className="sticky top-0 z-50 glass shadow-xs border-b border-white/20 dark:border-slate-800 transition-colors duration-300 relative"
      style={{
        backgroundColor: settings?.headerBgColor || undefined
      }}
    >
      {/* Background Photo Overlay */}
      {hasBgPhoto && (
        <div 
          className="absolute inset-0 z-0 bg-cover bg-center pointer-events-none"
          style={{ 
            backgroundImage: `url(${settings.headerBgPhoto})`,
          }}
        />
      )}
      {/* Dimmer Overlay on top of the photo option to ensure high readability */}
      {hasBgPhoto && (
        <div 
          className="absolute inset-0 z-0 pointer-events-none bg-slate-950"
          style={{ opacity: overlayOpacity }}
        />
      )}

      {/* Top Ticker Toggles info bar */}
      {(settings?.showLiveClock !== false || settings?.showDate !== false) && (
        <div className="bg-slate-900/10 dark:bg-slate-950/40 border-b border-slate-200/20 dark:border-slate-800/65 py-1.5 px-4 sm:px-6 lg:px-8 relative z-10 text-[11px] sm:text-xs no-print">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-2 font-bold text-slate-800 dark:text-slate-200">
            {/* Live Gregorian & Bangla Date Column */}
            <div className="flex items-center gap-1.5">
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0"></span>
              {settings?.showDate !== false ? (
                <span className="text-[11px] sm:text-xs tracking-tight">
                  আজঃ <span className="text-emerald-700 dark:text-emerald-450">{getBanglaDayName(time.getDay())}</span>, <span className="text-slate-700 dark:text-slate-300">{getFormattedDate()}</span>
                </span>
              ) : (
                <span className="text-[11px]">খলিলে নূর নূরানী কেজি মাদ্রাসা অনলাইন পোর্টাল</span>
              )}
            </div>
            
            {/* Live Clock Time Display Column */}
            {settings?.showLiveClock !== false && (
              <div className="flex items-center gap-2 bg-white/40 dark:bg-slate-850/60 border border-slate-300/30 dark:border-slate-800 px-3 py-0.5 rounded-full shadow-3xs">
                <span className="text-[10px] opacity-80 text-slate-500 dark:text-slate-400">⏰ লাইভ ঘড়িঃ</span>
                <span className="font-mono text-emerald-705 dark:text-emerald-450 font-bold select-none tracking-wide text-[11px]">
                  {getFormattedTime()}
                </span>
              </div>
            )}
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo Brand Sector */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setTab("home")}>
            <div 
              className="bg-white dark:bg-slate-800 flex items-center justify-center text-white font-bold relative group overflow-hidden shrink-0 transition-all border"
              style={{
                width: settings?.logoSize === "small" ? "40px" : settings?.logoSize === "large" ? "54px" : settings?.logoSize === "super-size" ? "64px" : "48px",
                height: settings?.logoSize === "small" ? "40px" : settings?.logoSize === "large" ? "54px" : settings?.logoSize === "super-size" ? "64px" : "48px",
                borderRadius: settings?.logoShape === "square" ? "0px" : settings?.logoShape === "rounded-xl" ? "12px" : settings?.logoShape === "polygon" ? undefined : "50%",
                clipPath: settings?.logoShape === "polygon" ? "polygon(50% 0%, 93% 25%, 93% 75%, 50% 100%, 7% 75%, 7% 25%)" : undefined,
                borderColor: settings?.logoBorderColor || "#10b981",
                boxShadow: settings?.logoGlow !== false ? `0 0 16px ${settings?.logoBorderColor || '#10b981'}` : undefined,
              }}
            >
              {settings?.logoUrl ? (
                <img src={settings.logoUrl} alt="Logo" className="w-full h-full object-cover" />
              ) : (
                <span className="group-hover:scale-110 transition-transform text-2xl">🕌</span>
              )}
              {settings?.logoShape !== "polygon" && (
                <div className="absolute inset-x-0 bottom-0 h-1 bg-amber-400"></div>
              )}
            </div>
            
            <div className="flex flex-col">
              <span className="font-heading text-[11px] sm:text-xs font-semibold text-emerald-700 dark:text-emerald-400 tracking-wide uppercase">
                Khalil Noor Kashemul Uloom
              </span>
              <h1 className="font-heading text-[15px] sm:text-lg font-bold text-slate-800 dark:text-white leading-tight">
                খলিলে নূর নূরানী কেজি মাদ্রাসা
              </h1>
              <span className="text-[10px] text-slate-500 dark:text-slate-400 tracking-tight leading-none no-print">
                ঢেমুশিয়া, চকরিয়া, কক্সবাজার
              </span>
            </div>
          </div>

          {/* Desktop Navigation Link-Set */}
          <nav className="hidden xl:flex items-center gap-1">
            {dynamicNavItems.map((item) => {
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-${item.id}`}
                  onClick={() => handleNavClick(item.id)}
                  className={`px-3 py-2 text-xs font-medium rounded-md transition-all duration-200 cursor-pointer ${
                    isActive
                      ? "bg-emerald-600 text-white shadow-xs"
                      : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-emerald-600 dark:hover:text-emerald-400"
                  }`}
                >
                  <span className="block text-center leading-none font-bold">{item.labelBn}</span>
                  <span className="block text-[9px] text-center opacity-85 mt-0.5 tracking-wider uppercase font-mono">{item.labelEn}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Control Options */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Theme Toggle */}
            <button
              id="theme-toggler"
              onClick={() => setDarkMode(!darkMode)}
              className="p-2.5 rounded-full text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer border border-transparent hover:border-slate-200 dark:hover:border-slate-700"
              aria-label="Toggle Dark Mode"
            >
              {darkMode ? <Sun size={18} className="text-amber-500" /> : <Moon size={18} />}
            </button>

            {/* Auth Operations Profile */}
            {currentUser ? (
              <div className="relative">
                <button
                  id="user-profile-menu-trigger"
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 p-1 bg-white/50 dark:bg-slate-800/50 rounded-full border border-slate-200 dark:border-slate-700 hover:ring-2 hover:ring-emerald-500/30 transition-all cursor-pointer"
                >
                  <div className="w-8 h-8 rounded-full bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-700 dark:text-emerald-400 font-bold overflow-hidden">
                    {currentUser.avatarUrl ? (
                      <img src={currentUser.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                    ) : (
                      <UserIcon size={16} />
                    )}
                  </div>
                  <span className="hidden leading-tight md:block text-xs font-semibold text-slate-700 dark:text-slate-200 max-w-[120px] truncate pr-1 text-left">
                    {currentUser.name.split(" ")[0]}
                  </span>
                </button>

                {userDropdownOpen && (
                  <>
                    <div className="fixed inset-0 z-10" onClick={() => setUserDropdownOpen(false)}></div>
                    <div id="user-details-dropdown" className="absolute right-0 mt-2 w-56 rounded-lg bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 shadow-lg py-2 z-20 animate-float-quick">
                      <div className="px-4 py-2 border-b border-slate-100 dark:border-slate-800">
                        <p className="text-xs text-slate-400">লগইন রোল</p>
                        <span className={`inline-block mt-1 px-2 py-0.5 text-[10px] font-bold rounded-full ${getRoleBadgeColor(currentUser.role)}`}>
                          {getRoleLabel(currentUser.role)}
                        </span>
                        <p className="text-xs font-bold text-slate-700 dark:text-white truncate mt-1.5">{currentUser.name}</p>
                        <p className="text-[10px] font-mono text-slate-400 truncate">{currentUser.email}</p>
                      </div>

                      <button
                        id="user-dashboard-entry"
                        onClick={() => {
                          setTab("dashboard");
                          setUserDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2 cursor-pointer"
                      >
                        <LayoutDashboard size={14} className="text-slate-400" />
                        <span>ড্যাশবোর্ড (Dashboard)</span>
                      </button>

                      <button
                        id="user-logout-trigger"
                        onClick={() => {
                          onLogout();
                          setUserDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2 text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/20 flex items-center gap-2 border-t border-slate-100 dark:border-slate-850 mt-1 cursor-pointer"
                      >
                        <LogOut size={14} />
                        <span>লগআউট (Logout)</span>
                      </button>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-1.5 sm:gap-2">
                <button
                  id="trigger-login-modal"
                  onClick={() => onOpenAuth("login")}
                  className="px-3 sm:px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 dark:bg-emerald-700 dark:hover:bg-emerald-800 text-white text-xs font-semibold flex items-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer"
                >
                  <LogIn size={14} />
                  <span>লগইন</span>
                </button>
                <button
                  id="trigger-register-modal"
                  onClick={() => onOpenAuth("register")}
                  className="hidden sm:inline-flex px-3 sm:px-4 py-2 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-250 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold items-center gap-1.5 transition-all border border-slate-200 dark:border-slate-700 cursor-pointer"
                >
                  <UserIcon size={14} />
                  <span>রেজিস্ট্রেশন</span>
                </button>
              </div>
            )}

            {/* Mobile Menu Toggler */}
            <button
              id="mobile-menu-hamburger"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden p-2 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div id="mobile-navigation-drawer" className="xl:hidden glass border-t border-slate-100 dark:border-slate-800/80 animate-fade-in py-3 px-4 flex flex-col gap-1 shadow-lg max-h-[80vh] overflow-y-auto">
          {dynamicNavItems.map((item) => {
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                id={`mob-nav-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className={`w-full text-left px-4 py-3 rounded-md text-xs font-semibold transition-all ${
                  isActive
                    ? "bg-emerald-600 text-white"
                    : "text-slate-600 dark:text-slate-350 hover:bg-slate-50 dark:hover:bg-slate-850"
                }`}
              >
                <div className="flex justify-between items-center">
                  <span>{item.labelBn}</span>
                  <span className="text-[10px] opacity-75 font-mono uppercase">{item.labelEn}</span>
                </div>
              </button>
            );
          })}
          
          <div className="border-t border-slate-200 dark:border-slate-800 my-2 pt-2">
            {!currentUser && (
              <button
                id="mob-trigger-register"
                onClick={() => {
                  onOpenAuth("register");
                  setMobileMenuOpen(false);
                }}
                className="w-full py-3.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-white text-xs font-bold text-center hover:bg-slate-200 transition-all cursor-pointer"
              >
                নিবন্ধন (Register New Account)
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
