import React, { useState } from "react";
import { Student, User } from "../types";
import { Search, UserPlus, Trash2, Calendar, MapPin, Grid, Layers, ClipboardList, X } from "lucide-react";

interface StudentSectionProps {
  students: Student[];
  onAddStudent: (student: Omit<Student, "id">) => Promise<boolean>;
  onDeleteStudent: (id: string) => Promise<boolean>;
  currentUser: User | null;
}

export default function StudentSection({ students, onAddStudent, onDeleteStudent, currentUser }: StudentSectionProps) {
  const isAdmin = currentUser?.role === "admin" || currentUser?.email === "khalilenurmadrasha65@gmail.com" || currentUser?.email === "hfmdsiddikramu1@gmail.com";
  const [modalOpen, setModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  // Search parameters
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedClass, setSelectedClass] = useState("All");

  // Form parameters
  const [name, setName] = useState("");
  const [roll, setRoll] = useState("");
  const [className, setClassName] = useState("Play");
  const [session, setSession] = useState("২০২৬");
  const [guardianName, setGuardianName] = useState("");
  const [guardianPhone, setGuardianPhone] = useState("");
  const [address, setAddress] = useState("");
  const [gender, setGender] = useState("Male");
  const [dob, setDob] = useState("");
  const [photo, setPhoto] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !guardianPhone || !guardianName) return;

    setLoading(true);
    const defaultPhoto = photo || "https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=150";
    
    const success = await onAddStudent({
      name,
      roll: roll || (students.length + 101).toString(),
      class: className,
      session,
      guardianName,
      guardianPhone,
      address: address || "বাজারপাড়া, ঢেমুশিয়া, চকরিয়া, কক্সবাজার",
      gender,
      dob: dob || "২০২০-০১-০১",
      photo: defaultPhoto
    });

    setLoading(false);
    if (success) {
      setModalOpen(false);
      setName("");
      setRoll("");
      setGuardianName("");
      setGuardianPhone("");
      setAddress("");
      setDob("");
      setPhoto("");
    }
  };

  const filteredStudents = students.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.roll.includes(searchQuery) ||
      student.guardianPhone.includes(searchQuery) ||
      student.guardianName.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesClass = selectedClass === "All" || student.class === selectedClass;
    
    return matchesSearch && matchesClass;
  });

  return (
    <div id="students-directory-screen" className="py-12 bg-slate-50 dark:bg-slate-900 min-h-screen transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title Hub */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest font-mono">Student Directory</span>
            <h2 className="font-heading text-xl sm:text-2xl font-black text-slate-800 dark:text-white leading-tight mt-1">
              ছাত্র-ছাত্রী রেজিস্টার (Student Roster)
            </h2>
            <div className="w-12 h-1 bg-emerald-600 dark:bg-emerald-500 rounded-full mt-3"></div>
          </div>

          {isAdmin && (
            <button
              id="admin-add-student-btn"
              onClick={() => setModalOpen(true)}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <UserPlus size={16} />
              <span>ছাত্র-ছাত্রী নথিভুক্তকরণ</span>
            </button>
          )}
        </div>

        {/* Filter Toolbar controls */}
        <div className="bg-white dark:bg-slate-850 p-4 rounded-2xl border border-slate-150/80 dark:border-slate-800 shadow-3xs flex flex-col sm:flex-row gap-4 items-center justify-between mb-8">
          
          {/* Text input search */}
          <div className="w-full sm:max-w-md relative">
            <span className="absolute left-3.5 top-3.5 text-slate-400">
              <Search size={16} />
            </span>
            <input
              type="text"
              id="student-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="রোল, নাম, অভিভাবকের তথ্যাদি বা মোবাইল লিখে খুঁজুন..."
              className="w-full text-xs pl-10 pr-4 py-3 rounded-xl border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
            />
          </div>

          {/* Class category filters picker */}
          <div className="flex gap-1.5 overflow-x-auto w-full sm:w-auto scrollbar-none pb-1 sm:pb-0">
            {["All", "Play", "Nursery", "First", "Second", "Third"].map((cls) => (
              <button
                key={cls}
                id={`filter-class-${cls}`}
                onClick={() => setSelectedClass(cls)}
                className={`px-3.5 py-2 text-[11px] font-bold rounded-lg transition-all cursor-pointer ${
                  selectedClass === cls
                    ? "bg-emerald-600 text-white shadow-xs"
                    : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-755"
                }`}
              >
                {cls === "All" ? "সকল শ্রেণী" : cls}
              </button>
            ))}
          </div>
        </div>

        {/* Students Roster Grids */}
        {filteredStudents.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredStudents.map((student) => (
              <div
                key={student.id}
                className="bg-white dark:bg-slate-850 rounded-2xl border border-slate-100 dark:border-slate-800 overflow-hidden shadow-3xs hover:shadow-xs transition-all relative flex flex-col group"
              >
                {/* Roll badge upper header */}
                <div className="absolute top-3 left-3 bg-slate-900/40 backdrop-blur-xs text-white text-[9px] font-mono font-bold px-2.5 py-1 rounded-md z-10 uppercase">
                  শ্রেণী: {student.class} | রোল: {student.roll}
                </div>

                {isAdmin && (
                  <button
                    onClick={() => {
                      if (confirm(`আপনি কি ${student.name} এর তথ্য সম্পূর্ণ মুছে ফেলতে চান?`)) {
                        onDeleteStudent(student.id);
                      }
                    }}
                    className="absolute top-3 right-3 p-2 rounded-full bg-rose-500/90 text-white hover:bg-rose-600 transition-all z-10 shadow-md cursor-pointer"
                    title="ডিলিট ছাত্র"
                  >
                    <Trash2 size={12} />
                  </button>
                )}

                {/* Avatar Display */}
                <div className="h-44 bg-slate-100 dark:bg-slate-800 flex items-center justify-center relative overflow-hidden shrink-0">
                  <img
                    src={student.photo}
                    alt={student.name}
                    className="w-full h-full object-cover group-hover:scale-104 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent z-5"></div>
                </div>

                {/* Body Details Card */}
                <div className="p-4 flex-1 flex flex-col gap-3">
                  <div>
                    <h3 className="text-xs sm:text-sm font-black text-slate-850 dark:text-white leading-snug">
                      {student.name}
                    </h3>
                    <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold mt-1">
                      অভিভাবকঃ {student.guardianName}
                    </p>
                  </div>

                  <div className="space-y-1 text-[11px] text-slate-500 dark:text-slate-350 bg-slate-50 dark:bg-slate-900/40 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800 mt-auto">
                    <div className="flex items-center gap-1.5">
                      <Layers size={12} className="text-slate-400 shrink-0" />
                      <span>সেশন: {student.session}</span>
                    </div>
                    {student.dob && (
                      <div className="flex items-center gap-1.5">
                        <Calendar size={12} className="text-slate-400 shrink-0" />
                        <span>জন্মদিন: {student.dob}</span>
                      </div>
                    )}
                    <div className="flex items-start gap-1.5">
                      <MapPin size={12} className="text-slate-400 shrink-0 mt-0.5" />
                      <span className="truncate" title={student.address}>{student.class === "Play" && student.address.includes("মাদ্রাসা") ? "ঢেমুশিয়া, চকরিয়া" : student.address}</span>
                    </div>
                  </div>

                  <div className="flex justify-between items-center text-[10px] border-t border-slate-100 dark:border-slate-800 pt-2.5">
                    <span className="font-mono text-slate-450">{student.gender === "Male" ? "👦 ছাত্র" : "👧 ছাত্রী"}</span>
                    <a href={`tel:${student.guardianPhone}`} className="text-emerald-600 dark:text-emerald-400 hover:underline font-bold font-mono">
                      📞 কল অভিভাবক
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 rounded-2xl bg-white dark:bg-slate-850 border border-slate-150/60 dark:border-slate-800">
            <ClipboardList size={36} className="text-slate-300 mx-auto mb-2" />
            <p className="text-xs text-slate-400">কোন ছাত্র-ছাত্রীর তথ্য খুঁজে পাওয়া যায়নি!</p>
          </div>
        )}

        {/* Modal addition Form */}
        {modalOpen && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl relative">
              
              <button
                onClick={() => setModalOpen(false)}
                className="absolute top-4 p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 right-4 cursor-pointer"
              >
                <X size={18} />
              </button>

              <h3 className="font-heading text-lg font-black text-slate-850 dark:text-white mb-4">
                নতুন ছাত্র-ছাত্রী ভর্তি তালিকাভূক্ত করুন
              </h3>

              <form onSubmit={handleSubmit} className="flex flex-col gap-4 text-xs">
                <div>
                  <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">ছাত্র/ছাত্রীর সম্পূর্ণ নাম *</label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: মোঃ মোস্তফা কামাল"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">শ্রেণী (Class) *</label>
                    <select
                      value={className}
                      onChange={(e) => setClassName(e.target.value)}
                      className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-850 text-slate-800 dark:text-white focus:outline-emerald-500"
                    >
                      <option value="Play">Play</option>
                      <option value="Nursery">Nursery</option>
                      <option value="First">First</option>
                      <option value="Second">Second</option>
                      <option value="Third">Third</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">রোল নম্বর *</label>
                    <input
                      type="text"
                      placeholder="যেমন: ১০৫"
                      value={roll}
                      onChange={(e) => setRoll(e.target.value)}
                      className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">লিঙ্গ *</label>
                    <select
                      value={gender}
                      onChange={(e) => setGender(e.target.value)}
                      className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-850 text-slate-800 dark:text-white focus:outline-emerald-500"
                    >
                      <option value="Male">👦 ছাত্র (Male)</option>
                      <option value="Female">👧 ছাত্রী (Female)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">জন্ম তারিখ</label>
                    <input
                      type="date"
                      value={dob}
                      onChange={(e) => setDob(e.target.value)}
                      className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500 font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">অভিভাবকের নাম (পিতা/মাতা) *</label>
                    <input
                      type="text"
                      required
                      placeholder="যেমন: মোঃ নুরুল আমিন"
                      value={guardianName}
                      onChange={(e) => setGuardianName(e.target.value)}
                      className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">অভিভাবকের মোবাইল নম্বর *</label>
                    <input
                      type="tel"
                      required
                      placeholder="০১৭XXXXXXXX"
                      value={guardianPhone}
                      onChange={(e) => setGuardianPhone(e.target.value)}
                      className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">ছবি আপলোড লিংক (Photo URL)</label>
                  <input
                    type="url"
                    placeholder="https://images.unsplash.com/..."
                    value={photo}
                    onChange={(e) => setPhoto(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">পূর্ণ ঠিকানা</label>
                  <input
                    type="text"
                    placeholder="যেমন: বাজারপাড়া, ঢেমুশিয়া, চকরিয়া, কক্সবাজার"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full mt-2 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer disabled:opacity-50"
                >
                  {loading ? "সংরক্ষণ হচ্ছে..." : "যাচাই ও যোগ করুন"}
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
