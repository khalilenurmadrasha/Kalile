import React from "react";
import { Mail, Phone, MapPin, Globe, Compass, BookOpen, ShieldCheck, Heart } from "lucide-react";

interface FooterProps {
  setTab: (tab: string) => void;
}

export default function Footer({ setTab }: FooterProps) {
  const currentYear = new Date().getFullYear();

  const usefulLinks = [
    { target: "objectives", label: "উদ্দেশ্য ও উপদেশ" },
    { target: "teachers", label: "শিক্ষক পরিচিতি" },
    { target: "library", label: "লাইব্রেরি ও বই" },
    { target: "admission", label: "অনলাইন ভর্তি" },
    { target: "contact", label: "মাদ্রাসা যোগাযোগ" }
  ];

  return (
    <footer className="bg-slate-900 text-slate-300 dark:bg-slate-950 border-t border-emerald-990/25 py-12 px-4 md:px-8 mt-auto">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
        
        {/* Left Hand: About & Branding */}
        <div className="flex flex-col gap-3">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-emerald-600 flex items-center justify-center text-white text-xl">
              🕌
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider">Noorani KG Madrasa</span>
              <span className="text-sm font-bold text-white">খলিলে নূর কাশেমুল উলুম মাদ্রাসা</span>
            </div>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
            কক্সবাজার জেলার চকরিয়া উপজেলার ঐতিহ্যবাহী ঢেমুশিয়া বাজারপাড়ায় অবস্থিত দ্বীনি শিক্ষার এক অনন্য নিকেতন। আধুনিক নূরানী ও কেজি পদ্ধতিতে ইসলামিক নৈতিক শিক্ষার সুসমন্বয়।
          </p>
          <div className="flex gap-3 mt-2">
            <a href="https://facebook.com" target="_blank" rel="noreferrer" className="w-8 h-8 rounded-full bg-slate-800 hover:bg-emerald-600 hover:text-white flex items-center justify-center transition-all text-xs" aria-label="Facebook">fb</a>
            <a href="https://youtube.com" target="_blank" rel="noreferrer" className="w-8 h-8 rounded-full bg-slate-800 hover:bg-red-650 hover:text-white flex items-center justify-center transition-all text-xs" aria-label="YouTube">yt</a>
            <a href="https://telegram.org" target="_blank" rel="noreferrer" className="w-8 h-8 rounded-full bg-slate-800 hover:bg-sky-500 hover:text-white flex items-center justify-center transition-all text-xs" aria-label="Telegram">tg</a>
          </div>
        </div>

        {/* Center Navigation Links */}
        <div className="flex flex-col gap-3 md:pl-8">
          <h3 className="text-white text-xs font-bold uppercase tracking-wider border-l-2 border-emerald-500 pl-2">
            প্রয়োজনীয় লিংক (Quick Links)
          </h3>
          <ul className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
            {usefulLinks.map(link => (
              <li key={link.target}>
                <button
                  onClick={() => setTab(link.target)}
                  className="hover:text-emerald-400 transition-colors py-1 cursor-pointer flex items-center gap-1.5"
                >
                  <BookOpen size={10} className="text-emerald-500" />
                  <span>{link.label}</span>
                </button>
              </li>
            ))}
            <li>
              <a 
                href="/api/downloads/schema" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="hover:text-amber-400 transition-colors py-1 flex items-center gap-1.5 focus:outline-none"
              >
                <ShieldCheck size={10} className="text-amber-400" />
                <span className="underline">MySQL Schema.sql</span>
              </a>
            </li>
          </ul>
        </div>

        {/* Right Contact details */}
        <div className="flex flex-col gap-3">
          <h3 className="text-white text-xs font-bold uppercase tracking-wider border-l-2 border-emerald-500 pl-2">
            যোগাযোগ ও ঠিকানা (Contact)
          </h3>
          <ul className="flex flex-col gap-2.5 text-xs">
            <li className="flex items-start gap-2.5">
              <MapPin size={14} className="text-emerald-500 mt-0.5 shrink-0" />
              <span>ঢেমুশিয়া, বাজারপাড়া, চকরিয়া, কক্সবাজার, বাংলাদেশ</span>
            </li>
            <li className="flex items-center gap-2.5">
              <Phone size={14} className="text-emerald-500 shrink-0" />
              <a href="tel:01812345678" className="hover:text-emerald-400">০১৮১২-৩৪৫৬৭৮</a>
            </li>
            <li className="flex items-center gap-2.5">
              <Mail size={14} className="text-emerald-500 shrink-0" />
              <a href="mailto:khalilenurmadrasha65@gmail.com" className="hover:text-emerald-400">khalilenurmadrasha65@gmail.com</a>
            </li>
            <li className="flex items-center gap-2.5">
              <Globe size={14} className="text-emerald-500 shrink-0" />
              <span>www.khalilenoormadrasha.edu</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto border-t border-slate-800 mt-10 pt-6 text-center text-[11px] text-slate-500 flex flex-col md:flex-row justify-between items-center gap-2">
        <p>© {currentYear} খলিলে নূর কাশেমুল উলুম নূরানী কেজি মাদ্রাসা। সর্বস্বত্ব সংরক্ষিত।</p>
        <p className="flex items-center gap-1">
          <span>দ্বীনি ও আধুনিক শিক্ষার একনিষ্ঠ কাফেলা</span>
          <Heart size={10} className="text-rose-500 animate-pulse fill-rose-500" />
          <span> কক্সবাজার জেলা</span>
        </p>
      </div>
    </footer>
  );
}
