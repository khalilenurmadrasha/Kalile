import React, { useState } from "react";
import { Mail, Phone, MapPin, CheckCircle, Send, Users } from "lucide-react";

interface ContactSectionProps {
  onSendMessage: (msg: { name: string; phone: string; message: string }) => Promise<boolean>;
}

export default function ContactSection({ onSendMessage }: ContactSectionProps) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [message, setMessage] = useState("");
  
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || !message) {
      alert("সব তথ্য সঠিকভাবে পূরণ করুন!");
      return;
    }

    setLoading(true);
    const ok = await onSendMessage({ name, phone, message });
    setLoading(false);
    
    if (ok) {
      setSuccess(true);
      setName("");
      setPhone("");
      setMessage("");
      setTimeout(() => setSuccess(false), 5000);
    }
  };

  return (
    <div id="contact-details-screen" className="py-12 bg-slate-50 dark:bg-slate-900 min-h-screen transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Title */}
        <div className="text-center mb-10">
          <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest font-mono">Get In Touch</span>
          <h2 className="font-heading text-xl sm:text-2xl font-black text-slate-800 dark:text-white leading-tight mt-1">
            মাদ্রাসার অফিস ও যোগাযোগ (Contact Desk)
          </h2>
          <div className="w-12 h-1 bg-emerald-600 dark:bg-emerald-500 rounded-full mx-auto mt-3"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          
          {/* Left panel: Info Details cards set */}
          <div className="md:col-span-5 flex flex-col gap-6">
            
            {/* Quick dials metadata */}
            <div className="bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-3xs flex gap-4 items-start hover:shadow-xs transition-shadow">
              <div className="w-10 h-10 rounded-full bg-emerald-50 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 shrink-0 select-none">
                <MapPin size={18} />
              </div>
              <div className="text-xs">
                <h4 className="font-bold text-slate-800 dark:text-white mb-1">মাদ্রাসার বাস্তব ঠিকানা</h4>
                <p className="text-slate-550 dark:text-slate-350 leading-relaxed">ঢেমুশিয়া, বাজারপাড়া, চকরিয়া, কক্সবাজার, বাংলাদেশ</p>
                <span className="text-[10px] text-slate-400 mt-1 block">ইউনিয়নঃ ঢেমুশিয়া, উপজেলাঃ চকরিয়া</span>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-855 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-3xs flex gap-4 items-start hover:shadow-xs transition-shadow">
              <div className="w-10 h-10 rounded-full bg-emerald-50 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 shrink-0 select-none">
                <Phone size={18} />
              </div>
              <div className="text-xs">
                <h4 className="font-bold text-slate-800 dark:text-white mb-1">জরুরী সাহায্য ও ভর্তি হটলাইন</h4>
                <p className="text-slate-550 dark:text-slate-350 font-mono font-bold hover:text-emerald-555">
                  <a href="tel:01812345678">০১৮১২-৩৪৫৬৭৮</a>
                </p>
                <span className="text-[10px] text-slate-400 mt-1 block">সকাল ৮:০০ টা থেকে বিকাল ৪:০০ টা (শনিবার-বৃহস্পতি)</span>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-855 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-3xs flex gap-4 items-start hover:shadow-xs transition-shadow">
              <div className="w-10 h-10 rounded-full bg-emerald-50 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 shrink-0 select-none">
                <Mail size={18} />
              </div>
              <div className="text-xs">
                <h4 className="font-bold text-slate-800 dark:text-white mb-1">অফিসিয়াল মেইলিং অ্যাকাউন্ট</h4>
                <p className="text-slate-550 dark:text-slate-350 font-mono truncate hover:text-emerald-555">
                  <a href="mailto:khalilenurmadrasha65@gmail.com">khalilenurmadrasha65@gmail.com</a>
                </p>
                <span className="text-[10px] text-slate-400 mt-1 block">যে কোনো তথ্যের জন্য আমাদের ইমেইল প্রেরণ করতে পারেন।</span>
              </div>
            </div>

            {/* Simulated leaflet marker */}
            <div className="bg-white dark:bg-slate-850 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-3xs">
              <div className="h-44 rounded-xl bg-slate-100 dark:bg-slate-900 flex items-center justify-center border text-center border-slate-150 p-4 relative overflow-hidden">
                <div className="absolute top-2 left-2 bg-slate-900/40 text-white text-[9px] font-bold px-2 py-0.5 rounded-sm">মাদ্রাসার ম্যাপ লোকেশন</div>
                <div className="flex flex-col items-center gap-1.5 z-5 text-xs text-slate-500 font-medium">
                  <span>📍 চকোরিয়া চিলখালী ব্রিজ সংলগ্ন ঢেমুশিয়া বাজারপাড়া সড়ক</span>
                  <p className="text-[10px] text-slate-400 max-w-xs leading-normal">চকরিয়া সদর থেকে সিএনজি যোগে সহজের ঢেমুশিয়া বাজারপাড়া মাদ্রাসার সামনে নামা যাবে।</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right panel: Active Message Submission Form */}
          <div className="md:col-span-7 bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-3xs">
            <h3 className="font-heading text-xs sm:text-sm font-black text-slate-800 dark:text-white pb-3 border-b mb-6 border-slate-100 dark:border-slate-800">
              অভিযোগ, পরামর্শ বা অনুসন্ধান পত্র (Send Message)
            </h3>

            {success && (
              <div className="mb-6 p-4 bg-emerald-100 text-emerald-800 dark:bg-emerald-950/20 dark:text-emerald-400 rounded-xl flex items-center gap-2 font-bold text-xs animate-float">
                <CheckCircle size={16} />
                <span>আপনার বার্তাটি সফলভাবে মাদ্রাসা দফতরে প্রেরণ করা হয়েছে। জাজাকাল্লাহ খাইরান!</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="flex flex-col gap-4 text-xs font-medium">
              <div>
                <label className="block text-slate-500 dark:text-slate-400 mb-1">আপনার পূর্ণ নাম *</label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: মুহাম্মদ ইউসুফ"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-500 dark:text-slate-400 mb-1">মোবাইল নম্বর (যোগাযোগের জন্য) *</label>
                <input
                  type="tel"
                  required
                  placeholder="যেমন: ০১XXXXXXXXX"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-500 dark:text-slate-400 mb-1">আপনার মন্তব্য বা বিস্তারিত বার্তা *</label>
                <textarea
                  required
                  rows={4}
                  placeholder="আপনার কাঙ্খিত তথ্য বা প্রশ্ন এখানে সুন্দরভাবে গুছিয়ে লিখুন..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full mt-2 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Send size={14} />
                <span>{loading ? "প্রেরণ হচ্ছে..." : "বার্তাটি প্রেরণ করুন"}</span>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
