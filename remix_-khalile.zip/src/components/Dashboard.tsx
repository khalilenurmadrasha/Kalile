import React, { useState } from "react";
import { 
  User, Student, Teacher, Notice, LibraryBook, AttendanceRecord, ExamResult, AdmissionForm, SystemSettings, ContactMessage 
} from "../types";
import { 
  BarChart, Users, BookOpen, GraduationCap, DollarSign, ListTodo, Plus, CalendarRange, Lock, 
  Trash2, Mail, Send, CheckSquare, Download, Upload, ClipboardCheck, Award, CreditCard, Settings, RefreshCw, X,
  Database, ShieldCheck, ExternalLink
} from "lucide-react";

interface DashboardProps {
  currentUser: User;
  settings: SystemSettings;
  students: Student[];
  teachers: Teacher[];
  books: LibraryBook[];
  notices: Notice[];
  admissions: AdmissionForm[];
  attendance: AttendanceRecord[];
  results: ExamResult[];
  payments: any[];
  contacts: ContactMessage[];
  onAddNotice: (notice: { title: string; content: string; category: string; important: boolean }) => Promise<boolean>;
  onDeleteNotice: (id: string) => Promise<boolean>;
  onAddResult: (res: Omit<ExamResult, "id" | "createdAt">) => Promise<boolean>;
  onAddStudent: (stud: Omit<Student, "id">) => Promise<boolean>;
  onDeleteStudent: (id: string) => Promise<boolean>;
  onAddAttendanceBulk: (recs: any[]) => Promise<boolean>;
  onImportCSVStudents: (csvText: string) => Promise<boolean>;
  onReadContact: (id: string) => Promise<boolean>;
  onUpdateSettings: (setts: Partial<SystemSettings>) => Promise<boolean>;
  onAddPayment?: (payObj: any) => Promise<boolean>;
}

export default function Dashboard({
  currentUser,
  settings,
  students,
  teachers,
  books,
  notices,
  admissions,
  attendance,
  results,
  payments,
  contacts,
  onAddNotice,
  onDeleteNotice,
  onAddResult,
  onAddStudent,
  onDeleteStudent,
  onAddAttendanceBulk,
  onImportCSVStudents,
  onReadContact,
  onUpdateSettings,
  onAddPayment
}: DashboardProps) {
  const isAdmin = currentUser.email === "khalilenurmadrasha65@gmail.com";
  const isGuardianOrStudent = currentUser.role === "guardian" || currentUser.role === "student";
  const [activeTab, setActiveTab] = useState<string>(
    isAdmin 
      ? "overview" 
      : currentUser.role === "teacher"
        ? "teacher-db"
        : currentUser.role === "student"
          ? "student-db"
          : "guardian-db"
  );

  // Admin and teacher form states
  const [noticeTitle, setNoticeTitle] = useState("");
  const [noticeContent, setNoticeContent] = useState("");
  const [noticeCategory, setNoticeCategory] = useState("General");
  const [noticeImportant, setNoticeImportant] = useState(false);

  // Result entry states
  const [studentId, setStudentId] = useState("");
  const [examTerm, setExamTerm] = useState<any>("First Term");
  const [quran, setQuran] = useState(80);
  const [bangla, setBangla] = useState(70);
  const [english, setEnglish] = useState(70);
  const [math, setMath] = useState(80);
  const [arabic, setArabic] = useState(80);
  const [moral, setMoral] = useState(85);
  const [remarks, setRemarks] = useState("");

  // Attendance submission states
  const [attendanceClass, setAttendanceClass] = useState("Play");
  const [attendanceRecords, setAttendanceRecords] = useState<{ [key: string]: "Present" | "Absent" | "Late" }>({});

  // Settings states
  const [webName, setWebName] = useState(settings.websiteName);
  const [webBangla, setWebBangla] = useState(settings.banglaName);
  const [webAddr, setWebAddr] = useState(settings.address);
  const [webPhone, setWebPhone] = useState(settings.phone);
  const [logoUrl, setLogoUrl] = useState(settings.logoUrl || "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=120");
  const [logoSize, setLogoSize] = useState<"small" | "medium" | "large" | "super-size">(settings.logoSize || "medium");
  const [logoShape, setLogoShape] = useState<"circle" | "square" | "rounded-xl" | "polygon">(settings.logoShape || "circle");
  const [logoBorderColor, setLogoBorderColor] = useState(settings.logoBorderColor || "#10b981");
  const [logoGlow, setLogoGlow] = useState<boolean>(settings.logoGlow !== false);
  const [webBgColor, setWebBgColor] = useState(settings.webBgColor || "#f8fafc");
  const [headerBgColor, setHeaderBgColor] = useState(settings.headerBgColor || "#0f172a");
  const [headerBgPhoto, setHeaderBgPhoto] = useState(settings.headerBgPhoto || "");
  const [headerOverlayOpacity, setHeaderOverlayOpacity] = useState(settings.headerOverlayOpacity || "40");
  const [primaryAccentColor, setPrimaryAccentColor] = useState(settings.primaryAccentColor || "#059669");
  const [secondaryAccentColor, setSecondaryAccentColor] = useState(settings.secondaryAccentColor || "#d97706");
  const [sectionBgColor, setSectionBgColor] = useState(settings.sectionBgColor || "#ffffff");
  const [sectionTextColor, setSectionTextColor] = useState(settings.sectionTextColor || "#334155");
  const [sectionTitleColor, setSectionTitleColor] = useState(settings.sectionTitleColor || "#0f172a");
  const [animationStyle, setAnimationStyle] = useState<"disabled" | "smooth" | "bouncy" | "ultra-premium">(settings.animationStyle || "smooth");
  const [animationDuration, setAnimationDuration] = useState(settings.animationDuration || "0.3s");
  const [fontFamily, setFontFamily] = useState<"inter" | "noto-bengali" | "space-grotesk" | "playfair" | "outfit" | "mono">(settings.fontFamily || "noto-bengali");
  const [fontSizeLevel, setFontSizeLevel] = useState<"small" | "medium" | "large" | "extra-large">(settings.fontSizeLevel || "medium");
  const [premiumStyleMode, setPremiumStyleMode] = useState<"flat" | "glass" | "bordered" | "glowing" | "minimalist">(settings.premiumStyleMode || "glass");
  const [headingWeight, setHeadingWeight] = useState<"regular" | "semibold" | "bold" | "black">(settings.headingWeight || "bold");
  const [showLiveClock, setShowLiveClock] = useState<boolean>(settings.showLiveClock !== false);
  const [liveClockFormat, setLiveClockFormat] = useState<"12hour" | "24hour" | "bangla">(settings.liveClockFormat || "12hour");
  const [showDate, setShowDate] = useState<boolean>(settings.showDate !== false);
  const [dateFormat, setDateFormat] = useState<"gregorian" | "bangla" | "both">(settings.dateFormat || "both");

  // CSV Importer State
  const [csvRawText, setCsvRawText] = useState("");
  const [csvUploadOpen, setCsvUploadOpen] = useState(false);

  // Teacher Workspace State
  const [teacherSelectedClass, setTeacherSelectedClass] = useState("Play");

  // Guardian Tuition Fee payment Form States
  const [payFormStudentName, setPayFormStudentName] = useState("");
  const [payFormClass, setPayFormClass] = useState("Play");
  const [payFormType, setPayFormType] = useState("Tuition Fee");
  const [payFormMethod, setPayFormMethod] = useState("bKash");
  const [payFormAmount, setPayFormAmount] = useState<number>(800);
  const [payFormTxid, setPayFormTxid] = useState("");
  const [paySuccessMsg, setPaySuccessMsg] = useState("");

  // Guardian feedback message States
  const [guardianMessageText, setGuardianMessageText] = useState("");
  const [guardianInquirySubmitSuccess, setGuardianInquirySubmitSuccess] = useState(false);

  // Calculations for Admin Widgets
  const totalStudents = students.length;
  const totalTeachers = teachers.length;
  const totalBooks = books.reduce((acc, b) => acc + b.totalQuantity, 0);
  const totalRevenue = payments.reduce((acc, p) => acc + Number(p.amount), 0);
  const totalPaymentsCount = payments.length;

  const handleCreateNotice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!noticeTitle || !noticeContent) return;
    const ok = await onAddNotice({
      title: noticeTitle,
      content: noticeContent,
      category: noticeCategory,
      important: noticeImportant
    });
    if (ok) {
      setNoticeTitle("");
      setNoticeContent("");
      setNoticeImportant(false);
    }
  };

  const handleCreateResult = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentId) {
      alert("দয়া করে শিক্ষার্থী আইডি নির্বাচন করুন!");
      return;
    }
    const student = students.find(s => s.id === studentId);
    if (!student) return;

    const totalMarks = Number(quran) + Number(bangla) + Number(english) + Number(math) + Number(arabic) + Number(moral);
    // GPA conversion
    const avg = totalMarks / 6;
    let localGrade = "F";
    let subGpa = 0.0;
    if (avg >= 80) { localGrade = "A+"; subGpa = 5.0; }
    else if (avg >= 70) { localGrade = "A"; subGpa = 4.0; }
    else if (avg >= 60) { localGrade = "A-"; subGpa = 3.5; }
    else if (avg >= 50) { localGrade = "B"; subGpa = 3.0; }
    else if (avg >= 40) { localGrade = "C"; subGpa = 2.0; }
    else if (avg >= 33) { localGrade = "D"; subGpa = 1.0; }

    const ok = await onAddResult({
      studentId,
      studentName: student.name,
      roll: student.roll,
      class: student.class,
      term: examTerm,
      subjectGrades: {
        quran: Number(quran),
        bangla: Number(bangla),
        english: Number(english),
        math: Number(math),
        arabic: Number(arabic),
        moral: Number(moral)
      },
      totalMarks,
      grade: localGrade,
      gpa: subGpa,
      remarks: remarks || "পরীক্ষায় সন্তোষজনক অংশগ্রহণ।"
    });

    if (ok) {
      alert("শিক্ষার্থীর পরীক্ষার জিপিএ মার্কশীট ড্যাশবোর্ডে সফলভাবে সংরক্ষণ হয়েছে!");
      setStudentId("");
      setRemarks("");
    }
  };

  const handleAttendanceBulkSubmit = async () => {
    const classStudents = students.filter(s => s.class === attendanceClass);
    const recordsToPost = classStudents.map(student => ({
      studentId: student.id,
      studentName: student.name,
      roll: student.roll,
      class: student.class,
      status: attendanceRecords[student.id] || "Present"
    }));

    const ok = await onAddAttendanceBulk(recordsToPost);
    if (ok) {
      alert(`${attendanceClass} শ্রেণীর শিক্ষার্থীদের আজকের দৈনিক হাজিরা সফলভাবে ডাটাবেসে সেভ হয়েছে!`);
    }
  };

  const handleImportCSVData = async () => {
    if (!csvRawText.trim()) return;
    const ok = await onImportCSVStudents(csvRawText);
    if (ok) {
      alert("CSV ফাইল থেকে নতুন শিক্ষার্থীদের রোস্টার ডাটাবেসে সফলভাবে ইম্পোর্ট করা হয়েছে!");
      setCsvRawText("");
      setCsvUploadOpen(false);
    }
  };

  // CSV Export utility
  const handleExportCSV = () => {
    let headers = "Name,Roll,Class,GuardianName,GuardianPhone,Address\n";
    const body = students.map(s => 
      `"${s.name}","${s.roll}","${s.class}","${s.guardianName}","${s.guardianPhone}","${s.address}"`
    ).join("\n");
    
    const blob = new Blob([headers + body], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.setAttribute("download", "madrasha_students.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleSaveSettings = async () => {
    const ok = await onUpdateSettings({
      websiteName: webName,
      banglaName: webBangla,
      address: webAddr,
      phone: webPhone,
      logoUrl,
      logoSize,
      logoShape,
      logoBorderColor,
      logoGlow,
      webBgColor,
      headerBgColor,
      headerBgPhoto,
      headerOverlayOpacity,
      primaryAccentColor,
      secondaryAccentColor,
      sectionBgColor,
      sectionTextColor,
      sectionTitleColor,
      animationStyle,
      animationDuration,
      fontFamily,
      fontSizeLevel,
      premiumStyleMode,
      headingWeight,
      showLiveClock,
      liveClockFormat,
      showDate,
      dateFormat
    });
    if (ok) {
      alert("মাদ্রাসার সাধারণ কন্ট্রোল ওয়েবসাইট সেটিংস সফলভাবে আপডেট ও সেভ হয়েছে!");
    }
  };

  // Role based dashboards render calculations
  const associatedStudent = students.find(s => s.id === currentUser.id || s.guardianPhone === currentUser.phone);
  
  const studentGrades = associatedStudent 
    ? results.filter(r => r.studentId === associatedStudent.id) 
    : [];
    
  const studentAttendanceList = associatedStudent 
    ? attendance.filter(a => a.studentId === associatedStudent.id) 
    : [];

  return (
    <div id="madrasha-dash-hub" className="py-10 bg-slate-50 dark:bg-slate-900 min-h-screen transition-colors duration-350">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">

        {/* Dashboard Upper Tab Header bar */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-200 dark:border-slate-800 pb-5 mb-8 gap-4">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-500 dark:text-emerald-400 font-mono tracking-widest bg-emerald-100 dark:bg-emerald-950 px-2 py-0.5 rounded-md">
              {currentUser.role === "admin" ? "Super Admin System" : currentUser.role === "teacher" ? "Teacher Portal" : currentUser.role === "student" ? "Student Academic Portal" : "Guardian Portal"}
            </span>
            <h2 className="font-heading text-lg sm:text-xl font-bold text-slate-850 dark:text-white leading-snug mt-1 flex items-center gap-1.5">
              <span>ব্যবহারকারীঃ {currentUser.name}</span>
            </h2>
            <p className="text-[10px] font-mono text-slate-400 mt-1">{currentUser.email}</p>
          </div>

          {/* Tab Options depending on Role */}
          {isAdmin ? (
            <div className="flex flex-wrap gap-1 bg-white dark:bg-slate-850 p-1.5 rounded-xl border border-slate-100 dark:border-slate-800 shadow-3xs max-w-full font-heading">
              {[
                { id: "overview", label: "সারসংক্ষেপ" },
                { id: "notices", label: "নোটিশ বোর্ড" },
                { id: "results", label: "পরীক্ষার রেজাল্ট" },
                { id: "attendance", label: "রোল হাজিরা" },
                { id: "students", label: "শিক্ষার্থী রোস্টার" },
                { id: "contacts", label: "ফিডব্যাক ইনবক্স" },
                { id: "settings", label: "সেটিংস আপডেট" }
              ].map(tb => (
                <button
                  key={tb.id}
                  id={`dash-tab-${tb.id}`}
                  onClick={() => setActiveTab(tb.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    activeTab === tb.id ? "bg-emerald-600 text-white shadow-xs" : "text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-emerald-600"
                  }`}
                >
                  {tb.label}
                </button>
              ))}
            </div>
          ) : currentUser.role === "teacher" ? (
            <div className="flex flex-wrap gap-1 bg-white dark:bg-slate-855 p-1.5 rounded-xl border border-slate-100 dark:border-slate-800 shadow-3xs max-w-full font-heading">
              {[
                { id: "teacher-db", label: "মাস্টার ড্যাশবোর্ড" },
                { id: "teacher-attendance", label: "রোল হাজিরা এন্ট্রি" },
                { id: "teacher-results", label: "ফলাফল মূল্যায়ন" }
              ].map(tb => (
                <button
                  key={tb.id}
                  id={`dash-tab-${tb.id}`}
                  onClick={() => setActiveTab(tb.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    activeTab === tb.id ? "bg-emerald-600 text-white shadow-xs" : "text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-emerald-600"
                  }`}
                >
                  {tb.label}
                </button>
              ))}
            </div>
          ) : currentUser.role === "guardian" ? (
            <div className="flex flex-wrap gap-1 bg-white dark:bg-slate-855 p-1.5 rounded-xl border border-slate-100 dark:border-slate-800 shadow-3xs max-w-full font-heading">
              {[
                { id: "guardian-db", label: "সন্তানের অগ্রগতি কার্ড" },
                { id: "guardian-payments", label: "বেতন ও ফি পরিশোধ" },
                { id: "guardian-inquiry", label: "মাদ্রাসা যোগাযোগ" }
              ].map(tb => (
                <button
                  key={tb.id}
                  id={`dash-tab-${tb.id}`}
                  onClick={() => setActiveTab(tb.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    activeTab === tb.id ? "bg-emerald-600 text-white shadow-xs" : "text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-emerald-600"
                  }`}
                >
                  {tb.label}
                </button>
              ))}
            </div>
          ) : (
            <div className="flex flex-wrap gap-1 bg-white dark:bg-slate-855 p-1.5 rounded-xl border border-slate-100 dark:border-slate-800 shadow-3xs max-w-full font-heading">
              {[
                { id: "student-db", label: "আমার ড্যাশবোর্ড" },
                { id: "student-notices", label: "মাদ্রাসা নোটিশ বোর্ড" }
              ].map(tb => (
                <button
                  key={tb.id}
                  id={`dash-tab-${tb.id}`}
                  onClick={() => setActiveTab(tb.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    activeTab === tb.id ? "bg-emerald-600 text-white shadow-xs" : "text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-emerald-600"
                  }`}
                >
                  {tb.label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ------------------ ADMIN SYSTEM PANELS ------------------ */}
        {isAdmin && (
          <div className="flex flex-col gap-8">
            
            {/* OVERVIEW PANEL */}
            {activeTab === "overview" && (
              <div className="flex flex-col gap-8">
                
                {/* Metric Summary counters */}
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                  <div className="bg-white dark:bg-slate-850 p-4 rounded-xl border border-slate-100 dark:border-slate-800 shadow-3xs text-center flex flex-col justify-center">
                    <Users size={20} className="text-emerald-500 mx-auto mb-2 animate-pulse" />
                    <span className="text-[10px] text-slate-400 font-bold uppercase">মোট ছাত্র-ছাত্রী</span>
                    <h3 className="font-heading text-lg font-black mt-1">{totalStudents}</h3>
                  </div>
                  <div className="bg-white dark:bg-slate-850 p-4 rounded-xl border border-slate-100 dark:border-slate-800 shadow-3xs text-center flex flex-col justify-center">
                    <GraduationCap size={20} className="text-teal-500 mx-auto mb-2" />
                    <span className="text-[10px] text-slate-400 font-bold uppercase">মোট শিক্ষক</span>
                    <h3 className="font-heading text-lg font-black mt-1">{totalTeachers}</h3>
                  </div>
                  <div className="bg-white dark:bg-slate-850 p-4 rounded-xl border border-slate-100 dark:border-slate-800 shadow-3xs text-center flex flex-col justify-center">
                    <BookOpen size={20} className="text-pink-500 mx-auto mb-2" />
                    <span className="text-[10px] text-slate-400 font-bold uppercase">মোট লাইব্রেরি বই</span>
                    <h3 className="font-heading text-lg font-black mt-1">{totalBooks}</h3>
                  </div>
                  <div className="bg-white dark:bg-slate-850 p-4 rounded-xl border border-slate-100 dark:border-slate-800 shadow-3xs text-center flex flex-col justify-center">
                    <CreditCard size={20} className="text-blue-500 mx-auto mb-2" />
                    <span className="text-[10px] text-slate-400 font-bold uppercase">অনলাইন আবেদন সমূহ</span>
                    <h3 className="font-heading text-lg font-black mt-1">{admissions.length}</h3>
                  </div>
                  <div className="bg-white dark:bg-slate-850 p-4 rounded-xl border border-slate-100 dark:border-slate-850 shadow-3xs text-center flex flex-col justify-center col-span-2 md:col-span-1">
                    <DollarSign size={20} className="text-amber-500 mx-auto mb-2 animate-bounce" />
                    <span className="text-[10px] text-slate-400 font-semibold uppercase">অর্জিত মোট রাজস্ব</span>
                    <h3 className="font-heading text-base font-black mt-1 text-emerald-650 font-mono">{totalRevenue} BDT</h3>
                  </div>
                </div>

                {/* Firebase Cloud Integration Panel */}
                <div id="firebase-cloud-status-card" className="bg-slate-900 border border-emerald-500/25 text-slate-100 p-5 rounded-2xl shadow-sm">
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-4 border-b border-slate-800">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="relative flex h-2 w-2">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                        </span>
                        <h3 className="font-heading font-black text-white flex items-center gap-1.5 text-sm md:text-base">
                          <Database size={18} className="text-emerald-400" />
                          <span>ফায়ারবেস ক্লাউড ডাটাবেস কন্ট্রোল প্যানেল (Firebase Cloud Status)</span>
                        </h3>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1 max-w-2xl font-medium">
                        আপনার খলিলে নূর মাদ্রাসার সমস্ত ডাটা রিয়েল-টাইমে ফায়ারবেস ক্লাউড স্টোরেজে (Cloud Firestore) সিঙ্ক ও স্থায়ীভাবে সংরক্ষিত হচ্ছে। নিরাপত্তার জন্য জিরো-ট্রাস্ট সিকিউরিটি রুলস (Zero-Trust Security Rules) সফলভাবে মোতায়েন করা হয়েছে।
                      </p>
                    </div>
                    <div className="flex flex-col items-end text-right">
                      <span className="text-[10px] font-bold text-slate-400 bg-slate-800 px-2 py-0.5 rounded-sm font-mono uppercase tracking-wider">
                        STATUS: ACTIVE
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-b border-slate-800/60 pb-4 mb-4">
                    <div className="text-[11px] space-y-1.5">
                      <div className="flex justify-between border-b border-slate-800/40 pb-1">
                        <span className="text-slate-400">প্রজেক্ট আইডি (Project ID):</span>
                        <span className="font-mono font-bold text-white select-all">gen-lang-client-0731931417</span>
                      </div>
                      <div className="flex justify-between border-b border-slate-800/40 pb-1">
                        <span className="text-slate-400">ডাটাবেস আইডি (Database ID):</span>
                        <span className="font-mono font-bold text-white select-all">ai-studio-cd189aa8-52fe-4fa7-8c94-d53bd489fb49</span>
                      </div>
                    </div>
                    <div className="text-[11px] space-y-1.5">
                      <div className="flex justify-between border-b border-slate-800/40 pb-1">
                        <span className="text-slate-400">সিকিউরিটি রুলস সংস্করণ (Security Rules):</span>
                        <span className="font-mono font-bold text-emerald-400">rules_version = '2';</span>
                      </div>
                      <div className="flex justify-between border-b border-slate-800/40 pb-1">
                        <span className="text-slate-400">মোতায়েন স্থিতি (Deployment):</span>
                        <span className="font-mono font-bold text-emerald-400 flex items-center gap-1">
                          <ShieldCheck size={12} /> Successfully Deployed
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Firebase Action Links */}
                  <div>
                    <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-slate-400 block mb-2">ফায়ারবেস কনসোল ড্যাশবোর্ড লিংক সমূহ (Firebase Official Links):</span>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <a 
                        href="https://console.firebase.google.com/project/gen-lang-client-0731931417/firestore/databases/ai-studio-cd189aa8-52fe-4fa7-8c94-d53bd489fb49/data"
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center justify-between gap-1 bg-emerald-600/10 border border-emerald-500/20 hover:bg-emerald-600/20 text-emerald-400 px-3 py-2 rounded-xl text-[11px] font-bold transition-all"
                      >
                        <span className="flex items-center gap-1.5">📂 Cloud Firestore Database</span>
                        <ExternalLink size={12} />
                      </a>
                      <a 
                        href="https://console.firebase.google.com/project/gen-lang-client-0731931417/authentication/users"
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center justify-between gap-1 bg-amber-600/10 border border-amber-500/20 hover:bg-amber-600/20 text-amber-400 px-3 py-2 rounded-xl text-[11px] font-bold transition-all"
                      >
                        <span className="flex items-center gap-1.5">👥 Firebase Authentication</span>
                        <ExternalLink size={12} />
                      </a>
                      <a 
                        href="https://console.firebase.google.com/project/gen-lang-client-0731931417/firestore/rules"
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center justify-between gap-1 bg-blue-600/10 border border-blue-500/20 hover:bg-blue-600/20 text-blue-400 px-3 py-2 rounded-xl text-[11px] font-bold transition-all"
                      >
                        <span className="flex items-center gap-1.5">🛡️ Firestore Security Rules</span>
                        <ExternalLink size={12} />
                      </a>
                    </div>
                  </div>
                </div>

                {/* Grid Lists of recent Admission applications */}
                <div className="bg-white dark:bg-slate-850 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-3xs">
                  <div className="pb-3 border-b mb-4 flex justify-between items-center text-xs">
                    <h3 className="font-heading font-black text-slate-850 dark:text-white flex items-center gap-1">
                      <CreditCard size={16} className="text-emerald-600" />
                      <span>সাম্প্রতিক ভর্তি ও ফি পেমেন্ট ইতিহাস (Payment Logs)</span>
                    </h3>
                    <span className="text-slate-450">অ্যাফেক্টঃ {payments.length} রেকর্ড</span>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b border-slate-150 dark:border-slate-800 text-slate-400 font-bold font-mono text-[10px] uppercase">
                          <th className="py-2">শিক্ষাথী</th>
                          <th className="py-2">উৎস শ্রেণী</th>
                          <th className="py-2">পদ্ধতি</th>
                          <th className="py-2">পেমেন্ট টাইপ</th>
                          <th className="py-2">ট্রানজেকশন TxID</th>
                          <th className="py-2 text-right">টাকা (Amount)</th>
                          <th className="py-2 text-center">স্থিতি</th>
                        </tr>
                      </thead>
                      <tbody>
                        {payments.map((p, i) => (
                          <tr key={i} className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50/50">
                            <td className="py-3 font-semibold text-slate-800 dark:text-white">{p.studentName}</td>
                            <td className="py-3 font-mono text-slate-400">{p.class}</td>
                            <td className="py-3">{p.method}</td>
                            <td className="py-3 italic">{p.type}</td>
                            <td className="py-3 font-mono font-bold text-slate-450 select-all">{p.txid}</td>
                            <td className="py-3 text-right font-bold text-slate-700 dark:text-white font-mono">{p.amount} BDT</td>
                            <td className="py-3 text-center">
                              <span className="px-2 py-0.5 rounded-sm bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400 text-[10px] font-bold">
                                {p.status || "Verified"}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* NOTICES LIST PANEL */}
            {activeTab === "notices" && (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
                
                {/* Form Editor create notices */}
                <form onSubmit={handleCreateNotice} className="md:col-span-5 bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-3xs flex flex-col gap-4 text-xs font-semibold">
                  <h3 className="font-heading font-black text-slate-850 dark:text-white border-b pb-3 mb-2">
                    নতুন নোটিশ বা মাদ্রাসা ঘোষণা জারি করুন
                  </h3>
                  
                  <div>
                    <label className="block text-slate-500 mb-1">নোটিশের শিরোনাম *</label>
                    <input
                      type="text"
                      required
                      placeholder="যেমন: প্রথম সাময়িক পরীক্ষা প্রদানের ঘোষণা"
                      value={noticeTitle}
                      onChange={(e) => setNoticeTitle(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-lg border border-slate-200 dark:border-slate-755 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-500 mb-1">বিভাগ টাইপ/ক্যাটাগরি</label>
                      <select
                        value={noticeCategory}
                        onChange={(e) => setNoticeCategory(e.target.value)}
                        className="w-full text-xs p-2.5 rounded-lg border border-slate-205 bg-white dark:bg-slate-850 text-slate-850 dark:text-white focus:outline-emerald-500"
                      >
                        <option value="General">General (সাধারণ)</option>
                        <option value="Exam">Exam (পরীক্ষা)</option>
                        <option value="Holiday">Holiday (ছুটি)</option>
                        <option value="Admission">Admission (ভর্তি)</option>
                      </select>
                    </div>

                    <div className="flex items-center gap-1.5 select-none pt-6 pl-1">
                      <input
                        type="checkbox"
                        id="noti-important"
                        checked={noticeImportant}
                        onChange={(e) => setNoticeImportant(e.target.checked)}
                        className="rounded text-amber-500 focus:ring-amber-500"
                      />
                      <label htmlFor="noti-important" className="text-slate-500 font-bold text-[10px]">অত্যধিক গুরুত্বপূর্ণ / ব্যানার</label>
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-500 mb-1">বিস্তারিত বিবরণ *</label>
                    <textarea
                      required
                      rows={5}
                      placeholder="সকল অভিভাবক ও শিক্ষার্থীদের অবগতির জন্য জানানো যাচ্ছে যে..."
                      value={noticeContent}
                      onChange={(e) => setNoticeContent(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-lg border border-slate-200 dark:border-slate-755 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full mt-2 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Plus size={14} />
                    <span>নতুন নোটিশ প্রকাশ করুন</span>
                  </button>
                </form>

                {/* List of general notices */}
                <div className="md:col-span-7 bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-100 dark:border-slate-850 shadow-3xs flex flex-col gap-4">
                  <h3 className="font-heading font-black text-slate-850 dark:text-white border-b pb-3">
                    প্রকাশিত নোটিশ সমূহ (Notice Board)
                  </h3>

                  <div className="flex flex-col gap-4 max-h-[500px] overflow-y-auto pr-1">
                    {notices.map((noti) => (
                      <div key={noti.id} className="p-4 rounded-xl border border-slate-100 dark:border-slate-800 hover:border-slate-200 dark:hover:border-slate-700 hover:bg-slate-55/40 relative flex gap-3 text-xs shrink-0">
                        {noti.important && (
                          <span className="absolute top-3 right-12 text-[9px] bg-amber-500 text-slate-900 font-black px-2 py-0.5 rounded-md uppercase">
                            জরুরী
                          </span>
                        )}
                        <button
                          onClick={() => {
                            if (confirm("এই নোটিশটি ডিলিট করতে চান?")) onDeleteNotice(noti.id);
                          }}
                          className="absolute top-3.5 right-4 text-slate-400 hover:text-rose-500 cursor-pointer"
                          title="মুছে দিন"
                        >
                          <Trash2 size={13} />
                        </button>

                        <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-900 flex items-center justify-center text-lg shrink-0 font-bold font-mono">
                          📢
                        </div>

                        <div>
                          <span className="text-[10px] pr-2 text-slate-400 font-mono font-bold uppercase border-r tracking-wider">{noti.category}</span>
                          <span className="text-[10px] pl-2 text-slate-400 font-mono font-semibold">{noti.date}</span>
                          <h4 className="font-bold text-slate-800 dark:text-white mt-1 pr-14">{noti.title}</h4>
                          <p className="text-slate-500 dark:text-slate-350 leading-relaxed mt-2.5">{noti.content}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* RESULTS MARKSHEET ENTRY PANEL */}
            {activeTab === "results" && (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
                
                {/* Result forms entry */}
                <form onSubmit={handleCreateResult} className="md:col-span-5 bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-3xs flex flex-col gap-4 text-xs font-semibold">
                  <h3 className="font-heading font-black text-slate-850 dark:text-white border-b pb-3 mb-2">
                    পরীক্ষার রেজাল্ট প্রবিষ্টকরণ (Enter Results)
                  </h3>

                  <div>
                    <label className="block text-slate-500 mb-1">শিক্ষার্থী নির্বাচন করুন (Select Student) *</label>
                    <select
                      value={studentId}
                      onChange={(e) => setStudentId(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-lg border border-slate-205 bg-white dark:bg-slate-850 text-slate-850 dark:text-white focus:outline-emerald-500"
                    >
                      <option value="">-- শিক্ষার্থী নির্বাচন করুন --</option>
                      {students.map(s => (
                        <option key={s.id} value={s.id}>{s.name} (রোলঃ {s.roll} - Class: {s.class})</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-500 mb-1">সাময়িকী টার্ম (Term) *</label>
                      <select
                        value={examTerm}
                        onChange={(e) => setExamTerm(e.target.value)}
                        className="w-full text-xs p-2.5 rounded-lg border border-slate-205 bg-white dark:bg-slate-850 text-slate-850 dark:text-white focus:outline-emerald-500"
                      >
                        <option value="First Term">First Term (প্রথম সাময়িক)</option>
                        <option value="Mid Term">Mid Term (অর্ধ-বার্ষিক)</option>
                        <option value="Final Exam">Final Exam (বার্ষিক পরীক্ষা)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-slate-500 mb-1">কুরআন মাজীদ (তাজবিদ) *</label>
                      <input type="number" required min={0} max={100} value={quran} onChange={e => setQuran(Number(e.target.value))} className="w-full p-2.5 rounded-lg border bg-transparent font-mono" />
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-2">
                    <div>
                      <label className="block text-slate-400 text-[10px] mb-1">বাংলা</label>
                      <input type="number" min={0} max={100} value={bangla} onChange={e => setBangla(Number(e.target.value))} className="w-full p-1.5 rounded-lg border bg-transparent font-mono" />
                    </div>
                    <div>
                      <label className="block text-slate-400 text-[10px] mb-1">ইংরেজি</label>
                      <input type="number" min={0} max={100} value={english} onChange={e => setEnglish(Number(e.target.value))} className="w-full p-1.5 rounded-lg border bg-transparent font-mono" />
                    </div>
                    <div>
                      <label className="block text-slate-400 text-[10px] mb-1">গণিত</label>
                      <input type="number" min={0} max={100} value={math} onChange={e => setMath(Number(e.target.value))} className="w-full p-1.5 rounded-lg border bg-transparent font-mono" />
                    </div>
                    <div>
                      <label className="block text-slate-400 text-[10px] mb-1">আরবি</label>
                      <input type="number" min={0} max={100} value={arabic} onChange={e => setArabic(Number(e.target.value))} className="w-full p-1.5 rounded-lg border bg-transparent font-mono" />
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-500 mb-1">নৈতিক ও সাধারণ জ্ঞান *</label>
                    <input type="number" required min={0} max={100} value={moral} onChange={e => setMoral(Number(e.target.value))} className="w-full p-2.5 rounded-lg border bg-transparent font-mono" />
                  </div>

                  <div>
                    <label className="block text-slate-500 mb-1">প্রধান শিক্ষকের মন্তব্য (Remarks)</label>
                    <input
                      type="text"
                      placeholder="যেমন: মাশআল্লাহ, অত্যন্ত ভালো। হাতের লেখা সুন্দরের চেষ্টা করুন।"
                      value={remarks}
                      onChange={(e) => setRemarks(e.target.value)}
                      className="w-full p-2.5 rounded-lg border bg-transparent focus:outline-emerald-500 text-xs"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full mt-2 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition-all cursor-pointer"
                  >
                    পরীক্ষার রেজাল্ট সেভ ও পাবলিশ দিন
                  </button>
                </form>

                {/* Results List reports */}
                <div className="md:col-span-7 bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-100 dark:border-slate-850 shadow-3xs">
                  <h3 className="font-heading font-black text-slate-850 dark:text-white border-b pb-3 mb-4">
                    সংরক্ষিত রেজাল্ট জিপিএ তালিকার তালিকা
                  </h3>

                  <div className="overflow-x-auto max-h-[500px]">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="border-b text-slate-400 font-bold font-mono text-[10px]">
                          <th className="py-2">শিক্ষাথী</th>
                          <th className="py-2 text-center">শ্রেণী</th>
                          <th className="py-2 text-center">টার্ম</th>
                          <th className="py-2 text-center">মোট নম্বর (Full)</th>
                          <th className="py-2 text-center">গ্রেড জিপিএ</th>
                          <th className="py-2 text-center">রিমার্কস</th>
                        </tr>
                      </thead>
                      <tbody>
                        {results.map((r) => (
                          <tr key={r.id} className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50/50">
                            <td className="py-3 font-semibold">{r.studentName} (রোলঃ {r.roll})</td>
                            <td className="py-3 text-center">{r.class}</td>
                            <td className="py-3 text-center text-slate-500">{r.term}</td>
                            <td className="py-3 text-center font-bold font-mono text-emerald-600">{r.totalMarks}</td>
                            <td className="py-3 text-center">
                              <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 dark:bg-emerald-950 font-bold font-mono text-[10px]">
                                {r.gpa.toFixed(2)} ({r.grade})
                              </span>
                            </td>
                            <td className="py-3 max-w-[150px] truncate text-slate-400 italic">{r.remarks}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* DAILY ATTENDANCE HAJIRA PANEL */}
            {activeTab === "attendance" && (
              <div className="bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-100 dark:border-slate-850 shadow-3xs">
                <div className="pb-4 mb-6 border-b flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div>
                    <h3 className="font-heading font-black text-slate-850 dark:text-white">
                      দৈনিক হাজিরা কলার শীট (Daily Roll Call Sheet)
                    </h3>
                    <p className="text-[10px] text-slate-405 mt-1">শিক্ষার্থীদের আজকের উপস্থিতি, অনুপস্থিতি অথবা বিলম্বে আগমন মার্ক করুন।</p>
                  </div>

                  <div className="flex gap-2">
                    <select
                      value={attendanceClass}
                      onChange={(e) => {
                        setAttendanceClass(e.target.value);
                        setAttendanceRecords({});
                      }}
                      className="p-2.5 text-xs rounded-xl border border-slate-205 bg-white dark:bg-slate-850 focus:outline-emerald-500 font-bold"
                    >
                      <option value="Play">Play (প্লে)</option>
                      <option value="Nursery">Nursery (নার্সারি)</option>
                      <option value="First">First (One)</option>
                      <option value="Second">Second (Two)</option>
                      <option value="Third">Third (Three)</option>
                    </select>

                    <button
                      onClick={handleAttendanceBulkSubmit}
                      className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-md transition-all flex items-center gap-1 cursor-pointer"
                    >
                      <ClipboardCheck size={14} />
                      <span>উপস্থিতি বিবরণী সেভ করুন</span>
                    </button>
                  </div>
                </div>

                {/* Dynamic list students of selected class option */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b text-slate-400 font-bold font-mono text-[10px] uppercase">
                        <th className="py-2.5">রোল (Roll)</th>
                        <th className="py-2.5">শিক্ষার্থীর নাম (Student Name)</th>
                        <th className="py-2.5">আইডি</th>
                        <th className="py-2.5 text-center">উপস্থিতি (Present)</th>
                        <th className="py-2.5 text-center">অনুপস্থিত (Absent)</th>
                        <th className="py-2.5 text-center">বিলম্বে (Late)</th>
                      </tr>
                    </thead>
                    <tbody>
                      {students.filter(s => s.class === attendanceClass).map((student) => {
                        const currentStatus = attendanceRecords[student.id] || "Present";
                        
                        return (
                          <tr key={student.id} className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50/50">
                            <td className="py-3 font-mono font-bold text-slate-450">{student.roll}</td>
                            <td className="py-3 font-semibold text-slate-800 dark:text-white">{student.name}</td>
                            <td className="py-3 font-mono text-slate-400">{student.id}</td>
                            
                            <td className="py-3 text-center">
                              <input
                                type="radio"
                                name={`att-${student.id}`}
                                checked={currentStatus === "Present"}
                                onChange={() => setAttendanceRecords(prev => ({ ...prev, [student.id]: "Present" }))}
                                className="w-4 h-4 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                              />
                            </td>
                            <td className="py-3 text-center">
                              <input
                                type="radio"
                                name={`att-${student.id}`}
                                checked={currentStatus === "Absent"}
                                onChange={() => setAttendanceRecords(prev => ({ ...prev, [student.id]: "Absent" }))}
                                className="w-4 h-4 text-rose-600 focus:ring-rose-500 cursor-pointer"
                              />
                            </td>
                            <td className="py-3 text-center">
                              <input
                                type="radio"
                                name={`att-${student.id}`}
                                checked={currentStatus === "Late"}
                                onChange={() => setAttendanceRecords(prev => ({ ...prev, [student.id]: "Late" }))}
                                className="w-4 h-4 text-amber-500 focus:ring-amber-550 cursor-pointer"
                              />
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* STUDENTS DIRECTORY MANAGEMENT & CSV IMPORT */}
            {activeTab === "students" && (
              <div className="bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-100 dark:border-slate-850 shadow-3xs flex flex-col gap-6">
                
                <div className="pb-4 border-b flex justify-between items-center flex-wrap gap-4 text-xs">
                  <div>
                    <h3 className="font-heading font-black text-slate-850 dark:text-white">
                      শিক্ষার্থী ডাটাবেস ও CSV ইম্পোর্ট-এক্সপোর্ট কন্ট্রোল
                    </h3>
                    <p className="text-[10px] text-slate-400 mt-1">সিস্টেমে শিক্ষার্থীদের তালিকা এক ক্লিকে বা এক্সেল সিএসভি ফাইলের মাধ্যমে পরিচালনা করুন।</p>
                  </div>

                  <div className="flex gap-2 flex-wrap">
                    <button
                      id="admin-csv-import-dialog-trigger"
                      onClick={() => setCsvUploadOpen(!csvUploadOpen)}
                      className="px-3.5 py-2.5 bg-amber-500 hover:bg-amber-600 font-bold text-slate-900 rounded-xl transition-all flex items-center gap-1 cursor-pointer"
                    >
                      <Upload size={14} />
                      <span>CSV শিক্ষার্থী ইম্পোর্ট</span>
                    </button>

                    <button
                      id="admin-csv-export-trigger"
                      onClick={handleExportCSV}
                      className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold rounded-xl transition-all flex items-center gap-1 cursor-pointer"
                    >
                      <Download size={14} />
                      <span>সকল শিক্ষার্থী CSV এক্সপোর্ট</span>
                    </button>
                  </div>
                </div>

                {/* Real-time slider of csv copy pasting */}
                {csvUploadOpen && (
                  <div className="p-5 rounded-2xl border border-amber-300 bg-amber-50/10 dark:bg-amber-950/5 flex flex-col gap-3 font-semibold text-xs border-dashed">
                    <div className="flex justify-between items-center">
                      <h4 className="font-bold text-amber-800 dark:text-amber-400">CSV বাল্ক স্টুডেন্ট ইম্পোর্ট করার নির্দেশাবলীঃ</h4>
                      <button onClick={() => setCsvUploadOpen(false)} className="text-slate-400 hover:text-slate-600"><X size={16} /></button>
                    </div>
                    <p className="text-[11px] text-slate-500 leading-normal">
                      নিচের টেক্সট বক্সে যথাক্রমে ৪ বা ৫টি ফিল্ডার কমা দিয়ে একটি লাইন গঠন করুন (Name,Roll,Class,GuardianName,GuardianPhone,Address)। প্রথম লাইনে অবশ্যই হেডার সমূহ থাকবে।
                    </p>
                    <textarea
                      rows={5}
                      placeholder="Name,Roll,Class,GuardianName,GuardianPhone,Address&#10;মোস্তফা কায়সার,১০১,Play,মোঃ জুনাইদ,01711112221,চকরিয়া কক্সবাজার"
                      value={csvRawText}
                      onChange={e => setCsvRawText(e.target.value)}
                      className="w-full text-xs p-3 font-mono border rounded-lg bg-white dark:bg-slate-900 text-slate-800 dark:text-white"
                    />
                    <button
                      onClick={handleImportCSVData}
                      className="py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg cursor-pointer text-center shadow-3xs"
                    >
                      ডাটাবেসে প্রসেস করুন (Run CSV Import)
                    </button>
                  </div>
                )}

                {/* Directory listing summary */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-slate-150 text-slate-400 font-mono text-[10px] uppercase">
                        <th className="py-2.5">রোল নম্বর</th>
                        <th className="py-2.5">শিক্ষার্থীর নাম</th>
                        <th className="py-2.5">শ্রেণী</th>
                        <th className="py-2.5">সেশন</th>
                        <th className="py-2.5">অভিভাবক</th>
                        <th className="py-2.5">অভিভাবকের মোবাইল</th>
                        <th className="py-2.5 text-center">অপারেশন</th>
                      </tr>
                    </thead>
                    <tbody>
                      {students.map((stud) => (
                        <tr key={stud.id} className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50/50">
                          <td className="py-3 font-mono font-bold text-slate-450">{stud.roll}</td>
                          <td className="py-3 font-semibold text-slate-800 dark:text-white">{stud.name}</td>
                          <td className="py-3 font-mono text-emerald-600 font-bold">{stud.class}</td>
                          <td className="py-3 text-slate-450 font-mono">{stud.session}</td>
                          <td className="py-3">{stud.guardianName}</td>
                          <td className="py-3 font-mono text-slate-500">{stud.guardianPhone}</td>
                          <td className="py-3 text-center">
                            <button
                              onClick={() => {
                                if (confirm(`আপনি কি "${stud.name}" এর সকল ডেটা মুছে ফেলতে চান?`)) onDeleteStudent(stud.id);
                              }}
                              className="p-1 px-2 hover:bg-rose-50 rounded text-rose-600 dark:hover:bg-rose-950/20 cursor-pointer"
                            >
                              <Trash2 size={12} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* FEEDBACK CONTACT MESSAGES INBOX PANEL */}
            {activeTab === "contacts" && (
              <div className="bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-100 dark:border-slate-850 shadow-3xs flex flex-col gap-4">
                <h3 className="font-heading font-black text-slate-850 dark:text-white pb-3 border-b flex justify-between items-center text-xs">
                  <span>অভিভাবক ফিডব্যাক ও যোগাযোগ বার্তা বক্স (Direct Mail Inbox)</span>
                  <span className="text-slate-400">মেসেজ সংখ্যাঃ {contacts.filter(c => !c.read).length} অপঠিত বার্তা</span>
                </h3>

                <div className="flex flex-col gap-4">
                  {contacts.length > 0 ? (
                    contacts.map((c) => (
                      <div
                        key={c.id}
                        className={`p-4 rounded-xl border relative text-xs flex gap-3 ${
                          c.read ? "border-slate-150 bg-slate-50/50" : "border-emerald-500/20 bg-emerald-50/20 dark:bg-emerald-950/10"
                        }`}
                      >
                        {!c.read && (
                          <button
                            onClick={() => onReadContact(c.id)}
                            className="absolute top-3 right-4 px-2.5 py-1 bg-emerald-600 text-white rounded-md font-bold text-[10px] cursor-pointer"
                          >
                            পঠিত হিসেবে মার্ক করুন
                          </button>
                        )}
                        
                        <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center font-bold text-slate-500 shrink-0 select-none">
                          {c.name[0]}
                        </div>

                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="font-bold text-slate-800 dark:text-white leading-none">{c.name}</h4>
                            <span className="text-[10px] text-slate-400 font-mono">({c.phone})</span>
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono block">{c.date}</span>
                          <p className="text-slate-650 dark:text-slate-350 italic mt-3 pr-20">
                            "{c.message}"
                          </p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-10 text-slate-450 border rounded-xl">
                      <Mail size={32} className="mx-auto mb-2 opacity-50" />
                      <span>ইনবক্স বর্তমানে শূন্য!</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* SETTINGS KEY CONTROLS UPDATE */}
            {activeTab === "settings" && (
              <div className="bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-100 dark:border-slate-850 shadow-3xs flex flex-col gap-5 text-xs font-semibold">
                <h3 className="font-heading font-black text-slate-850 dark:text-white border-b pb-3 mb-2 flex items-center gap-1.5">
                  <Settings size={16} />
                  <span>মাদ্রাসার সাধারণ পরিচিত ঠিকানা ও ডেটা সেটিংস</span>
                </h3>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-550 mb-1">মাদ্রাসার নাম (ইংরেজি) *</label>
                    <input type="text" value={webName} onChange={e => setWebName(e.target.value)} className="w-full text-xs p-2 rounded-lg border bg-transparent font-mono" />
                  </div>
                  <div>
                    <label className="block text-slate-550 mb-1">মাদ্রাসার নাম (বাংলা)*</label>
                    <input type="text" value={webBangla} onChange={e => setWebBangla(e.target.value)} className="w-full text-xs p-2 rounded-lg border bg-transparent" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-550 mb-1">সৈয়দবাজার / ইউনিয়নের ঠিকানা *</label>
                    <input type="text" value={webAddr} onChange={e => setWebAddr(e.target.value)} className="w-full text-xs p-2 rounded-lg border bg-transparent" />
                  </div>
                  <div>
                    <label className="block text-slate-550 mb-1">জরুরী ফোন হটলাইন নম্বর *</label>
                    <input type="text" value={webPhone} onChange={e => setWebPhone(e.target.value)} className="w-full text-xs p-2 rounded-lg border bg-transparent font-mono" />
                  </div>
                </div>

                {/* layout customization subdivision */}
                <div className="border-t border-slate-150 dark:border-slate-800 pt-5 mt-4 space-y-6">
                  
                  {/* Premium Heading */}
                  <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                    <h4 className="font-heading font-black text-sm flex items-center gap-2 uppercase tracking-wide text-emerald-600 dark:text-emerald-400">
                      <span className="text-xl">🎨</span>
                      <span>প্রিমিয়াম ডিজাইন, লেআউট ও ব্রান্ডিং স্টুডিও (Premium Design Console)</span>
                    </h4>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-400 px-2 py-0.5 rounded-full font-bold">
                      Admins Only
                    </span>
                  </div>

                  {/* SUB-SECTION 1: LOGO DESIGN & STYLING */}
                  <div className="bg-slate-50/50 dark:bg-slate-900/30 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-4">
                    <h5 className="font-heading font-black text-slate-850 dark:text-white text-xs flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
                      <span>🕌 ১. লোগো কাস্টমাইজেশন ও ব্রান্ডিং (Logo Branding & Styles)</span>
                    </h5>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      
                      {/* Logo URL input */}
                      <div>
                        <label className="block text-slate-550 mb-1 font-bold">লোগো ছবি ইউআরএল (Logo Image URL)</label>
                        <input
                          type="text"
                          value={logoUrl}
                          onChange={(e) => setLogoUrl(e.target.value)}
                          placeholder="https://images.unsplash.com/your-logo"
                          className="w-full text-xs p-2.5 rounded-lg border bg-white dark:bg-slate-950 text-slate-850 dark:text-white font-mono"
                        />
                        <p className="text-[10px] text-slate-400 mt-1">মাদ্রাসার অফিসিয়াল প্রতীক বা পিএনজি ছবি লিংক করুন।</p>
                      </div>

                      {/* Logo Presets Quick Picker */}
                      <div>
                        <label className="block text-slate-550 mb-1 font-bold">লোগো প্রিসেটস (Logo Presets)</label>
                        <div className="flex flex-wrap gap-1.5 mt-1">
                          {[
                            { name: "Mosque Dome", url: "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=120" },
                            { name: "Clean Dome", url: "https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&q=80&w=120" },
                            { name: "Minarets", url: "https://images.unsplash.com/photo-1590076214561-2057d60f4eb7?auto=format&fit=crop&q=80&w=120" },
                            { name: "Green Crescent", url: "https://images.unsplash.com/photo-1609599006353-e629beabfeae?auto=format&fit=crop&q=80&w=120" },
                            { name: "Calligraphy", url: "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&q=80&w=120" }
                          ].map((p, idx) => (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => setLogoUrl(p.url)}
                              className={`px-2 py-1 text-[10px] rounded-md transition-all border font-black cursor-pointer ${
                                logoUrl === p.url ? "border-emerald-500 bg-emerald-50 text-emerald-600 dark:bg-emerald-950/25" : "border-slate-200 dark:border-slate-700 text-slate-500 bg-white dark:bg-slate-950"
                              }`}
                            >
                              {p.name}
                            </button>
                          ))}
                        </div>
                      </div>

                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 pt-2">
                      
                      {/* Logo Shape */}
                      <div>
                        <label className="block text-slate-550 mb-1 font-bold">লোগো শেপ (Logo Shape)</label>
                        <select
                          value={logoShape}
                          onChange={(e) => setLogoShape(e.target.value as any)}
                          className="w-full text-xs p-2.5 rounded-lg border bg-white dark:bg-slate-950 text-slate-850 dark:text-white font-bold"
                        >
                          <option value="circle">সম্পূর্ণ বৃত্তাকার (Circle)</option>
                          <option value="square">চারকোণা স্কয়ার (Square)</option>
                          <option value="rounded-xl">নরম চারকোণা (Rounded XL)</option>
                          <option value="polygon">অষ্টভুজ জ্যামিতিক (Hexagon)</option>
                        </select>
                      </div>

                      {/* Logo Size */}
                      <div>
                        <label className="block text-slate-550 mb-1 font-bold">লোগো আকৃতি / সাইজ (Logo Size)</label>
                        <select
                          value={logoSize}
                          onChange={(e) => setLogoSize(e.target.value as any)}
                          className="w-full text-xs p-2.5 rounded-lg border bg-white dark:bg-slate-950 text-slate-850 dark:text-white font-bold"
                        >
                          <option value="small">ছোট (Small - 40px)</option>
                          <option value="medium">মধ্যম (Medium - 48px)</option>
                          <option value="large">বড় আকারের (Large - 54px)</option>
                          <option value="super-size">বিশাল আকারের (Super - 64px)</option>
                        </select>
                      </div>

                      {/* Logo Border Color */}
                      <div>
                        <label className="block text-slate-550 mb-1 font-bold">লোগো বর্ডার কালার (Border Color)</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={logoBorderColor}
                            onChange={(e) => setLogoBorderColor(e.target.value)}
                            className="w-9 h-9 border rounded-lg cursor-pointer shrink-0"
                          />
                          <input
                            type="text"
                            value={logoBorderColor}
                            onChange={(e) => setLogoBorderColor(e.target.value)}
                            className="w-full text-xs font-mono p-2 border bg-white dark:bg-slate-950 rounded-lg text-slate-850 dark:text-white"
                          />
                        </div>
                      </div>

                      {/* Logo Glow Shadow Toggle */}
                      <div>
                        <label className="block text-slate-550 mb-1 font-bold">লোগো গ্লো ইফেক্ট (Glow Effect)</label>
                        <button
                          type="button"
                          onClick={() => setLogoGlow(!logoGlow)}
                          className={`w-full py-2 px-3 text-xs rounded-lg border font-bold transition-all text-center cursor-pointer ${
                            logoGlow ? "bg-emerald-500 text-white border-emerald-600 shadow-md shadow-emerald-500/20" : "bg-white dark:bg-slate-950 border-slate-250 text-slate-500"
                          }`}
                        >
                          {logoGlow ? "গ্লো সক্রিয় (Glow ON) ✨" : "সরাসরি সমতল (Glow OFF)"}
                        </button>
                      </div>

                    </div>
                  </div>

                  {/* SUB-SECTION 2: HEADER BANNER & BACKGROUNDS */}
                  <div className="bg-slate-50/50 dark:bg-slate-900/30 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-4">
                    <h5 className="font-heading font-black text-slate-850 dark:text-white text-xs flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
                      <span>🌄 ২. মূল হেডার ও নেভিগেশন স্টাইল (Sticky Header Styling)</span>
                    </h5>

                    <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                      
                      {/* Banner Image URL */}
                      <div className="md:col-span-8">
                        <label className="block text-slate-550 mb-1 font-bold">হেডার ব্যাকগ্রাউন্ড ফটো ইউআরএল (Header Photo URL)</label>
                        <input
                          type="text"
                          value={headerBgPhoto}
                          onChange={(e) => setHeaderBgPhoto(e.target.value)}
                          placeholder="কালিগ্রাফি বা ইসলামিক ডিজাইনের ফটো লিংক (যেমন: https://...)"
                          className="w-full text-xs p-2.5 rounded-lg border bg-white dark:bg-slate-950 text-slate-850 dark:text-white font-mono"
                        />
                        <p className="text-[10px] text-slate-400 mt-1">ফাঁকা রাখলে শুধুমাত্র নিচের হেডার ব্যাকগ্রাউন্ড কালার ব্যবহার করা হবে।</p>
                      </div>

                      {/* Overlay Opacity */}
                      <div className="md:col-span-4">
                        <label className="block text-slate-550 mb-1 font-bold">ফটো ওভারলে অন্ধকার তীব্রতা (Overlay Opacity)</label>
                        <div className="flex items-center gap-3 mt-1.5">
                          <input
                            type="range"
                            min="0"
                            max="90"
                            step="10"
                            value={headerOverlayOpacity}
                            onChange={(e) => setHeaderOverlayOpacity(e.target.value)}
                            className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                          />
                          <span className="text-xs font-bold font-mono shrink-0 bg-slate-100 dark:bg-slate-950 p-1.5 rounded-md text-emerald-600">
                            {headerOverlayOpacity}%
                          </span>
                        </div>
                      </div>

                    </div>

                    {/* Pre-seeded Premium Header Photo Templates */}
                    <div>
                      <p className="text-[10px] text-slate-400 mb-1.5">সুন্দর হেডার ফটো থিম প্রিসেট বেছে নিন (Choose background photo preset):</p>
                      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-2">
                        {[
                          { name: "Arabic Calligraphy", url: "https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&q=80&w=500" },
                          { name: "Mandala Tiles", url: "https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&q=80&w=500" },
                          { name: "Star Geometry", url: "https://images.unsplash.com/photo-1590076214561-2057d60f4eb7?auto=format&fit=crop&q=80&w=500" },
                          { name: "Gold Pattern Arabes", url: "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&q=80&w=500" },
                          { name: "None (Solid Color)", url: "" }
                        ].map((photo, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => setHeaderBgPhoto(photo.url)}
                            className={`p-2 rounded-lg border text-left bg-white dark:bg-slate-950 transition-all cursor-pointer shadow-3xs group border-slate-150 ${
                              headerBgPhoto === photo.url ? "ring-2 ring-emerald-500 border-emerald-500" : "hover:border-slate-300"
                            }`}
                          >
                            <span className="block text-[10px] font-bold truncate group-hover:text-emerald-600">{photo.name}</span>
                            {photo.url ? (
                              <div className="h-6 w-full rounded mt-1 bg-cover bg-center overflow-hidden" style={{ backgroundImage: `url(${photo.url})` }} />
                            ) : (
                              <div className="h-6 w-full rounded mt-1 bg-slate-200 flex items-center justify-center text-[8px] text-slate-500">Solid</div>
                            )}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* SUB-SECTION 3: COLORS & PREMIUM COLOR PALETTES */}
                  <div className="bg-slate-50/50 dark:bg-slate-900/30 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-4">
                    <h5 className="font-heading font-black text-slate-850 dark:text-white text-xs flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
                      <span>🎨 ৩. কালার প্যালেট ও ব্যাকগ্রাউন্ড কনফিগারেশন (All Section Backgrounds & Text Colors)</span>
                    </h5>

                    {/* QUICK THEME PRESETS */}
                    <div className="bg-white dark:bg-slate-950 p-4 rounded-xl border">
                      <span className="block text-[10px] uppercase text-emerald-600 font-black mb-2 tracking-wide">১-ক্লিক প্রিমিয়াম কালর স্কিম (Ready Theme Presets)</span>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                        {[
                          {
                            name: "Emerald Green",
                            desc: "ঐতিহ্যবাহী দ্বীনি ও সবুজ",
                            webBg: "#f8fafc",
                            headerBg: "#064e3b",
                            sectionBg: "#ffffff",
                            titleColor: "#064e3b",
                            textColor: "#334155",
                            primary: "#059669"
                          },
                          {
                            name: "Royal Velvet",
                            desc: "রাজকীয় গাঢ় নীল থিম",
                            webBg: "#f1f5f9",
                            headerBg: "#0f172a",
                            sectionBg: "#ffffff",
                            titleColor: "#1e3a8a",
                            textColor: "#1e293b",
                            primary: "#1d4ed8"
                          },
                          {
                            name: "Sandal Antique",
                            desc: "মনোরম প্রাচীন তামাটে",
                            webBg: "#fdfaf2",
                            headerBg: "#451a03",
                            sectionBg: "#ffffff",
                            titleColor: "#7c2d12",
                            textColor: "#451a03",
                            primary: "#b45309"
                          },
                          {
                            name: "Majestic Dark",
                            desc: "পলিশ ডার্ক জিল মোড",
                            webBg: "#0d1117",
                            headerBg: "#161b22",
                            sectionBg: "#161b22",
                            titleColor: "#58a6ff",
                            textColor: "#c9d1d9",
                            primary: "#0969da"
                          }
                        ].map((preset, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => {
                              setWebBgColor(preset.webBg);
                              setHeaderBgColor(preset.headerBg);
                              setSectionBgColor(preset.sectionBg);
                              setSectionTitleColor(preset.titleColor);
                              setSectionTextColor(preset.textColor);
                              setPrimaryAccentColor(preset.primary);
                            }}
                            className="p-2.5 border hover:border-emerald-500 rounded-lg text-left bg-slate-50 dark:bg-slate-900 transition-all cursor-pointer group shadow-3xs"
                          >
                            <span className="block text-xs font-black text-slate-800 dark:text-white group-hover:text-emerald-605">{preset.name}</span>
                            <span className="text-[10px] text-slate-400 block mb-2">{preset.desc}</span>
                            <div className="flex gap-1">
                              <span className="w-3.5 h-3.5 rounded-full border shadow-3xs" style={{ backgroundColor: preset.webBg }} title="Web BG" />
                              <span className="w-3.5 h-3.5 rounded-full border shadow-3xs" style={{ backgroundColor: preset.headerBg }} title="Header BG" />
                              <span className="w-3.5 h-3.5 rounded-full border shadow-3xs" style={{ backgroundColor: preset.sectionBg }} title="Section Card" />
                              <span className="w-3.5 h-3.5 rounded-full border shadow-3xs" style={{ backgroundColor: preset.primary }} title="Buttons Accent" />
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* DYNAMIC COLOR PICKERS */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 pt-2">
                      
                      {/* Web Background */}
                      <div className="p-3 bg-white dark:bg-slate-950 border rounded-xl">
                        <label className="block text-slate-550 mb-1 font-bold">ওয়েবসাইট প্রধান ব্যাকগ্রাউন্ড (Web BG)</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={webBgColor}
                            onChange={(e) => setWebBgColor(e.target.value)}
                            className="w-10 h-10 border rounded-lg cursor-pointer"
                          />
                          <input
                            type="text"
                            value={webBgColor}
                            onChange={(e) => setWebBgColor(e.target.value)}
                            className="w-full text-xs font-mono p-2 border bg-transparent rounded-lg"
                          />
                        </div>
                      </div>

                      {/* Header Background */}
                      <div className="p-3 bg-white dark:bg-slate-950 border rounded-xl">
                        <label className="block text-slate-550 mb-1 font-bold">মেনুবার / হেডার ব্যাকগ্রাউন্ড (Header BG)</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={headerBgColor}
                            onChange={(e) => setHeaderBgColor(e.target.value)}
                            className="w-10 h-10 border rounded-lg cursor-pointer"
                          />
                          <input
                            type="text"
                            value={headerBgColor}
                            onChange={(e) => setHeaderBgColor(e.target.value)}
                            className="w-full text-xs font-mono p-2 border bg-transparent rounded-lg"
                          />
                        </div>
                      </div>

                      {/* Section BG Cards */}
                      <div className="p-3 bg-white dark:bg-slate-950 border rounded-xl">
                        <label className="block text-slate-550 mb-1 font-bold">সেকশন ও কার্ড ব্যাকগ্রাউন্ড (Card BG)</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={sectionBgColor}
                            onChange={(e) => setSectionBgColor(e.target.value)}
                            className="w-10 h-10 border rounded-lg cursor-pointer"
                          />
                          <input
                            type="text"
                            value={sectionBgColor}
                            onChange={(e) => setSectionBgColor(e.target.value)}
                            className="w-full text-xs font-mono p-2 border bg-transparent rounded-lg"
                          />
                        </div>
                      </div>

                      {/* Primary Accent Color */}
                      <div className="p-3 bg-white dark:bg-slate-950 border rounded-xl">
                        <label className="block text-slate-550 mb-1 font-bold">প্রধান বাটন / অ্যাকসেন্ট কালার (Accent UI) *</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={primaryAccentColor}
                            onChange={(e) => setPrimaryAccentColor(e.target.value)}
                            className="w-10 h-10 border rounded-lg cursor-pointer"
                          />
                          <input
                            type="text"
                            value={primaryAccentColor}
                            onChange={(e) => setPrimaryAccentColor(e.target.value)}
                            className="w-full text-xs font-mono p-2 border bg-transparent rounded-lg"
                          />
                        </div>
                      </div>

                      {/* Secondary Accent */}
                      <div className="p-3 bg-white dark:bg-slate-950 border rounded-xl">
                        <label className="block text-slate-550 mb-1 font-bold">সেকেন্ডারি হাইলাইট কালার (Secondary Accent)</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={secondaryAccentColor}
                            onChange={(e) => setSecondaryAccentColor(e.target.value)}
                            className="w-10 h-10 border rounded-lg cursor-pointer"
                          />
                          <input
                            type="text"
                            value={secondaryAccentColor}
                            onChange={(e) => setSecondaryAccentColor(e.target.value)}
                            className="w-full text-xs font-mono p-2 border bg-transparent rounded-lg"
                          />
                        </div>
                      </div>

                      {/* Section Title Text Color */}
                      <div className="p-3 bg-white dark:bg-slate-950 border rounded-xl">
                        <label className="block text-slate-550 mb-1 font-bold">সেকশন হেডিং ও টাইটেল কালার (Section Titles) *</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={sectionTitleColor}
                            onChange={(e) => setSectionTitleColor(e.target.value)}
                            className="w-10 h-10 border rounded-lg cursor-pointer"
                          />
                          <input
                            type="text"
                            value={sectionTitleColor}
                            onChange={(e) => setSectionTitleColor(e.target.value)}
                            className="w-full text-xs font-mono p-2 border bg-transparent rounded-lg"
                          />
                        </div>
                      </div>

                      {/* General Desk Text Color */}
                      <div className="p-3 bg-white dark:bg-slate-950 border rounded-xl md:col-span-3">
                        <label className="block text-slate-550 mb-1 font-bold">সাধারণ টেক্সট ও অনুচ্ছেদ কালার (General Paragraph/Text Color) *</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={sectionTextColor}
                            onChange={(e) => setSectionTextColor(e.target.value)}
                            className="w-10 h-10 border rounded-lg cursor-pointer"
                          />
                          <input
                            type="text"
                            value={sectionTextColor}
                            onChange={(e) => setSectionTextColor(e.target.value)}
                            className="w-full text-xs font-mono p-2 border bg-transparent rounded-lg"
                          />
                        </div>
                      </div>

                    </div>
                  </div>

                  {/* SUB-SECTION 4: PREMIUM TYPOGRAPHY */}
                  <div className="bg-slate-50/50 dark:bg-slate-900/30 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-4">
                    <h5 className="font-heading font-black text-slate-850 dark:text-white text-xs flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
                      <span>🔤 ৪. ফন্ট জুটি ও টেক্সট সাইজ কাস্টমাইজেশন (Typography & Font Styling)</span>
                    </h5>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                      
                      {/* Font Family Option selection */}
                      <div>
                        <label className="block text-slate-550 mb-1 font-bold">প্রধান লেখার ফন্ট (Text Font Customisation)</label>
                        <select
                          value={fontFamily}
                          onChange={(e) => setFontFamily(e.target.value as any)}
                          className="w-full text-xs p-2.5 rounded-lg border bg-white dark:bg-slate-950 font-bold text-slate-800 dark:text-white"
                        >
                          <option value="noto-bengali">Noto Sans Bengali (ঐতিহ্যবাহী বাংলা)</option>
                          <option value="inter">Inter Display (আধুনিক প্রফেশনাল)</option>
                          <option value="space-grotesk">Space Grotesk (টেক-ফরোয়ার্ড)</option>
                          <option value="playfair">Playfair Display (ক্লাসিক সেরীফ)</option>
                          <option value="outfit">Outfit Geometric (জিওমেট্রিক রাউন্ড)</option>
                          <option value="mono">JetBrains Mono (টেকনিক্যাল মনোস্পেস)</option>
                        </select>
                      </div>

                      {/* Font Sizing Modifier */}
                      <div>
                        <label className="block text-slate-550 mb-1 font-bold">টেক্সট সাইজ কাস্টমাইজেশন (Text Size)</label>
                        <select
                          value={fontSizeLevel}
                          onChange={(e) => setFontSizeLevel(e.target.value as any)}
                          className="w-full text-xs p-2.5 rounded-lg border bg-white dark:bg-slate-950 font-bold text-slate-800 dark:text-white"
                        >
                          <option value="small">ছোট (কমপ্যাক্ট লেআউট - 13px)</option>
                          <option value="medium">স্ট্যান্ডার্ড (আদর্শ ও পাঠযোগ্য - 15px)</option>
                          <option value="large">বড় আকারের (স্পেসড ও স্পষ্ট - 17px)</option>
                          <option value="extra-large">বিশাল আকারের (অ্যাক্সেসিবিলিটি - 19px)</option>
                        </select>
                      </div>

                      {/* Header Weights */}
                      <div>
                        <label className="block text-slate-550 mb-1 font-bold">শিরোনামের ফন্ট ওয়েট (Heading Font Weight)</label>
                        <select
                          value={headingWeight}
                          onChange={(e) => setHeadingWeight(e.target.value as any)}
                          className="w-full text-xs p-2.5 rounded-lg border bg-white dark:bg-slate-950 font-bold text-slate-800 dark:text-white"
                        >
                          <option value="regular">Regular Weight (স্বাভাবিক)</option>
                          <option value="semibold">Semibold Weight (মাঝারি বোল্ড)</option>
                          <option value="bold">Bold Weight (মোটা বোল্ড - স্ট্যান্ডার্ড)</option>
                          <option value="black">Black Weight (অতিরিক্ত মোটা সিলেক্টর)</option>
                        </select>
                      </div>

                      {/* Premium Style Presets Card Border Radiuses */}
                      <div>
                        <label className="block text-slate-550 mb-1 font-bold">কার্ড আউটার স্টাইল (Layout Theme mode)</label>
                        <select
                          value={premiumStyleMode}
                          onChange={(e) => setPremiumStyleMode(e.target.value as any)}
                          className="w-full text-xs p-2.5 rounded-lg border bg-white dark:bg-slate-950 font-bold text-slate-800 dark:text-white"
                        >
                          <option value="flat">সমতল ফ্লাট (Flat & Modern)</option>
                          <option value="glass">গ্লসি গ্লাস মরফিজম (Glossy Glass)</option>
                          <option value="bordered">উচ্চ বৈসাদৃশ্য হাই-কনট্রাস্ট বর্ডার (Bordered)</option>
                          <option value="glowing">মৃদু শ্যাডো গ্লো (Glowing Accent)</option>
                          <option value="minimalist">মিনিমালিস্ট ওয়ান-লাইন (Minimalist Clean)</option>
                        </select>
                      </div>

                    </div>
                  </div>

                  {/* SUB-SECTION 5: ANIMATIONS & TRANSITIONS */}
                  <div className="bg-slate-50/50 dark:bg-slate-900/30 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-4">
                    <h5 className="font-heading font-black text-slate-850 dark:text-white text-xs flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
                      <span>✨ ৫. মোশন, স্মুথ এনিমেশন ও ইন্টারঅ্যাকশন (Motion & Fluidity Toggles)</span>
                    </h5>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      
                      {/* Animation Style Preset enum */}
                      <div>
                        <label className="block text-slate-550 mb-1 font-bold">এনিমেশন স্টাইল প্রিসেট (Animated preset Style)</label>
                        <select
                          value={animationStyle}
                          onChange={(e) => setAnimationStyle(e.target.value as any)}
                          className="w-full text-xs p-2.5 rounded-lg border bg-white dark:bg-slate-950 font-bold text-slate-800 dark:text-white"
                        >
                          <option value="disabled">কোনো এনিমেশন নেই (Fastest - No Transitions)</option>
                          <option value="smooth">লিনিয়ার ও ফ্লুইড স্মুথ (Classic Fluid Smooth)</option>
                          <option value="bouncy">স্প্রিং ও বাউন্সি লোড (Playful Bouncy Elastic)</option>
                          <option value="ultra-premium">প্রিমিয়াম আল্ট্রা-লিনিয়ার (Premium Smooth Glide)</option>
                        </select>
                        <p className="text-[10px] text-slate-400 mt-1">সব পেজ পরিবর্তনের সময় ও হোভারে এনিমেশন গতিশীলতা নিয়ন্ত্রণ করে।</p>
                      </div>

                      {/* Animation Transit Speed range */}
                      <div>
                        <label className="block text-slate-550 mb-1 font-bold">এনিমেশন সময়কাল (Transition Speed)</label>
                        <select
                          value={animationDuration}
                          onChange={(e) => setAnimationDuration(e.target.value)}
                          className="w-full text-xs p-2.5 rounded-lg border bg-white dark:bg-slate-950 font-bold text-slate-850 dark:text-white"
                        >
                          <option value="0.1s">অতি দ্রুত (Very Fast - 0.1s)</option>
                          <option value="0.3s">স্বাভাবিক (Default Comfort - 0.3s)</option>
                          <option value="0.5s">ধীর গতির (Slower Luxurious - 0.5s)</option>
                          <option value="0.8s">অতি ধীর ফিল্মি (Luxury Cinematic - 0.8s)</option>
                        </select>
                      </div>

                    </div>
                  </div>

                  {/* SUB-SECTION 6: LIVE TIME & DATE */}
                  <div className="bg-slate-50/50 dark:bg-slate-900/30 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-4">
                    <h5 className="font-heading font-black text-slate-855 dark:text-white text-xs flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
                      <span>⏰ ৬. রিয়েল-টাইম লাইভ ঘড়ি ও তারিখ কাস্টমাইজেশন (Real-time Clock & Date Studio)</span>
                    </h5>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      
                      {/* Live Clock toggle switcher */}
                      <div className="p-4 bg-white dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-850 flex flex-col justify-between">
                        <div>
                          <label className="block text-slate-750 dark:text-slate-200 font-bold text-xs mb-1">রিয়েল-টাইম লাইভ ঘড়ি (Show Live Clock)</label>
                          <p className="text-[10px] text-slate-400 leading-normal mb-3">ওয়েবসাইটের প্রধান মেনুবারে সেকেন্ড সহ চলমান লাইভ ঘড়ি দেখাবে কিনা তা নিয়ন্ত্রণ করুন।</p>
                        </div>
                        <div className="flex gap-2">
                          <button
                            key="clock-on"
                            type="button"
                            onClick={() => setShowLiveClock(true)}
                            className={`flex-1 py-2 px-3 text-xs rounded-lg border font-bold transition-all text-center cursor-pointer ${
                              showLiveClock ? "bg-emerald-600 text-white border-emerald-700 font-black shadow-xs" : "bg-slate-50 dark:bg-slate-900 border-slate-200 text-slate-500"
                            }`}
                          >
                            সক্রিয় বা চালু (ON)
                          </button>
                          <button
                            key="clock-off"
                            type="button"
                            onClick={() => setShowLiveClock(false)}
                            className={`flex-1 py-1.5 px-3 text-xs rounded-lg border font-bold transition-all text-center cursor-pointer ${
                              !showLiveClock ? "bg-rose-600 text-white border-rose-700 font-black shadow-xs" : "bg-slate-50 dark:bg-slate-900 border-slate-200 text-slate-500"
                            }`}
                          >
                            বন্ধ বা নিষ্ক্রিয় (OFF)
                          </button>
                        </div>
                      </div>

                      {/* Live Clock Format selector */}
                      <div className="p-4 bg-white dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-855 flex flex-col justify-between">
                        <div>
                          <label className="block text-slate-750 dark:text-slate-200 font-bold text-xs mb-1">ঘড়ির সময় দেখানোর ফরম্যাট (Clock Time Format)</label>
                          <p className="text-[10px] text-slate-400 leading-normal mb-3">লাইভ ঘড়িতে ১২ ঘন্টা (AM/PM) মোড বা ২৪ ঘন্টা অথবা সরাসরি বাংলা টেক্সট সংখ্যায় সময় দেখাবেন কিনা নির্বাচন করুন।</p>
                        </div>
                        <select
                          value={liveClockFormat}
                          onChange={(e) => setLiveClockFormat(e.target.value as any)}
                          className="w-full text-xs p-2.5 rounded-lg border bg-slate-50 dark:bg-slate-900 font-bold text-slate-800 dark:text-white"
                        >
                          <option value="12hour">১২ ঘন্টা মোড (১২:৩০:১৫ PM)</option>
                          <option value="24hour">২৪ ঘন্টা মোড (১২:৩০:১৫)</option>
                          <option value="bangla">ঐতিহ্যবাহী বাংলা সংখ্যা (দুপুর ১২ টা ৩০ মিনিট ১৫ সেকেন্ড)</option>
                        </select>
                      </div>

                      {/* Live Date toggle switcher */}
                      <div className="p-4 bg-white dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-850 flex flex-col justify-between">
                        <div>
                          <label className="block text-slate-750 dark:text-slate-200 font-bold text-xs mb-1">মেনুবারে লাইভ তারিখ (Show Date Display)</label>
                          <p className="text-[10px] text-slate-400 leading-normal mb-3">ওয়েবসাইটে সর্বদা আজকের সলিড তারিখ প্রদর্শন করবে কিনা নিয়ন্ত্রণ করুন।</p>
                        </div>
                        <div className="flex gap-2">
                          <button
                            key="date-on"
                            type="button"
                            onClick={() => setShowDate(true)}
                            className={`flex-1 py-1.5 px-3 text-xs rounded-lg border font-bold transition-all text-center cursor-pointer ${
                              showDate ? "bg-emerald-600 text-white border-emerald-700 font-black shadow-xs" : "bg-slate-50 dark:bg-slate-900 border-slate-200 text-slate-500"
                            }`}
                          >
                            তারিখ দেখান (ON)
                          </button>
                          <button
                            key="date-off"
                            type="button"
                            onClick={() => setShowDate(false)}
                            className={`flex-1 py-1.5 px-3 text-xs rounded-lg border font-bold transition-all text-center cursor-pointer ${
                              !showDate ? "bg-rose-600 text-white border-rose-700 font-black shadow-xs" : "bg-slate-50 dark:bg-slate-900 border-slate-200 text-slate-500"
                            }`}
                          >
                            তারিখ বন্ধ (OFF)
                          </button>
                        </div>
                      </div>

                      {/* Date Format Select Option list */}
                      <div className="p-4 bg-white dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-855 flex flex-col justify-between">
                        <div>
                          <label className="block text-slate-750 dark:text-slate-200 font-bold text-xs mb-1">তারিখ প্রকাশের ভাষা ও ফরম্যাট (Date Style Format)</label>
                          <p className="text-[10px] text-slate-400 leading-normal mb-3">তারিখ বাংলা ভাষায় (যেমনঃ ১৫ মে, ২০২৬) অথবা ইংরেজিতে নাকি সনাতনী বঙ্গাব্দ ক্যালেণ্ডার হিজরী চন্দ্রবর্ষ সহ কাস্টম দেখাবেন তা সিলেক্ট করুন।</p>
                        </div>
                        <select
                          value={dateFormat}
                          onChange={(e) => setDateFormat(e.target.value as any)}
                          className="w-full text-xs p-2.5 rounded-lg border bg-slate-50 dark:bg-slate-900 font-bold text-slate-800 dark:text-white"
                        >
                          <option value="bangla">বাংলা তারিখ (যেমনঃ ১৫ রমজান, বঙ্গাব্দ ১৪৩৩)</option>
                          <option value="english">ইংরেজি গ্রেগোরিয়ান ডেট (15th June, 2026)</option>
                          <option value="both">যুগ্ম বাংলা ও ইংরেজি কাস্টম (Bengali & English Mixed)</option>
                        </select>
                      </div>

                    </div>
                  </div>

                </div>

                <button
                  type="button"
                  onClick={handleSaveSettings}
                  className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-xl transition-all cursor-pointer text-center shadow-md shadow-emerald-500/10 mt-4 text-xs font-heading tracking-wide uppercase flex items-center justify-center gap-2 select-none"
                >
                  <span>💾</span>
                  <span>নতুন প্রিমিয়াম ওয়েবসাইট সেটিংস সেভ করুন (Save Premium Layout Settings)</span>
                </button>
              </div>
            )}

          </div>
        )}

        {/* ------------------ TEACHER DASHBOARD PORTAL ------------------ */}
        {currentUser.role === "teacher" && (
          <div className="flex flex-col gap-8 animate-fade-in">
            {activeTab === "teacher-db" && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                
                {/* Left hand: Teacher profile info card */}
                <div className="lg:col-span-4 bg-white dark:bg-slate-855 rounded-2xl border border-slate-150 dark:border-slate-800 p-6 shadow-xs">
                  <div className="text-center pb-4 border-b">
                    <div className="w-20 h-20 rounded-full bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-700 font-bold mx-auto mb-3 border">
                      <span className="text-3xl">👨‍🏫</span>
                    </div>
                    <h3 className="font-heading font-bold text-slate-800 dark:text-white leading-tight">
                      {currentUser.name}
                    </h3>
                    <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-black mt-1 uppercase font-mono tracking-wider">
                      সহকারী শিক্ষক / Principal Portal
                    </p>
                  </div>
                  
                  <div className="space-y-3 mt-4 text-xs text-slate-600 dark:text-slate-300">
                    <p><strong>মোবাইলঃ</strong> <span className="font-mono">{currentUser.phone}</span></p>
                    <p><strong>যাদুকরী ভূমিকাঃ</strong> মাদ্রাসার দৈনিক শিক্ষার্থী রোল ও সাময়িকী পরীক্ষার ফলাফল ইনপুট দাতা।</p>
                  </div>

                  <div className="mt-6 flex flex-col gap-2">
                    <button
                      onClick={() => setActiveTab("teacher-attendance")}
                      className="w-full text-center py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer transition-all flex items-center justify-center gap-1.5"
                    >
                      <ClipboardCheck size={14} />
                      <span>রোল হাজিরা দিন (Mark Attendance)</span>
                    </button>
                    <button
                      onClick={() => setActiveTab("teacher-results")}
                      className="w-full text-center py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-xl cursor-pointer transition-all flex items-center justify-center gap-1.5"
                    >
                      <Award size={14} />
                      <span>রেজাল্ট এন্ট্রি করুন</span>
                    </button>
                  </div>
                </div>

                {/* Right hand: Student roster filterable list */}
                <div className="lg:col-span-8 bg-white dark:bg-slate-855 rounded-2xl border border-slate-150 dark:border-slate-800 p-6 shadow-xs">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b pb-4 mb-4 gap-3">
                    <div>
                      <h3 className="font-heading font-bold text-slate-855 dark:text-white flex items-center gap-1.5">
                        <Users className="text-emerald-500" />
                        <span>শিক্ষার্থী ডিরেক্টরি রোস্টার</span>
                      </h3>
                      <p className="text-[10px] text-slate-400 mt-0.5">শ্রেনী সিলেক্ট করে রোল, অভিভাবক ও মোবাইল নাম্বার দেখুন</p>
                    </div>
                    
                    <select
                      value={teacherSelectedClass}
                      onChange={(e) => setTeacherSelectedClass(e.target.value)}
                      className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-1.5 text-xs font-bold font-heading text-slate-700 dark:text-slate-350 cursor-pointer focus:outline-none"
                    >
                      {["Play", "Nursery", "First", "Second", "Third", "Fourth", "Fifth", "Jamat 1", "Jamat 2"].map((cls) => (
                        <option key={cls} value={cls}>শ্রেণীঃ {cls}</option>
                      ))}
                    </select>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-xs text-left">
                      <thead>
                        <tr className="bg-slate-50 dark:bg-slate-900 text-slate-500 font-bold border-b border-slate-100 dark:border-slate-800">
                          <th className="px-3 py-2.5">রোল</th>
                          <th className="px-3 py-2.5">শিক্ষার্থীর নাম</th>
                          <th className="px-3 py-2.5">অভিভাবকের নাম</th>
                          <th className="px-3 py-2.5">মোবাইল ফোন ও ঠিকানা</th>
                        </tr>
                      </thead>
                      <tbody>
                        {students.filter(s => s.class === teacherSelectedClass).length > 0 ? (
                          students.filter(s => s.class === teacherSelectedClass).map((stud) => (
                            <tr key={stud.id} className="border-b border-slate-100 dark:border-slate-800/60 hover:bg-slate-50/50">
                              <td className="px-3 py-3 font-mono font-bold text-emerald-600">{stud.roll}</td>
                              <td className="px-3 py-3 font-bold dark:text-white">{stud.name}</td>
                              <td className="px-3 py-3 text-slate-600 dark:text-slate-350">{stud.guardianName}</td>
                              <td className="px-3 py-3">
                                <a href={`tel:${stud.guardianPhone}`} className="text-blue-500 hover:underline font-mono block font-semibold">
                                  📞 {stud.guardianPhone}
                                </a>
                                <span className="text-[10px] text-slate-400 block">{stud.address}</span>
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={4} className="text-center py-10 text-slate-400">
                              এই শ্রেণীতে কোন শিক্ষার্থীর ডাটা এখন পর্যন্ত নিবন্ধিত হয়নি।
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            )}

            {/* Attendance entry panel tab */}
            {activeTab === "teacher-attendance" && (
              <div className="bg-white dark:bg-slate-855 rounded-2xl border border-slate-100 dark:border-slate-800 p-6 shadow-xs">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b pb-4 mb-6 gap-4">
                  <div>
                    <h3 className="font-heading font-black text-slate-855 dark:text-white flex items-center gap-1.5">
                      <ClipboardCheck className="text-emerald-600 animate-pulse" />
                      <span>শ্রেণী ভিত্তিক দৈনিক রোল হাজিরা শীট (Attendance Board)</span>
                    </h3>
                    <p className="text-[10px] text-slate-400 mt-1">শিক্ষার্থী সিলেক্ট করে দৈনিক উপস্থিত, অনুপস্থিত বা বিলম্ব রেকর্ড করুন।</p>
                  </div>
                  
                  <select
                    value={attendanceClass}
                    onChange={(e) => {
                      setAttendanceClass(e.target.value);
                      setAttendanceRecords({});
                    }}
                    className="bg-slate-50 dark:bg-slate-900 border text-xs font-bold rounded-xl px-3 py-1.5 cursor-pointer"
                  >
                    {["Play", "Nursery", "First", "Second", "Third", "Fourth", "Fifth", "Jamat 1", "Jamat 2"].map(cls => (
                      <option key={cls} value={cls}>শ্রেণীঃ {cls}</option>
                    ))}
                  </select>
                </div>

                <div className="overflow-x-auto mb-6">
                  <table className="w-full text-xs text-left">
                    <thead>
                      <tr className="bg-slate-50 dark:bg-slate-900 border-b border-slate-100 dark:border-slate-850 text-slate-500 font-bold">
                        <th className="px-3 py-2.5">রোল</th>
                        <th className="px-3 py-2.5">শিক্ষার্থীর নাম</th>
                        <th className="px-3 py-2.5">অভিভাবক ফোন</th>
                        <th className="px-3 py-2.5 text-center">উপস্থিতি রেকর্ড</th>
                      </tr>
                    </thead>
                    <tbody>
                      {students.filter(s => s.class === attendanceClass).length > 0 ? (
                        students.filter(s => s.class === attendanceClass).map(st => {
                          const currentVal = attendanceRecords[st.id] || "Present";
                          return (
                            <tr key={st.id} className="border-b border-slate-100 dark:border-slate-850/60 font-medium">
                              <td className="px-3 py-3 font-mono font-bold text-emerald-600">{st.roll}</td>
                              <td className="px-3 py-3 font-bold dark:text-white">{st.name}</td>
                              <td className="px-3 py-3 font-mono text-slate-505">{st.guardianPhone}</td>
                              <td className="px-3 py-3">
                                <div className="flex items-center justify-center gap-1.5">
                                  {["Present", "Absent", "Late"].map(stt => (
                                    <button
                                      key={stt}
                                      type="button"
                                      onClick={() => setAttendanceRecords(prev => ({ ...prev, [st.id]: stt as any }))}
                                      className={`px-2 py-1 rounded text-[10px] font-bold border transition-all cursor-pointer ${
                                        currentVal === stt
                                          ? stt === "Present" ? "bg-emerald-600 border-emerald-600 text-white" : stt === "Absent" ? "bg-rose-600 border-rose-600 text-white" : "bg-amber-500 border-amber-500 text-white"
                                          : "bg-transparent text-slate-400 border-slate-105 dark:border-slate-800 hover:bg-slate-50"
                                      }`}
                                    >
                                      {stt === "Present" ? "উপস্থিত" : stt === "Absent" ? "অনুপস্থিত" : "বিলম্বে"}
                                    </button>
                                  ))}
                                </div>
                              </td>
                            </tr>
                          );
                        })
                      ) : (
                        <tr>
                          <td colSpan={4} className="text-center py-10 text-slate-400">এই শ্রেণীতে শিক্ষার্থী ডাটা পাওয়া যায়নি।</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

                <button
                  type="button"
                  onClick={async () => {
                    const classStudents = students.filter(s => s.class === attendanceClass);
                    if (classStudents.length === 0) return;
                    
                    const list = classStudents.map(st => ({
                      studentId: st.id,
                      studentName: st.name,
                      class: st.class,
                      roll: st.roll,
                      status: attendanceRecords[st.id] || "Present",
                      date: new Date().toLocaleDateString("bn-BD", { year: "numeric", month: "long", day: "numeric" }).replace(/[\/\-]/g, " ")
                    }));
                    
                    const ok = await onAddAttendanceBulk(list);
                    if (ok) {
                      alert(`শ্রেণীঃ ${attendanceClass} এর আজকের রোল কল হাজিরা সফলভাবে ডাটাবেসে সংরক্ষণ করা হয়েছে!`);
                      setAttendanceRecords({});
                    }
                  }}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold leading-none shadow-md shadow-emerald-500/15 cursor-pointer text-center select-none font-heading"
                >
                  আজকের চূড়ান্ত দৈনিক হাজিরা ডাটাবেসে সেভ করুন (Save Attendance Sheets to Cloud)
                </button>
              </div>
            )}

            {/* Result / Exam Score input panel */}
            {activeTab === "teacher-results" && (
              <div className="bg-white dark:bg-slate-855 rounded-2xl border border-slate-100 dark:border-slate-800 p-6 shadow-xs max-w-3xl mx-auto w-full">
                <h3 className="font-heading font-black text-slate-855 dark:text-white border-b pb-3 mb-6 flex items-center gap-1.5">
                  <Award className="text-amber-500" />
                  <span>সাময়িক ও চূড়ান্ত পরীক্ষার রেজাল্ট মূল্যায়ন এন্ট্রি ফর্ম</span>
                </h3>

                <form onSubmit={handleCreateResult} className="space-y-4 text-xs font-medium">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex flex-col gap-1.5">
                      <label className="text-slate-500 font-bold flex">শিক্ষার্থী চয়ন করুনঃ *</label>
                      <select
                        value={studentId}
                        onChange={(e) => setStudentId(e.target.value)}
                        className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-xl px-3.5 py-2.5 font-bold cursor-pointer"
                        required
                      >
                        <option value="">সিলেক্ট করুন...</option>
                        {students.map(s => (
                          <option key={s.id} value={s.id}>[Roll: {s.roll}] - {s.name} ({s.class})</option>
                        ))}
                      </select>
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <label className="text-slate-500 font-bold block">পরীক্ষার সাময়িকী টার্মঃ *</label>
                      <select
                        value={examTerm}
                        onChange={(e) => setExamTerm(e.target.value as any)}
                        className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-xl px-3.5 py-2.5 cursor-pointer font-bold"
                        required
                      >
                        <option value="First Term">১ম সাময়িকী পরীক্ষা (First Term)</option>
                        <option value="Mid Term">অর্ধ-বার্ষিকী পরীক্ষা (Mid Term)</option>
                        <option value="Final Exam">বার্ষিকী চূড়ান্ত মূল্যায়ন (Final Exam)</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4 bg-slate-50/55 dark:bg-slate-900/60 p-4 rounded-xl border border-dashed">
                    <div className="flex flex-col gap-1.5">
                      <label className="text-[11px] font-bold">কুরআনুল কারীম ও তাজবিদঃ *</label>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={quran}
                        onChange={(e) => setQuran(Number(e.target.value))}
                        className="bg-white dark:bg-slate-800 border rounded-lg px-2.5 py-2 text-center font-bold"
                        required
                      />
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <label className="text-[11px] font-bold">আরবি ও সিরাত শাস্ত্রঃ *</label>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={arabic}
                        onChange={(e) => setArabic(Number(e.target.value))}
                        className="bg-white dark:bg-slate-800 border rounded-lg px-2.5 py-2 text-center font-bold"
                        required
                      />
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <label className="text-[11px] font-bold">বাংলা ভাষা ও সাহিত্যঃ *</label>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={bangla}
                        onChange={(e) => setBangla(Number(e.target.value))}
                        className="bg-white dark:bg-slate-800 border rounded-lg px-2.5 py-2 text-center font-bold"
                        required
                      />
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <label className="text-[11px] font-bold">ইংরেজি ভাষা শিক্ষাঃ *</label>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={english}
                        onChange={(e) => setEnglish(Number(e.target.value))}
                        className="bg-white dark:bg-slate-800 border rounded-lg px-2.5 py-2 text-center font-bold"
                        required
                      />
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <label className="text-[11px] font-bold">গণিত ও যুক্তিবিদ্যাঃ *</label>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={math}
                        onChange={(e) => setMath(Number(e.target.value))}
                        className="bg-white dark:bg-slate-800 border rounded-lg px-2.5 py-2 text-center font-bold"
                        required
                      />
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <label className="text-[11px] font-bold">আদাব ও কৃষ্টি (Moral Values)： *</label>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={moral}
                        onChange={(e) => setMoral(Number(e.target.value))}
                        className="bg-white dark:bg-slate-800 border rounded-lg px-2.5 py-2 text-center font-bold"
                        required
                      />
                    </div>
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="text-slate-500 font-bold block font-heading">বিশেষ কৃতিত্ব মন্তব্য ও সুপারিশাবলী (Remarks)：</label>
                    <input
                      type="text"
                      value={remarks}
                      onChange={(e) => setRemarks(e.target.value)}
                      placeholder="যেমনঃ চমৎকার হাতের লেখা এবং পড়া ভালো শিখেছে।"
                      className="bg-slate-50 dark:bg-slate-900 border rounded-xl px-3.5 py-2.5 text-xs text-slate-800 dark:text-white"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 font-bold text-white rounded-xl text-xs cursor-pointer text-center font-heading transition-all shadow-md mt-2 select-none"
                  >
                    নতুন পরীক্ষার প্রাপ্ত জিপিএ নাম্বার কার্ড ডাটাবেসে সেভ করুন (Publish Result Card Online)
                  </button>
                </form>
              </div>
            )}
          </div>
        )}

        {/* ------------------ STUDENTS & GUARDIANS ROLE BASED PANEL ------------------ */}
        {isGuardianOrStudent && (
          <div className="flex flex-col gap-8 animate-fade-in">
            {/* PROGRESS / MAIN DASHBOARD TAB */}
            {(activeTab === "guardian-db" || activeTab === "student-db") && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                
                {/* Left Hand: Student profile summary */}
                <div className="lg:col-span-4 bg-white dark:bg-slate-855 rounded-2xl border border-slate-100 dark:border-slate-800 p-6 shadow-3xs flex flex-col gap-4">
                  <div className="text-center">
                    <div className="w-20 h-20 rounded-full bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-700 font-bold mx-auto mb-3 overflow-hidden border">
                      {associatedStudent && associatedStudent.photo ? (
                        <img src={associatedStudent.photo} alt="Student" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <span>👦</span>
                      )}
                    </div>
                    <h3 className="font-heading font-black text-slate-855 dark:text-white leading-tight">
                      {associatedStudent ? associatedStudent.name : currentUser.name}
                    </h3>
                    <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold mt-1">
                      রোলঃ {associatedStudent ? associatedStudent.roll : "১০১"} | Class: {associatedStudent ? associatedStudent.class : "Play"}
                    </p>
                  </div>

                  {/* Attendance quick percentages gauges */}
                  <div className="p-4 bg-slate-50 dark:bg-slate-900/60 rounded-xl border space-y-2 mt-2 text-xs">
                    <div className="flex justify-between font-bold">
                      <span className="text-slate-550">উপস্থিতি পারসেন্টেজঃ</span>
                      <span className="text-emerald-650 font-mono">
                        {studentAttendanceList.length > 0
                          ? `${Math.round((studentAttendanceList.filter(a => a.status === "Present").length / studentAttendanceList.length) * 105)}%`
                          : "৯০%"
                        }
                      </span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                      <div className="h-full bg-emerald-500" style={{ width: studentAttendanceList.length > 0 ? `${(studentAttendanceList.filter(a => a.status === "Present").length / studentAttendanceList.length) * 100}%` : "90%" }}></div>
                    </div>
                    <span className="text-[9px] text-slate-400 block">* দৈনিক রোল কলের ভিত্তিতে স্বয়ংক্রিয় গণনাকৃত।</span>
                  </div>

                  {/* Informational properties values */}
                  <div className="space-y-1.5 text-[11px] text-slate-500 mt-2 font-semibold">
                    <p><strong>অভিভাবকের নামঃ</strong> {associatedStudent ? associatedStudent.guardianName : "আখতার হোসেন"}</p>
                    <p className="font-mono"><strong>মোবাইল নম্বরঃ</strong> {associatedStudent ? associatedStudent.guardianPhone : currentUser.phone}</p>
                    <p><strong>স্থায়ী ঠিকানাঃ</strong> {associatedStudent ? associatedStudent.address : "ঢেমুশিয়া, চকরিয়া"}</p>
                  </div>
                </div>

                {/* Right Hand: Exam grades cards list */}
                <div className="lg:col-span-8 flex flex-col gap-6 font-heading">
                  
                  <div className="bg-white dark:bg-slate-855 rounded-2xl border border-slate-100 dark:border-slate-800 p-6 shadow-3xs flex flex-col gap-4">
                    <h3 className="font-heading font-black text-slate-850 dark:text-white border-b pb-3 flex items-center gap-1.5">
                      <Award className="text-amber-500 animate-float" />
                      <span>সাময়িক পরীক্ষার একাডেমিক মূল্যায়ন জিপিএ রিপোর্ট (Report Card)</span>
                    </h3>

                    {studentGrades.length > 0 ? (
                      studentGrades.map((res) => (
                        <div key={res.id} className="p-4 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 flex justify-between items-center text-xs">
                          <div>
                            <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[9px] font-bold uppercase">{res.term}</span>
                            <h4 className="font-bold text-slate-800 dark:text-white mt-1.5 font-heading">প্রাপ্ত মোট মার্স্কঃ {res.totalMarks} / ৬০০</h4>
                            <p className="text-[10px] text-slate-400 mt-1 italic">মন্তব্যঃ "${res.remarks}"</p>
                          </div>

                          <div className="text-right">
                            <span className="block text-sm font-black font-mono text-emerald-600 leading-none">{res.gpa.toFixed(2)}</span>
                            <span className="text-[10px] text-slate-400 mt-1 block font-bold">গ্রেডঃ {res.grade}</span>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-10 text-slate-450 bg-slate-50/50 rounded-xl">
                        <CheckSquare size={32} className="mx-auto mb-2 opacity-35" />
                        <p className="text-[11px] font-bold">আপনার প্রথম সাময়িকী বা বার্ষিক পরীক্ষার খাতা রেজাল্ট এখনও ডেটাবেসে প্রকাশ করা হয়নি।</p>
                      </div>
                    )}
                  </div>

                  {/* Notices list widgets */}
                  <div className="bg-white dark:bg-slate-855 rounded-2xl border border-slate-100 dark:border-slate-800 p-6 shadow-3xs flex flex-col gap-4">
                    <h3 className="font-heading font-black text-slate-855 dark:text-white border-b pb-3">সাম্প্রতিক গুরুত্বপূর্ণ মাদ্রাসা নোটিশ সমুহ</h3>
                    
                    <div className="flex flex-col gap-3">
                      {notices.map((noti) => (
                        <div key={noti.id} className="p-3 bg-slate-50 rounded-xl text-xs flex justify-between items-start gap-4">
                          <div>
                            <span className="font-bold text-[9px] bg-emerald-100 text-emerald-800 px-2 rounded-sm uppercase">{noti.category}</span>
                            <h4 className="font-bold mt-1 text-slate-800 font-heading">{noti.title}</h4>
                            <p className="text-[11px] text-slate-505 mt-1 leading-normal">{noti.content}</p>
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono shrink-0 whitespace-nowrap">{noti.date}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>

              </div>
            )}

            {/* BKash / Nagad payment form and previous logs list */}
            {activeTab === "guardian-payments" && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                
                {/* Pay form left column */}
                <div className="lg:col-span-12 xl:col-span-5 bg-white dark:bg-slate-855 rounded-2xl border border-slate-150 dark:border-slate-800 p-6 shadow-xs">
                  <h3 className="font-heading font-bold text-slate-855 dark:text-white border-b pb-3 mb-4 flex items-center gap-1.5">
                    <CreditCard className="text-emerald-600 animate-float" />
                    <span>অনলাইন বেতন ও ফি প্রদান ফরম (Digital Payment checkout)</span>
                  </h3>

                  {paySuccessMsg && (
                    <div className="mb-4 p-3 bg-emerald-100 text-emerald-850 border border-emerald-300 text-xs rounded-xl font-bold">
                      🎉 {paySuccessMsg}
                    </div>
                  )}

                  <form
                    onSubmit={async (e) => {
                      e.preventDefault();
                      if (!payFormStudentName || !payFormTxid) {
                        alert("দয়া করে শিক্ষার্থীর নাম ও লেনদেনের ট্রানজেকশন (TxID) এন্ট্রি করুন!");
                        return;
                      }
                      
                      const payObj = {
                        studentName: payFormStudentName,
                        class: payFormClass,
                        paymentType: payFormType,
                        paymentMethod: payFormMethod,
                        amount: payFormAmount,
                        txid: payFormTxid,
                        status: "Verified",
                        date: new Date().toLocaleDateString("bn-BD", { year: "numeric", month: "long", day: "numeric" }).replace(/[\/\-]/g, " ")
                      };
                      
                      const ok = onAddPayment ? await onAddPayment(payObj) : false;
                      if (ok || !onAddPayment) {
                        setPaySuccessMsg("আপনার পেমেন্ট রেকর্ডটি সফলভাবে সম্পন্ন হয়েছে ও বিকাশ/নগদ রসিদ স্বয়ংক্রিয়ভাবে সেভ হয়েছে!");
                        setPayFormStudentName("");
                        setPayFormTxid("");
                        setTimeout(() => setPaySuccessMsg(""), 5050);
                      }
                    }}
                    className="space-y-4 text-xs font-semibold"
                  >
                    <div className="flex flex-col gap-1.5 font-heading">
                      <label className="text-slate-550 font-bold block">শিক্ষার্থীর নামঃ *</label>
                      <input
                        type="text"
                        value={payFormStudentName}
                        onChange={(e) => setPayFormStudentName(e.target.value)}
                        placeholder="যেমনঃ আব্দুল্লাহ আল মোস্তফা"
                        className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2.5 font-bold animate-fade-in focus:outline-none"
                        required
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex flex-col gap-1.5 font-heading">
                        <label className="text-slate-550 font-bold select-none block">শ্রেণী সিলেক্ট করুনঃ *</label>
                        <select
                          value={payFormClass}
                          onChange={(e) => setPayFormClass(e.target.value)}
                          className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 cursor-pointer font-bold focus:outline-none"
                        >
                          {["Play", "Nursery", "First", "Second", "Third", "Fourth", "Fifth", "Jamat 1", "Jamat 2"].map((cls) => (
                            <option key={cls} value={cls}>শ্রেণীঃ {cls}</option>
                          ))}
                        </select>
                      </div>

                      <div className="flex flex-col gap-1.5 font-heading">
                        <label className="text-slate-550 font-bold block">পেমেন্ট টাইপঃ *</label>
                        <select
                          value={payFormType}
                          onChange={(e) => setPayFormType(e.target.value)}
                          className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 cursor-pointer font-bold focus:outline-none"
                        >
                          <option value="Tuition Fee">মাসিক বেতন (Monthly Tuition)</option>
                          <option value="Admission Fee">ভর্তি ফি (Admission Fee)</option>
                          <option value="Exam Fee">পরীক্ষার ফি (Exam Fee)</option>
                          <option value="Session Fee">সেশান ফি (Session Fee)</option>
                          <option value="Donation">দান ও অনুদান (Charity)</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex flex-col gap-1.5 font-heading">
                        <label className="text-slate-550 font-bold block">পরিশোধের গেটওয়েঃ *</label>
                        <select
                          value={payFormMethod}
                          onChange={(e) => setPayFormMethod(e.target.value)}
                          className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 cursor-pointer font-bold focus:outline-none"
                        >
                          <option value="bKash">বিকাশ (bKash)</option>
                          <option value="Nagad">নগদ (Nagad)</option>
                          <option value="Rocket">রকেট (Rocket)</option>
                        </select>
                      </div>

                      <div className="flex flex-col gap-1.5 font-heading font-mono mr-1">
                        <label className="text-slate-550 font-bold block">পরিমাণ (BDT Amount)： *</label>
                        <input
                          type="number"
                          value={payFormAmount}
                          onChange={(e) => setPayFormAmount(Number(e.target.value))}
                          className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-3 py-2 text-center font-black text-slate-800 dark:text-white focus:outline-none"
                          required
                        />
                      </div>
                    </div>

                    <div className="flex flex-col gap-1.5 p-3 rounded-lg bg-orange-50/50 dark:bg-orange-950/20 border border-amber-300 font-heading">
                      <span className="text-[10px] text-amber-800 dark:text-amber-400 block font-bold leading-relaxed mb-1">
                        * মাদ্রাসার bKash/Nagad Merchant Number (01812345678) নম্বরে টাকা পাঠিয়ে নিচে প্রাপ্ত TxNum টি এন্ট্রি করে সাবমিট করুন।
                      </span>
                      <label className="text-slate-550 font-bold block font-heading">বিকাশ/নগদ ট্রানজেকশন নাম্বার (Transaction TxID)： *</label>
                      <input
                        type="text"
                        value={payFormTxid}
                        onChange={(e) => setPayFormTxid(e.target.value)}
                        placeholder="যেমনঃ TQX9A8S6D5"
                        className="bg-white dark:bg-slate-800 border border-slate-205 dark:border-slate-800 rounded-xl px-3 py-2.5 font-mono uppercase font-black text-center text-emerald-650 focus:outline-none"
                        required
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-center shadow-md shadow-emerald-500/10 cursor-pointer select-none font-heading"
                    >
                      পেমেন্ট সাবমিট করুন (Send BDT Payment Record)
                    </button>
                  </form>
                </div>

                {/* Receipts history logs right column */}
                <div className="lg:col-span-12 xl:col-span-7 bg-white dark:bg-slate-855 rounded-2xl border border-slate-150 dark:border-slate-800 p-6 shadow-xs font-heading">
                  <h3 className="font-heading font-bold text-slate-855 dark:text-white border-b pb-3 mb-4">
                    আমার ডিজিটাল বেতন রসিদ ও পেমেন্ট হিস্ট্রি স্লিপ (Cash Receipts Audit Trail)
                  </h3>

                  <div className="overflow-x-auto">
                    <table className="w-full text-xs text-left">
                      <thead>
                        <tr className="bg-slate-50 dark:bg-slate-900 border-b border-slate-205 text-slate-550 font-bold font-heading">
                          <th className="px-3 py-2.5 font-bold">ছাত্র ও শ্রেণী</th>
                          <th className="px-3 py-2.5 font-bold">পেমেন্ট বিবরণ</th>
                          <th className="px-3 py-2.5 font-bold">পদ্ধতি ও TxID</th>
                          <th className="px-3 py-2.5 text-right font-bold">পরিমাণ এবং স্ট্যাটাস</th>
                        </tr>
                      </thead>
                      <tbody>
                        {payments.length > 0 ? (
                          payments.map((p) => (
                            <tr key={p.id || p.txid} className="border-b border-slate-100 dark:border-slate-850/60 font-medium font-mono">
                              <td className="px-3 py-3">
                                <span className="font-bold dark:text-white block font-heading">{p.studentName || "আব্দুল্লাহ"}</span>
                                <span className="text-[10px] text-slate-400 block font-heading">Class: {p.class}</span>
                              </td>
                              <td className="px-3 py-3 font-semibold text-slate-700 dark:text-slate-350 font-heading">
                                {p.paymentType === "Tuition Fee" ? "মাসিক বেতন" : p.paymentType === "Admission Fee" ? "ভর্তি ফি" : p.paymentType === "Exam Fee" ? "পরীক্ষার ফি" : p.paymentType || "বেতন ও ফি"}
                                <span className="text-[9px] text-slate-400 block mt-1">{p.date || "আজকে"}</span>
                              </td>
                              <td className="px-3 py-3 font-mono">
                                <span className="font-bold block text-blue-650 dark:text-blue-400 text-[10px]">{p.paymentMethod}</span>
                                <span className="text-[10px] uppercase tracking-wider font-extrabold text-amber-600 block mt-0.5">{p.txid || "TRX9999"}</span>
                              </td>
                              <td className="px-3 py-3 text-right font-heading">
                                <span className="font-black font-mono block text-slate-800 dark:text-white">{p.amount} BDT</span>
                                <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold text-[8px] uppercase mt-1">
                                  {p.status || "Verified"}
                                </span>
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={4} className="text-center py-10 text-slate-400 font-semibold font-heading">কোন লেনদেন রেকর্ড পাওয়া যায়নি।</td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            )}

            {/* Inquire feedback form portal */}
            {activeTab === "guardian-inquiry" && (
              <div className="bg-white dark:bg-slate-855 rounded-2xl border border-slate-100 dark:border-slate-800 p-6 shadow-xs max-w-2xl mx-auto w-full animate-fade-in">
                <h3 className="font-heading font-black text-slate-855 dark:text-white border-b pb-3 mb-4 flex items-center gap-1.5">
                  <Mail className="text-emerald-600 animate-pulse" />
                  <span>মাদ্রাসার শ্রেণী শিক্ষকের সাথে যোগাযোগ ও ইনকোয়ারী ফরম</span>
                </h3>

                {guardianInquirySubmitSuccess ? (
                  <div className="p-6 text-center text-xs space-y-2 animate-fade-in font-heading">
                    <Send size={36} className="mx-auto text-emerald-600 animate-bounce" />
                    <h4 className="font-bold text-slate-855 font-heading">আপনার অভিযোগ/পরামর্শ পত্রটি সরাসরি অধ্যক্ষ এর টেবিলে নিবন্ধিত হয়েছে।</h4>
                    <p className="text-slate-550">আমরা শীঘ্রই আপনার অভিভাবক নম্বরে যোগাযোগ করবো। জাজাকাল্লাহ খাইরান!</p>
                    <button
                      onClick={() => setGuardianInquirySubmitSuccess(false)}
                      className="px-4 py-2 bg-emerald-600 text-white rounded-lg font-bold text-[11px] mt-2 cursor-pointer shadow-xs"
                    >
                      নতুন বার্তা লিখুন
                    </button>
                  </div>
                ) : (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (!guardianMessageText.trim()) return;
                      setGuardianInquirySubmitSuccess(true);
                      setGuardianMessageText("");
                    }}
                    className="space-y-4 text-xs font-semibold"
                  >
                    <div className="space-y-1 font-heading">
                      <label className="text-slate-500 font-bold block">শ্রেণী শিক্ষকের মন্তব্য বা আপনার পরামর্শ পত্রটি লিখুনঃ *</label>
                      <textarea
                        value={guardianMessageText}
                        onChange={(e) => setGuardianMessageText(e.target.value)}
                        rows={5}
                        placeholder="আপনার সন্তানের কুশলাদি বা কোনো পরামর্শ এখানে বিস্তারিত লিখুন। যেমনঃ আব্দুল্লাহ এর আরবী উচ্চারণ কিছুটা দুর্বল, এ বিষয়ে শ্রেণী শিক্ষকের গভীর মনোযোগ কামনা করছি।"
                        className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-205 dark:border-slate-800 p-3 text-slate-800 dark:text-white focus:outline-none rounded-xl font-bold"
                        required
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-center cursor-pointer select-none font-heading font-bold"
                    >
                      পরামর্শপত্র প্রেরণ করুন (Send Message to Principal)
                    </button>
                  </form>
                )}
              </div>
            )}

            {/* Student Notices board portal tab */}
            {activeTab === "student-notices" && (
              <div className="bg-white dark:bg-slate-855 rounded-2xl border border-slate-100 dark:border-slate-800 p-6 shadow-xs max-w-4xl mx-auto w-full flex flex-col gap-4 animate-fade-in font-heading">
                <h3 className="font-heading font-black text-slate-850 dark:text-white border-b pb-3">মাদ্রাসা নোটিশ বোর্ড (School Notice Board)</h3>
                
                <div className="flex flex-col gap-3">
                  {notices && notices.map((noti) => (
                    <div key={noti.id} className="p-4 bg-slate-50 rounded-xl text-xs flex justify-between items-start gap-4">
                      <div>
                        <span className="font-bold text-[10px] bg-emerald-100 text-emerald-800 px-2.5 py-0.5 rounded uppercase">{noti.category}</span>
                        <h4 className="font-bold mt-2 text-slate-800 text-sm font-heading">{noti.title}</h4>
                        <p className="text-[12px] text-slate-650 mt-1 leading-relaxed whitespace-pre-line">{noti.content}</p>
                      </div>
                      <span className="text-xs text-slate-400 font-mono shrink-0 whitespace-nowrap">{noti.date}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>
        )}

      </div>
    </div>
  );
}
