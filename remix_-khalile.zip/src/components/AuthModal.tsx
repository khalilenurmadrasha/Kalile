import React, { useState } from "react";
import { User, Teacher, Student } from "../types";
import { LogIn, UserPlus, HelpCircle, X, ShieldAlert, Smartphone, Mail, Lock } from "lucide-react";
import { isStaticOrFailedEnv, forceLocalStorageDB, getLocalValue, INITIAL_TEACHERS, INITIAL_STUDENTS } from "../utils/localDB";

interface AuthModalProps {
  onClose: () => void;
  onLoginSuccess: (user: User) => void;
  initialMode: "login" | "register";
}

export default function AuthModal({ onClose, onLoginSuccess, initialMode }: AuthModalProps) {
  const [mode, setMode] = useState<"login" | "register" | "forgot">(initialMode);
  const [loginMethod, setLoginMethod] = useState<"email" | "phone">("email");
  const [loading, setLoading] = useState(false);

  // Email form values
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);

  // Phone form values
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);

  // Register values
  const [registerName, setRegisterName] = useState("");
  const [registerEmail, setRegisterEmail] = useState("");
  const [registerPhone, setRegisterPhone] = useState("");
  const [registerPassword, setRegisterPassword] = useState("");

  const handleEmailLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loginMethod === "email" && !email) return;
    if (loginMethod === "phone" && !phone) return;

    setLoading(true);

    let apiSuccess = false;
    
    // 1. Try real backend Express login if not explicitly configured in static fallback mode
    if (!isStaticOrFailedEnv()) {
      try {
        const response = await fetch("/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            email: email,
            phone: phone,
            password: password,
            type: loginMethod
          }),
        });

        const contentType = response.headers.get("content-type");
        if (response.ok && contentType && contentType.includes("application/json")) {
          const resData = await response.json();
          setLoading(false);
          apiSuccess = true;

          if (resData.success && resData.user) {
            onLoginSuccess(resData.user);
            onClose();
            return;
          } else {
            alert(resData.error || "লগইন তথ্য ও ডাটা সফল মিল পাওয়া যায়নি!");
            return;
          }
        }
      } catch (err) {
        console.warn("Express server authentication failed, switching to local responsive authentication layer:", err);
      }
    }

    // 2. Client-Side Static / Local Storage / Netlify Fallback
    forceLocalStorageDB(); // mark this browser as offline-first local mode
    
    // Slight simulated wait for loading state to provide native premium feel
    setTimeout(() => {
      setLoading(false);
      
      const savedTeachers = getLocalValue<Teacher[]>("teachers", INITIAL_TEACHERS);
      const savedStudents = getLocalValue<Student[]>("students", INITIAL_STUDENTS);

      if (loginMethod === "email") {
        const normEmail = email.toLowerCase().trim();
        // Admin
        if (normEmail === "khalilenurmadrasha65@gmail.com") {
          onLoginSuccess({
            id: "admin_1",
            email: normEmail,
            name: "মাওলানা হাফেজ মোঃ ছিদ্দিকুল্লাহ (Admin)",
            role: "admin",
            phone: "01812345678",
            createdAt: new Date().toISOString()
          });
          onClose();
          return;
        }

        // Special Principal/Developer login (Teacher role)
        if (normEmail === "hfmdsiddikramu1@gmail.com") {
          onLoginSuccess({
            id: "t_1",
            email: normEmail,
            name: "মাওলানা হাফেজ মোঃ ছিদ্দিকুল্লাহ (Principal)",
            role: "teacher",
            phone: "01823456781",
            createdAt: new Date().toISOString()
          });
          onClose();
          return;
        }

        // Teacher
        const teacher = savedTeachers.find(t => t.email.toLowerCase() === normEmail);
        if (teacher) {
          onLoginSuccess({
            id: teacher.id,
            email: teacher.email,
            name: teacher.name,
            phone: teacher.phone,
            role: "teacher",
            createdAt: new Date().toISOString()
          } as any);
          onClose();
          return;
        }

        // Error message for wrong email in client side
        alert("ভুল ইমেইল বা পাসওয়ার্ড! এডমিন লগইনের জন্য প্রবেশ করুন: khalilenurmadrasha65@gmail.com");
      } else {
        // Phone login
        const normPhone = phone.trim();
        
        // Admin phone
        if (normPhone === "01812345678") {
          onLoginSuccess({
            id: "admin_1",
            email: "khalilenurmadrasha65@gmail.com",
            name: "মাওলানা হাফেজ মোঃ ছিদ্দিকুল্লাহ (Admin/Principal)",
            phone: "01812345678",
            role: "admin",
            createdAt: new Date().toISOString()
          });
          onClose();
          return;
        }

        // Students / Parents lookup
        const student = savedStudents.find(s => s.guardianPhone === normPhone);
        if (student) {
          onLoginSuccess({
            id: student.id,
            email: `${student.id}@madrasha.com`,
            name: student.guardianName + " (Guardian of " + student.name + ")",
            phone: student.guardianPhone,
            role: "guardian",
            createdAt: new Date().toISOString(),
            studentDetails: student
          } as any);
          onClose();
          return;
        }

        // Default guardian mock success
        onLoginSuccess({
          id: "s_default",
          email: "student@madrasha.com",
          name: "অভিভাবক (সম্মানিত অভিভাবক)",
          phone: normPhone,
          role: "guardian",
          createdAt: new Date().toISOString()
        });
        onClose();
      }
    }, 400);
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!registerName || !registerEmail || !registerPhone || !registerPassword) {
      alert("সকল তারকাচিহ্নিত তথ্য সম্পূর্ণ করুন!");
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      // Automatically log inside as student/guardian roles
      onLoginSuccess({
        id: "usr_" + Date.now(),
        email: registerEmail.toLowerCase().trim(),
        phone: registerPhone,
        name: registerName,
        role: "guardian",
        createdAt: new Date().toISOString()
      });
      onClose();
    }, 1500);
  };

  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert("একটি পাসওয়ার্ড পাসকোড রিকভারি লিঙ্ক আপনার ইমেইলে প্রেরণ করা হয়েছে!");
    setMode("login");
  };

  const handleGoogleMockLogin = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onLoginSuccess({
        id: "g_usr_" + Date.now(),
        email: "guest_parent@gmail.com",
        name: "পছন্দনীয় গেস্ট অভিভাবক",
        role: "guardian",
        createdAt: new Date().toISOString()
      });
      onClose();
    }, 1000);
  };

  return (
    <div id="authentication-backdrop" className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div id="auth-modal-panel" className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl max-w-sm w-full p-6 shadow-2xl relative animate-float-quick">
        
        {/* Close trigger */}
        <button
          onClick={onClose}
          className="absolute top-4 p-1 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 right-4 cursor-pointer"
          aria-label="Close Authentication Form"
        >
          <X size={18} />
        </button>

        {/* Modal content switcher */}
        {mode === "login" && (
          <div>
            <div className="text-center mb-6">
              <span className="text-xl">🕌</span>
              <h3 className="font-heading text-base font-black text-slate-850 dark:text-white mt-2">
                মাদ্রাসা পোর্টাল লগইন (Portal Login)
              </h3>
              <p className="text-[10px] text-slate-400 mt-1">আপনার অ্যাকাউন্ট রোল সিলেক্ট করে প্রবেশ করুন।</p>
            </div>

            {/* Toggle Mail vs Phone Login */}
            <div className="grid grid-cols-2 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg mb-4 text-xs font-bold">
              <button
                type="button"
                onClick={() => setLoginMethod("email")}
                className={`py-1.5 rounded-md transition-all cursor-pointer ${
                  loginMethod === "email" ? "bg-white dark:bg-slate-900 shadow-3xs text-emerald-600 dark:text-emerald-400" : "text-slate-400"
                }`}
              >
                ইমেইল লগইন
              </button>
              <button
                type="button"
                onClick={() => setLoginMethod("phone")}
                className={`py-1.5 rounded-md transition-all cursor-pointer ${
                  loginMethod === "phone" ? "bg-white dark:bg-slate-900 shadow-3xs text-emerald-600 dark:text-emerald-400" : "text-slate-400"
                }`}
              >
                মোবাইল নম্বর
              </button>
            </div>

            <form onSubmit={handleEmailLoginSubmit} className="flex flex-col gap-4 text-xs">
              
              {loginMethod === "email" ? (
                <>
                  <div>
                    <label className="block text-slate-500 font-bold mb-1">ইমেইল ঠিকানা (Email Input)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-3 text-slate-400"><Mail size={14} /></span>
                      <input
                        type="email"
                        id="auth-email-field"
                        required
                        placeholder="যেমন: parent@gmail.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full text-xs pl-9 pr-3 py-2.5 rounded-lg border border-slate-200 dark:border-slate-755 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500 font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between mb-1">
                      <label className="text-slate-500 font-bold">পাসওয়ার্ড (Password)</label>
                      <button
                        type="button"
                        onClick={() => setMode("forgot")}
                        className="text-[10px] text-emerald-600 hover:underline font-bold"
                      >
                        পাসওয়ার্ড ভুলে গেছেন?
                      </button>
                    </div>
                    <div className="relative">
                      <span className="absolute left-3 top-3 text-slate-400"><Lock size={14} /></span>
                      <input
                        type="password"
                        required
                        placeholder="••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full text-xs pl-9 pr-3 py-2.5 rounded-lg border border-slate-200 dark:border-slate-755 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                      />
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div>
                    <label className="block text-slate-500 font-bold mb-1">মোবাইল নম্বর (Phone Number)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-3 text-slate-400"><Smartphone size={14} /></span>
                      <input
                        type="tel"
                        required
                        placeholder="০১৮XXXXXXXX"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full text-xs pl-10 pr-3 py-2.5 rounded-lg border border-slate-200 dark:border-slate-755 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500 font-mono"
                      />
                    </div>
                  </div>

                  {otpSent ? (
                    <div>
                      <label className="block text-slate-500 font-bold mb-1">প্রেরিত OTP পাসকোড</label>
                      <input
                        type="text"
                        required
                        placeholder="৬ সংখ্যার ওটিপি কোড"
                        value={otp}
                        onChange={(e) => setOtp(e.target.value)}
                        className="w-full text-xs p-2.5 rounded-lg border focus:outline-emerald-500 font-mono text-center tracking-[0.2em]"
                      />
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        if (phone.length >= 10) setOtpSent(true);
                        else alert("সঠিক মোবাইল নম্বর টাইপ করুন!");
                      }}
                      className="w-full py-2 bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400 rounded-lg hover:bg-emerald-100 inline-flex items-center justify-center font-bold"
                    >
                      ভেরিফিকেশন কোড পাঠান
                    </button>
                  )}
                </>
              )}

              {/* Keep Remember inputs */}
              <div className="flex items-center gap-1.5 font-bold text-slate-500 select-none">
                <input
                  type="checkbox"
                  id="remember-me"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-555"
                />
                <label htmlFor="remember-me">আমাকে লগইন রাখুন (Remember Me)</label>
              </div>

              {/* Admin login hint details */}
              <div className="p-2 bg-amber-50 rounded-lg border border-amber-200 text-[10px] text-amber-900 leading-normal flex gap-1.5">
                <ShieldAlert className="shrink-0 text-amber-600" size={14} />
                <div>
                  <strong>সুপার এডমিন লগারঃ </strong>
                  <span className="font-mono bg-white px-1 select-all">khalilenurmadrasha65@gmail.com</span>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full mt-2 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <LogIn size={14} />
                <span>{loading ? "অপেক্ষা করুন..." : "পোর্টালে প্রবেশ করুন"}</span>
              </button>
            </form>

            {/* Google OAuth simulation link */}
            <div className="mt-4 border-t border-slate-100 dark:border-slate-800 pt-4 flex flex-col gap-3">
              <button
                type="button"
                onClick={handleGoogleMockLogin}
                className="w-full py-2.5 border border-slate-200 dark:border-slate-755 hover:bg-slate-50 rounded-xl text-center flex items-center justify-center gap-2 cursor-pointer font-bold text-slate-700 dark:text-slate-300"
              >
                <span>🌍</span>
                <span>Google একাউন্ট দিয়ে লগইন (Fast Link)</span>
              </button>

              <div className="text-center text-slate-450 text-[11px] font-medium mt-1">
                কোন রেজিস্ট্রেশন করা অ্যাকাউন্ট নেই?{" "}
                <button
                  type="button"
                  onClick={() => setMode("register")}
                  className="text-emerald-600 font-bold hover:underline cursor-pointer"
                >
                  নতুন নিব্ন্ধন করুন
                </button>
              </div>
            </div>
          </div>
        )}

        {/* MODE 2: Sign-up Inputs */}
        {mode === "register" && (
          <div>
            <div className="text-center mb-6">
              <h3 className="font-heading text-base font-black text-slate-850 dark:text-white">
                মাদ্রাসা পোর্টাল রেজিস্ট্রেশন (Registration)
              </h3>
              <p className="text-[10px] text-slate-400 mt-1">ভর্তিচ্ছু শিক্ষার্থী অভিভাবকের পোর্টাল খোলার তালিকা ফর্ম।</p>
            </div>

            <form onSubmit={handleRegisterSubmit} className="flex flex-col gap-3 text-xs font-semibold">
              <div>
                <label className="block text-slate-500 mb-1">অভিভাবকের পূর্ণ নাম *</label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: মোহাম্মদ ইউনুস কায়সার"
                  value={registerName}
                  onChange={(e) => setRegisterName(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-lg border border-slate-200 dark:border-slate-755 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-500 mb-1">ইমেইল ঠিকানা *</label>
                <input
                  type="email"
                  required
                  placeholder="parent@madrasha.com"
                  value={registerEmail}
                  onChange={(e) => setRegisterEmail(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-lg border border-slate-200 dark:border-slate-755 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-500 mb-1">মোবাইল নম্বর *</label>
                <input
                  type="tel"
                  required
                  placeholder="০১৭XXXXXXXX"
                  value={registerPhone}
                  onChange={(e) => setRegisterPhone(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-lg border border-slate-200 dark:border-slate-755 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-500 mb-1">গোপন পাসওয়ার্ড তৈরি করুন *</label>
                <input
                  type="password"
                  required
                  placeholder="পাসওয়ার্ড তৈরি করুন (সর্বনিম্ন ৬ অক্ষর)"
                  value={registerPassword}
                  onChange={(e) => setRegisterPassword(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-lg border border-slate-200 dark:border-slate-755 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full mt-3 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition-all cursor-pointer"
              >
                {loading ? "নিবন্ধন হচ্ছে..." : "নিবন্ধন সম্পূর্ণ করুন"}
              </button>

              <div className="text-center text-slate-450 text-[11px] mt-2">
                ইতিমধ্যে একটি অ্যাকাউন্ট খোলা আছে?{" "}
                <button
                  type="button"
                  onClick={() => setMode("login")}
                  className="text-emerald-600 font-bold hover:underline cursor-pointer"
                >
                  লগইন করুন
                </button>
              </div>
            </form>
          </div>
        )}

        {/* MODE 3: Forgot Pass Recovery */}
        {mode === "forgot" && (
          <div>
            <div className="text-center mb-6">
              <h3 className="font-heading text-base font-black text-slate-850 dark:text-white">
                পাসওয়ার্ড ভুলে গেছেন? (Forgot Password)
              </h3>
              <p className="text-[10px] text-slate-400 mt-1">ইমেইল প্রদান করুন, আমরা পাসকোড উদ্ধার লিঙ্ক প্রেরণ করব।</p>
            </div>

            <form onSubmit={handleForgotSubmit} className="flex flex-col gap-4 text-xs font-semibold">
              <div>
                <label className="block text-slate-500 mb-1">নিবন্ধিত ইমেইল ঠিকানা</label>
                <input
                  type="email"
                  required
                  placeholder="parent@madrasha.com"
                  className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-755 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500 font-mono"
                />
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setMode("login")}
                  className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 rounded-xl font-bold border cursor-pointer text-center"
                >
                  বাতিল করুন
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl cursor-pointer text-center shadow-md"
                >
                  লিঙ্ক পাঠান
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
