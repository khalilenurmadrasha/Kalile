import React, { useState } from "react";
import { GalleryItem, User } from "../types";
import { Grid, Image, Plus, Trash2, X, Eye } from "lucide-react";

interface GallerySectionProps {
  gallery: GalleryItem[];
  onAddGallery: (item: Omit<GalleryItem, "id" | "date">) => Promise<boolean>;
  onDeleteGallery: (id: string) => Promise<boolean>;
  currentUser: User | null;
}

export default function GallerySection({ gallery, onAddGallery, onDeleteGallery, currentUser }: GallerySectionProps) {
  const isAdmin = currentUser?.role === "admin" || currentUser?.email === "khalilenurmadrasha65@gmail.com" || currentUser?.email === "hfmdsiddikramu1@gmail.com";
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [modalOpen, setModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  
  // Lightbox Preview State
  const [lightboxImg, setLightboxImg] = useState<string | null>(null);

  // Add Item state
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");
  const [category, setCategory] = useState<any>("Campus");

  const categories = ["Campus", "Classroom", "Event", "Sports"];

  const handleAddImage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url || !title) return;

    setLoading(true);
    const success = await onAddGallery({
      title,
      url,
      category
    });
    setLoading(false);
    if (success) {
      setModalOpen(false);
      setTitle("");
      setUrl("");
    }
  };

  const filteredItems = gallery.filter((item) => {
    return selectedCategory === "All" || item.category === selectedCategory;
  });

  return (
    <div id="madrasha-gallery-portfolio" className="py-12 bg-slate-50 dark:bg-slate-900 min-h-screen transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest font-mono">Our Memories</span>
            <h2 className="font-heading text-xl sm:text-2xl font-black text-slate-800 dark:text-white leading-tight mt-1">
              মাদ্রাসার ছবি গ্যালারি (Gallery Store)
            </h2>
            <div className="w-12 h-1 bg-emerald-600 dark:bg-emerald-500 rounded-full mt-3"></div>
          </div>

          {isAdmin && (
            <button
              id="admin-add-gallery-btn"
              onClick={() => setModalOpen(true)}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Plus size={16} />
              <span>নতুন চিত্র আপলোড</span>
            </button>
          )}
        </div>

        {/* Categories togglers */}
        <div className="flex gap-1.5 overflow-x-auto pb-4 mb-8 scrollbar-none">
          {["All", ...categories].map((cat) => (
            <button
              key={cat}
              id={`gallery-cat-toggle-${cat}`}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer shrink-0 ${
                selectedCategory === cat
                  ? "bg-emerald-600 text-white shadow-xs"
                  : "bg-white dark:bg-slate-850 text-slate-600 dark:text-slate-350 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-100 dark:border-slate-800"
              }`}
            >
              {cat === "All" ? "সব চিত্রসমূহ" : cat}
            </button>
          ))}
        </div>

        {/* Gallery Grids */}
        {filteredItems.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className="bg-white dark:bg-slate-850 rounded-2xl border border-slate-100 dark:border-slate-800 overflow-hidden shadow-3xs group relative h-64 hover:shadow-md transition-all"
              >
                <img
                  src={item.url}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-104 transition-all duration-500"
                  referrerPolicy="no-referrer"
                />
                
                {/* Overlay details */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-4 z-10 text-white">
                  
                  {isAdmin ? (
                    <button
                      onClick={() => {
                        if (confirm("এই ছবিটি গ্যালারী থেকে চিরতরে মুছে ফেলতে চান?")) {
                          onDeleteGallery(item.id);
                        }
                      }}
                      className="self-end p-2 rounded-full bg-rose-600 hover:bg-rose-700 transition-colors cursor-pointer"
                      title="ডিলিট ছবি"
                    >
                      <Trash2 size={12} />
                    </button>
                  ) : (
                    <span></span>
                  )}

                  <div className="flex flex-col gap-1.5">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-sm bg-emerald-600 self-start">
                      {item.category}
                    </span>
                    <h4 className="text-xs font-bold truncate pr-6">{item.title}</h4>
                    <button
                      onClick={() => setLightboxImg(item.url)}
                      className="mt-2 text-[10px] font-bold text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <Eye size={12} />
                      <span>রিয়েল ছবি দেখুন (Preview)</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-white dark:bg-slate-850 rounded-2xl border border-slate-150 dark:border-slate-800 text-slate-400">
            <Image size={36} className="mx-auto mb-2" />
            <p className="text-xs">গ্যালারিতে ক্যাটাগরি ছবি নেই!</p>
          </div>
        )}

        {/* Lightbox previews modal popup */}
        {lightboxImg && (
          <div
            className="fixed inset-0 bg-black/90 p-4 flex items-center justify-center z-50 animate-fade-in cursor-zoom-out"
            onClick={() => setLightboxImg(null)}
          >
            <div className="relative max-w-5xl w-full max-h-[85vh] flex items-center justify-center">
              <button
                onClick={() => setLightboxImg(null)}
                className="absolute -top-12 right-0 p-2 text-white bg-slate-800/80 rounded-full hover:bg-slate-700 transition-colors cursor-pointer"
                aria-label="Close Lightbox"
              >
                <X size={20} />
              </button>
              <img
                src={lightboxImg}
                alt="Lightbox Preview"
                className="max-w-full max-h-[85vh] object-contain rounded-lg border border-slate-750"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        )}

        {/* Upload dialog inputs */}
        {modalOpen && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl relative animate-float-quick">
              <button
                onClick={() => setModalOpen(false)}
                className="absolute top-4 p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 right-4 cursor-pointer"
              >
                <X size={18} />
              </button>

              <h3 className="font-heading text-lg font-black text-slate-850 dark:text-white mb-4">
                গ্যালারিতে নতুন ছবি নথিভুক্ত করুন
              </h3>

              <form onSubmit={handleAddImage} className="flex flex-col gap-4 text-xs font-medium">
                <div>
                  <label className="block text-slate-500 dark:text-slate-400 mb-1">ছবির শিরোনাম (Image Title) *</label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: বাৎসরিক পুরস্কার বিতরণ ও মেলা"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-500 dark:text-slate-400 mb-1">ছবির টাইপ বিভাগ (Category) *</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-755 bg-white dark:bg-slate-850 text-slate-800 dark:text-white focus:outline-emerald-500"
                  >
                    <option value="Campus">Campus</option>
                    <option value="Classroom">Classroom</option>
                    <option value="Event">Event</option>
                    <option value="Sports">Sports</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-500 dark:text-slate-400 mb-1">ছবির ডিরেক্ট ওয়েব লিঙ্ক (Supported JPG/PNG/WEBP URL) *</label>
                  <input
                    type="url"
                    required
                    placeholder="https://images.unsplash.com/your-image..."
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500 font-mono"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full mt-2 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer disabled:opacity-50"
                >
                  {loading ? "সংরক্ষণ হচ্ছে..." : "যাচাই ও যোগ করুন"}
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
