import React, { useState } from "react";
import { SystemSettings, User } from "../types";
import { BookOpen, Flag, ShieldAlert, FileText, Check, Save } from "lucide-react";

interface ObjectivesProps {
  settings: SystemSettings;
  onUpdateSettings: (newSettings: Partial<SystemSettings>) => Promise<boolean>;
  currentUser: User | null;
}

export default function Objectives({ settings, onUpdateSettings, currentUser }: ObjectivesProps) {
  const isAdmin = currentUser?.role === "admin" || currentUser?.email === "khalilenurmadrasha65@gmail.com" || currentUser?.email === "hfmdsiddikramu1@gmail.com";
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  
  // Local edit states
  const [intro, setIntro] = useState(settings.introduction);
  const [islamic, setIslamic] = useState(settings.islamicEducation);
  const [moral, setMoral] = useState(settings.moralEducation);
  const [advices, setAdvices] = useState(settings.advices);
  const [missionsText, setMissionsText] = useState(settings.targetMissions.join("\n"));

  const handleSave = async () => {
    setLoading(true);
    const updatedMissions = missionsText.split("\n").filter(m => m.trim().length > 0);
    const success = await onUpdateSettings({
      introduction: intro,
      islamicEducation: islamic,
      moralEducation: moral,
      advices: advices,
      targetMissions: updatedMissions
    });
    setLoading(false);
    if (success) {
      setIsEditing(false);
    }
  };

  return (
    <div id="objectives-page" className="py-12 bg-slate-50 dark:bg-slate-900 min-h-screen transition-colors duration-300">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title Group */}
        <div className="text-center mb-10">
          <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest font-mono">Philosophy & Advices</span>
          <h2 className="font-heading text-2xl sm:text-3xl font-black text-slate-800 dark:text-white leading-tight mt-1">
            প্রতিষ্ঠানের উদ্দেশ্য ও উপদেশ (Objectives)
          </h2>
          <div className="w-12 h-1 bg-emerald-600 dark:bg-emerald-500 rounded-full mx-auto mt-3"></div>
          
          {isAdmin && (
            <div className="mt-4">
              {!isEditing ? (
                <button
                  id="admin-edit-objectives-btn"
                  onClick={() => setIsEditing(true)}
                  className="px-4 py-2 text-xs font-bold bg-amber-500 hover:bg-amber-600 text-slate-900 rounded-lg shadow-sm transition-all cursor-pointer"
                >
                  পৃষ্ঠা সম্পাদনা করুন (Edit Page Content)
                </button>
              ) : (
                <div className="flex gap-2 justify-center">
                  <button
                    id="admin-save-objectives-btn"
                    onClick={handleSave}
                    disabled={loading}
                    className="px-4 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow-sm flex items-center gap-1 cursor-pointer disabled:opacity-50"
                  >
                    <Save size={14} />
                    <span>{loading ? "সংরক্ষণ হচ্ছে..." : "সংরক্ষণ করুন (Save Changes)"}</span>
                  </button>
                  <button
                    id="admin-cancel-objectives-btn"
                    onClick={() => {
                      setIsEditing(false);
                      setIntro(settings.introduction);
                      setIslamic(settings.islamicEducation);
                      setMoral(settings.moralEducation);
                      setAdvices(settings.advices);
                      setMissionsText(settings.targetMissions.join("\n"));
                    }}
                    className="px-4 py-2 text-xs font-bold bg-slate-200 dark:bg-slate-800 text-slate-750 dark:text-slate-350 rounded-lg transition-all cursor-pointer"
                  >
                    বাতিল (Cancel)
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex flex-col gap-8">
          
          {/* Card 1: Introduction */}
          <div className="bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-3xs">
            <h3 className="text-sm font-black text-slate-850 dark:text-white pb-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
              <FileText className="text-emerald-550" size={18} />
              <span>প্রতিষ্ঠানের পরিচিতি (Introduction)</span>
            </h3>
            <div className="mt-4">
              {isEditing ? (
                <textarea
                  value={intro}
                  onChange={(e) => setIntro(e.target.value)}
                  rows={4}
                  className="w-full text-xs p-3 rounded-lg border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-900 text-slate-800 dark:text-white focus:outline-emerald-500"
                />
              ) : (
                <p className="text-xs sm:text-sm text-slate-650 dark:text-slate-300 leading-relaxed">
                  {settings.introduction}
                </p>
              )}
            </div>
          </div>

          {/* Card 2: Targets & Missions */}
          <div className="bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-3xs">
            <h3 className="text-sm font-black text-slate-850 dark:text-white pb-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
              <Flag className="text-emerald-550" size={18} />
              <span>আমাদের লক্ষ্য ও উদ্দেশ্য (Our Targets)</span>
            </h3>
            <div className="mt-4">
              {isEditing ? (
                <div>
                  <p className="text-[10px] text-slate-400 mb-1">প্রতি লাইনে একটি করে উদ্দেশ্য লিখুন:</p>
                  <textarea
                    value={missionsText}
                    onChange={(e) => setMissionsText(e.target.value)}
                    rows={6}
                    className="w-full text-xs p-3 rounded-lg border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-900 text-slate-800 dark:text-white focus:outline-emerald-500 font-mono"
                  />
                </div>
              ) : (
                <ul className="flex flex-col gap-3">
                  {settings.targetMissions.map((miss, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-650 dark:text-slate-350">
                      <div className="w-5 h-5 rounded-full bg-emerald-50 dark:bg-emerald-950 flex items-center justify-center font-bold text-[10px] text-emerald-600 shrink-0 mt-0.5">
                        {idx + 1}
                      </div>
                      <span>{miss}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          {/* Card 3: Islamic & Moral learnings */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-3xs">
              <h4 className="text-xs font-black text-slate-850 dark:text-white pb-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
                <BookOpen className="text-emerald-555" size={16} />
                <span>ইসলামিক শিক্ষা (Islamic Education)</span>
              </h4>
              <div className="mt-4">
                {isEditing ? (
                  <textarea
                    value={islamic}
                    onChange={(e) => setIslamic(e.target.value)}
                    rows={4}
                    className="w-full text-xs p-3 rounded-lg border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-900 text-slate-800 dark:text-white focus:outline-emerald-500"
                  />
                ) : (
                  <p className="text-xs text-slate-600 dark:text-slate-350 leading-relaxed">
                    {settings.islamicEducation}
                  </p>
                )}
              </div>
            </div>

            <div className="bg-white dark:bg-slate-850 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-3xs">
              <h4 className="text-xs font-black text-slate-850 dark:text-white pb-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
                <Check className="text-emerald-555" size={16} />
                <span>নৈতিক সুশিক্ষা (Moral Teachings)</span>
              </h4>
              <div className="mt-4">
                {isEditing ? (
                  <textarea
                    value={moral}
                    onChange={(e) => setMoral(e.target.value)}
                    rows={4}
                    className="w-full text-xs p-3 rounded-lg border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-900 text-slate-800 dark:text-white focus:outline-emerald-500"
                  />
                ) : (
                  <p className="text-xs text-slate-600 dark:text-slate-350 leading-relaxed">
                    {settings.moralEducation}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Card 4: Advices for parenting */}
          <div className="bg-amber-50/40 dark:bg-amber-950/10 border border-amber-200/50 dark:border-amber-900/30 p-6 rounded-2xl shadow-3xs">
            <h3 className="text-sm font-black text-amber-850 dark:text-amber-400 pb-3 border-b border-amber-200/30 dark:border-amber-900/20 flex items-center gap-2">
              <ShieldAlert className="text-amber-600" size={18} />
              <span>সম্মানিত অভিভাবকদের প্রতি উপদেশ (Advices)</span>
            </h3>
            <div className="mt-4">
              {isEditing ? (
                <textarea
                  value={advices}
                  onChange={(e) => setAdvices(e.target.value)}
                  rows={4}
                  className="w-full text-xs p-3 rounded-lg border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-900 text-slate-800 dark:text-white focus:outline-emerald-500"
                />
              ) : (
                <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed italic">
                  {settings.advices}
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
