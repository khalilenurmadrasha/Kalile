import React, { useState } from "react";
import { Teacher, User } from "../types";
import { Phone, Award, Mail, Plus, Trash2, X, ClipboardList } from "lucide-react";

interface TeacherSectionProps {
  teachers: Teacher[];
  onAddTeacher: (teacher: Omit<Teacher, "id">) => Promise<boolean>;
  onDeleteTeacher: (id: string) => Promise<boolean>;
  currentUser: User | null;
}

export default function TeacherSection({ teachers, onAddTeacher, onDeleteTeacher, currentUser }: TeacherSectionProps) {
  const isAdmin = currentUser?.role === "admin" || currentUser?.email === "khalilenurmadrasha65@gmail.com" || currentUser?.email === "hfmdsiddikramu1@gmail.com";
  const [modalOpen, setModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  // Form states
  const [name, setName] = useState("");
  const [designation, setDesignation] = useState("");
  const [qualification, setQualification] = useState("");
  const [phone, setPhone] = useState("");
  const [biography, setBiography] = useState("");
  const [email, setEmail] = useState("");
  const [photo, setPhoto] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !designation || !phone) return;

    setLoading(true);
    const mockPhoto = photo || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200";
    
    const success = await onAddTeacher({
      name,
      designation,
      qualification,
      phone,
      biography: biography || "খলিলে নূর মাদ্রাসার সম্মানিত দায়িত্বশীল শিক্ষক।",
      email: email || `${Date.now()}@madrasha.com`,
      photo: mockPhoto
    });

    setLoading(false);
    if (success) {
      setModalOpen(false);
      setName("");
      setDesignation("");
      setQualification("");
      setPhone("");
      setBiography("");
      setEmail("");
      setPhoto("");
    }
  };

  return (
    <div id="teachers-section-layout" className="py-12 bg-slate-50 dark:bg-slate-900 min-h-screen transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Page Title */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-10 gap-4">
          <div>
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest font-mono">Our Instructors</span>
            <h2 className="font-heading text-xl sm:text-2xl font-black text-slate-800 dark:text-white leading-tight mt-1">
              সম্মানিত শিক্ষক মণ্ডলী (Academic Faculty)
            </h2>
            <div className="w-12 h-1 bg-emerald-600 dark:bg-emerald-500 rounded-full mt-3"></div>
          </div>

          {isAdmin && (
            <button
              id="admin-add-teacher-btn"
              onClick={() => setModalOpen(true)}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Plus size={16} />
              <span>নতুন শিক্ষক সংযুক্ত করুন</span>
            </button>
          )}
        </div>

        {/* Teachers Catalog Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {teachers.map((teacher) => (
            <div
              key={teacher.id}
              className="bg-white dark:bg-slate-850 rounded-2xl border border-slate-100 dark:border-slate-800 overflow-hidden shadow-3xs hover:shadow-xs transition-all relative group flex flex-col"
            >
              {/* Photo Banner Area */}
              <div className="h-44 bg-slate-100 dark:bg-slate-800 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent z-10 opacity-70"></div>
                <img
                  src={teacher.photo}
                  alt={teacher.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute bottom-4 left-4 z-15">
                  <span className="inline-block px-2.5 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-bold">
                    {teacher.designation}
                  </span>
                </div>

                {isAdmin && (
                  <button
                    onClick={() => {
                      if (confirm("এই শিক্ষকের প্রোফাইলটি মুছে ফেলতে চান?")) {
                        onDeleteTeacher(teacher.id);
                      }
                    }}
                    className="absolute top-3 right-3 p-2 rounded-full bg-rose-500/90 text-white hover:bg-rose-600 transition-all z-20 shadow-md cursor-pointer"
                    title="ডিলিট শিক্ষক"
                  >
                    <Trash2 size={14} />
                  </button>
                )}
              </div>

              {/* Informational Details */}
              <div className="p-6 flex-1 flex flex-col gap-4">
                <div>
                  <h3 className="text-xs sm:text-sm font-black text-slate-850 dark:text-white leading-tight">
                    {teacher.name}
                  </h3>
                  <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1 mt-1">
                    <Award size={12} />
                    <span>{teacher.qualification}</span>
                  </p>
                </div>

                <p className="text-xs text-slate-500 dark:text-slate-350 leading-relaxed italic pr-2">
                  "{teacher.biography}"
                </p>

                {/* Contacts Block */}
                <div className="mt-auto pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2 text-xs">
                  <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                    <Phone size={14} className="text-emerald-650" />
                    <a href={`tel:${teacher.phone}`} className="hover:underline font-mono">{teacher.phone}</a>
                  </div>
                  <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                    <Mail size={14} className="text-emerald-650" />
                    <a href={`mailto:${teacher.email}`} className="hover:underline font-mono truncate max-w-[200px]">{teacher.email}</a>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Add Teacher Input dialog */}
        {modalOpen && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl relative animate-float-quick">
              
              <button
                onClick={() => setModalOpen(false)}
                className="absolute top-4 p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 right-4 cursor-pointer"
              >
                <X size={18} />
              </button>

              <h3 className="font-heading text-lg font-black text-slate-850 dark:text-white mb-4">
                নতুন শিক্ষক পরিচিতি যোগ করুন
              </h3>

              <form onSubmit={handleSubmit} className="flex flex-col gap-4 text-xs">
                <div>
                  <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">শিক্ষকের সম্পূর্ণ নাম *</label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: মাওলানা হাফেজ মোঃ আব্দুল হাই"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">পদবী *</label>
                    <input
                      type="text"
                      required
                      placeholder="যেমন: সহকারী শিক্ষক"
                      value={designation}
                      onChange={(e) => setDesignation(e.target.value)}
                      className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">যোগ্যতা *</label>
                    <input
                      type="text"
                      required
                      placeholder="যেমন: ফাযিল, কামিল"
                      value={qualification}
                      onChange={(e) => setQualification(e.target.value)}
                      className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">মোবাইল নম্বর *</label>
                    <input
                      type="tel"
                      required
                      placeholder="০১৮XXXXXXXX"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">ইমেইল ঠিকানা</label>
                    <input
                      type="email"
                      placeholder="email@madrasha.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">প্রোফাইল চমৎকার ছবির লিংক (Photo URL)</label>
                  <input
                    type="url"
                    placeholder="https://images.unsplash.com/..."
                    value={photo}
                    onChange={(e) => setPhoto(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">সংক্ষিপ্ত পরিচিতি বা বাণী</label>
                  <textarea
                    rows={3}
                    placeholder="যেমন: কোমলমতি শিশুদের স্নেহের সাথে নিয়মিত নূরানী কুরআন তাজবিদ তালিম শেখান।"
                    value={biography}
                    onChange={(e) => setBiography(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full mt-2 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer disabled:opacity-50"
                >
                  {loading ? "সংরক্ষণ হচ্ছে..." : "যাচাই ও যোগ করুন"}
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
