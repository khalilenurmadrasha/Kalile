import React, { useState } from "react";
import { LibraryBook, User } from "../types";
import { BookOpen, FolderOpen, Layers, Plus, ArrowRightLeft, CheckCircle2, Bookmark, Trash2, X } from "lucide-react";

interface LibrarySectionProps {
  books: LibraryBook[];
  onAddBook: (book: Omit<LibraryBook, "id">) => Promise<boolean>;
  onDeleteBook: (id: string) => Promise<boolean>;
  onBorrowBook: (bookId: string, name: string) => Promise<boolean>;
  onReturnBook: (bookId: string) => Promise<boolean>;
  currentUser: User | null;
}

export default function LibrarySection({
  books,
  onAddBook,
  onDeleteBook,
  onBorrowBook,
  onReturnBook,
  currentUser
}: LibrarySectionProps) {
  const isAdmin = currentUser?.role === "admin" || currentUser?.email === "khalilenurmadrasha65@gmail.com" || currentUser?.email === "hfmdsiddikramu1@gmail.com";
  const [modalOpen, setModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  // Filters state
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedClass, setSelectedClass] = useState("All");

  // Add Book states
  const [bookName, setBookName] = useState("");
  const [author, setAuthor] = useState("");
  const [category, setCategory] = useState<any>("কুরআন মাজীদ");
  const [className, setClassName] = useState<any>("Play");
  const [totalQuantity, setTotalQuantity] = useState(10);
  const [coverPhoto, setCoverPhoto] = useState("");

  const categories = [
    "কুরআন মাজীদ", "বাংলা", "ইংরেজি", "গণিত", "সমাজ", "আরবি", "সিলেবাস", "খাতা", "কলম", "ডাস্টার", "স্লেট"
  ];

  const classes = ["Play", "Nursery", "First", "Second", "Third"];

  const handleCreateBook = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookName || !author) return;

    setLoading(true);
    const mockCover = coverPhoto || "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=120";
    
    const success = await onAddBook({
      bookName,
      author,
      category,
      class: className,
      availability: true,
      totalQuantity: Number(totalQuantity),
      coverPhoto: mockCover,
      borrowedQuantity: 0
    });

    setLoading(false);
    if (success) {
      setModalOpen(false);
      setBookName("");
      setAuthor("");
      setCoverPhoto("");
    }
  };

  const filteredBooks = books.filter((book) => {
    const matchesCat = selectedCategory === "All" || book.category === selectedCategory;
    const matchesClass = selectedClass === "All" || book.class === selectedClass;
    return matchesCat && matchesClass;
  });

  // Stats summary for Library dashboard
  const totalBooksCount = books.reduce((acc, b) => acc + b.totalQuantity, 0);
  const totalBorrowedCount = books.reduce((acc, b) => acc + b.borrowedQuantity, 0);
  const totalAvailableCount = totalBooksCount - totalBorrowedCount;

  return (
    <div id="library-catalog-screen" className="py-12 bg-slate-50 dark:bg-slate-900 min-h-screen transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest font-mono">Library Inventory</span>
            <h2 className="font-heading text-xl sm:text-2xl font-black text-slate-800 dark:text-white leading-tight mt-1">
              মাদ্রাসা কুতুবখানা ও লাইব্রেরী (Library Portal)
            </h2>
            <div className="w-12 h-1 bg-emerald-600 dark:bg-emerald-500 rounded-full mt-3"></div>
          </div>

          {isAdmin && (
            <button
              id="admin-add-book-btn"
              onClick={() => setModalOpen(true)}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Plus size={16} />
              <span>নতুন কিতাব যোগ করুন</span>
            </button>
          )}
        </div>

        {/* Library Dashboard Widget Grid */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <div className="bg-white dark:bg-slate-850 p-4 rounded-xl border border-slate-100 dark:border-slate-800 shadow-3xs text-center">
            <span className="text-[10px] text-slate-400 font-bold uppercase">মোট কিতাব সংখ্যা</span>
            <h3 className="font-heading text-base sm:text-xl font-black text-slate-850 dark:text-white mt-1">
              {totalBooksCount}
            </h3>
          </div>
          <div className="bg-white dark:bg-slate-850 p-4 rounded-xl border border-slate-100 dark:border-slate-800 shadow-3xs text-center">
            <span className="text-[10px] text-emerald-650 dark:text-emerald-400 font-bold uppercase">আলমারিতে মওজুদ</span>
            <h3 className="font-heading text-base sm:text-xl font-black text-slate-850 dark:text-white mt-1">
              {totalAvailableCount}
            </h3>
          </div>
          <div className="bg-white dark:bg-slate-850 p-4 rounded-xl border border-slate-100 dark:border-slate-800 shadow-3xs text-center">
            <span className="text-[10px] text-amber-655 dark:text-amber-450 font-bold uppercase">ধারকৃত বই</span>
            <h3 className="font-heading text-base sm:text-xl font-black text-slate-845 dark:text-white mt-1">
              {totalBorrowedCount}
            </h3>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left panel: Filters categories set */}
          <div className="lg:col-span-3 flex flex-col gap-5">
            {/* Category Select Filters */}
            <div className="bg-white dark:bg-slate-850 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-3xs">
              <h4 className="text-xs font-black text-slate-800 dark:text-white mb-3 flex items-center gap-1">
                <Bookmark size={14} className="text-emerald-550" />
                <span>বিষয় ভিত্তিক ফিল্টার</span>
              </h4>
              <div className="flex flex-col gap-1 text-xs">
                <button
                  id="lib-cat-all"
                  onClick={() => setSelectedCategory("All")}
                  className={`w-full text-left px-3 py-2 rounded-lg font-medium transition-all cursor-pointer ${
                    selectedCategory === "All"
                      ? "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-400 font-bold"
                      : "text-slate-600 dark:text-slate-350 hover:bg-slate-50 dark:hover:bg-slate-800/55"
                  }`}
                >
                  সকল ক্যাটাগরি
                </button>
                {categories.map((cat) => (
                  <button
                    key={cat}
                    id={`lib-cat-${cat}`}
                    onClick={() => setSelectedCategory(cat)}
                    className={`w-full text-left px-3 py-2 rounded-lg font-medium transition-all truncate hover:text-emerald-500 cursor-pointer ${
                      selectedCategory === cat
                        ? "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-400 font-bold"
                        : "text-slate-600 dark:text-slate-350 hover:bg-slate-50 dark:hover:bg-slate-800/55"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Class filter selects */}
            <div className="bg-white dark:bg-slate-850 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-3xs">
              <h4 className="text-xs font-black text-slate-800 dark:text-white mb-3 flex items-center gap-1">
                <FolderOpen size={14} className="text-emerald-555" />
                <span>শ্রেণী ভিত্তিক নির্বাচন</span>
              </h4>
              <div className="flex flex-col gap-1 text-xs font-medium">
                <button
                  id="lib-class-all"
                  onClick={() => setSelectedClass("All")}
                  className={`w-full text-left px-3 py-2 rounded-lg transition-all cursor-pointer ${
                    selectedClass === "All"
                      ? "bg-teal-50 dark:bg-slate-800 text-teal-800 dark:text-teal-400 font-bold"
                      : "text-slate-600 dark:text-slate-350 hover:bg-slate-50 dark:hover:bg-slate-800/55"
                  }`}
                >
                  সব শ্রেনীর সিলেবাস
                </button>
                {classes.map((cls) => (
                  <button
                    key={cls}
                    id={`lib-class-${cls}`}
                    onClick={() => setSelectedClass(cls)}
                    className={`w-full text-left px-3 py-2 rounded-lg transition-all cursor-pointer ${
                      selectedClass === cls
                        ? "bg-teal-50 dark:bg-slate-800 text-teal-800 dark:text-teal-400 font-bold"
                        : "text-slate-600 dark:text-slate-350 hover:bg-slate-50 dark:hover:bg-slate-800/55"
                    }`}
                  >
                    শ্রেণী: {cls}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right panel: Books directory grids */}
          <div className="lg:col-span-9">
            {filteredBooks.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredBooks.map((book) => {
                  const stockRemaining = book.totalQuantity - book.borrowedQuantity;
                  const isAvailable = stockRemaining > 0;

                  return (
                    <div
                      key={book.id}
                      className="bg-white dark:bg-slate-850 rounded-2xl border border-slate-100 dark:border-slate-800 p-5 shadow-3xs flex gap-4 hover:shadow-xs transition-all relative"
                    >
                      {isAdmin && (
                        <button
                          onClick={() => {
                            if (confirm(`আপনি কি "${book.bookName}" কিতাবটি কুতুবখানা ডাটাবেস থেকে ডিলিট করতে চান?`)) {
                              onDeleteBook(book.id);
                            }
                          }}
                          className="absolute bottom-4 right-4 p-1.5 rounded-full bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-950/20 dark:hover:bg-rose-900/10 transition-all cursor-pointer z-10"
                        >
                          <Trash2 size={13} />
                        </button>
                      )}

                      {/* Cover Preview Image */}
                      <div className="w-20 h-28 bg-slate-100 dark:bg-slate-800 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 shrink-0 relative">
                        <img
                          src={book.coverPhoto}
                          alt={book.bookName}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>

                      {/* Text Properties details */}
                      <div className="flex flex-col flex-1 gap-2 text-xs">
                        <div>
                          <span className="inline-block text-[9px] font-bold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-500 mb-1">
                            {book.category} ({book.class})
                          </span>
                          <h3 className="font-heading text-xs font-black text-slate-850 dark:text-white leading-snug">
                            {book.bookName}
                          </h3>
                          <p className="text-[10px] text-slate-400 mt-1">লেখক: {book.author}</p>
                        </div>
                        
                        <div className="mt-auto">
                          <p className="text-[10px] text-slate-500 dark:text-slate-400 mb-2">
                            মওজুদ স্টক: <strong className="font-mono">{stockRemaining}/{book.totalQuantity}</strong> কিতাব
                          </p>

                          {isAvailable ? (
                            <button
                              id={`borrow-book-btn-${book.id}`}
                              onClick={() => {
                                const borrower = currentUser ? currentUser.name : prompt("ধার গ্রহণকারীর নাম লিখুন:");
                                if (borrower) {
                                  onBorrowBook(book.id, borrower);
                                }
                              }}
                              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-bold rounded-lg shadow-3xs flex items-center gap-1 transition-all cursor-pointer"
                            >
                              <ArrowRightLeft size={12} />
                              <span>বই ধার নিন (Borrow)</span>
                            </button>
                          ) : (
                            <span className="inline-block px-3 py-1.5 bg-rose-50 text-rose-600 dark:bg-rose-950/20 dark:text-rose-400 text-[10px] font-bold rounded-lg leading-none">
                              স্টক খালি (Out Of Stock)
                            </span>
                          )}

                          {book.borrowedQuantity > 0 && (
                            <button
                              id={`return-book-btn-${book.id}`}
                              onClick={() => onReturnBook(book.id)}
                              className="mt-1.5 block text-[10px] text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
                            >
                              ধার ফেরত দিন (Return Book)
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-16 bg-white dark:bg-slate-850 rounded-2xl border border-slate-150 dark:border-slate-800">
                <BookOpen size={40} className="text-slate-300 mx-auto mb-2 animate-bounce" />
                <p className="text-xs text-slate-405 font-medium">নির্বাচিত ক্যাটাগরি বা শ্রেণীতে কোনো সংরক্ষিত কিতাবের মেল তথ্য পাওয়া যায়নি!</p>
              </div>
            )}
          </div>
        </div>

        {/* Modal creation dialog window */}
        {modalOpen && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl relative">
              <button
                onClick={() => setModalOpen(false)}
                className="absolute top-4 p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 right-4 cursor-pointer"
              >
                <X size={18} />
              </button>

              <h3 className="font-heading text-lg font-black text-slate-850 dark:text-white mb-4">
                লাইব্রেরি ডাটাবেসে নতুন কিতাব যোগ করুন
              </h3>

              <form onSubmit={handleCreateBook} className="flex flex-col gap-4 text-xs">
                <div>
                  <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">কিতাবের নাম (Book Title) *</label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: সহজ নূরানী কায়দা"
                    value={bookName}
                    onChange={(e) => setBookName(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">লেখক বা প্রকাশক (Author) *</label>
                  <input
                    type="text"
                    required
                    placeholder="যেমন: মাওলানা ক্বারী বেলায়েত হোসাইন"
                    value={author}
                    onChange={(e) => setAuthor(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">ক্যাটাগরি *</label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-850 text-slate-800 dark:text-white focus:outline-emerald-500"
                    >
                      {categories.map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">শ্রেণী সিলেবাস *</label>
                    <select
                      value={className}
                      onChange={(e) => setClassName(e.target.value)}
                      className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-white dark:bg-slate-850 text-slate-800 dark:text-white focus:outline-emerald-500"
                    >
                      {classes.map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">মোট কিতাব স্টক *</label>
                    <input
                      type="number"
                      required
                      min={1}
                      value={totalQuantity}
                      onChange={(e) => setTotalQuantity(Number(e.target.value))}
                      className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-500 dark:text-slate-400 font-bold mb-1">বই কভার ছবির লিঙ্ক</label>
                    <input
                      type="url"
                      placeholder="https://..."
                      value={coverPhoto}
                      onChange={(e) => setCoverPhoto(e.target.value)}
                      className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-750 bg-transparent text-slate-800 dark:text-white focus:outline-emerald-500 font-mono"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full mt-2 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer disabled:opacity-50"
                >
                  {loading ? "যোগ করা হচ্ছে..." : "যাচাই ও যোগ করুন"}
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
