/**
 * TypeScript definitions for Khalil Noor Kashemul Uloom Noorani KG Madrasa
 */

export type UserRole = "admin" | "teacher" | "student" | "guardian";

export interface User {
  id: string;
  email: string;
  phone?: string;
  name: string;
  role: UserRole;
  avatarUrl?: string;
  createdAt: string;
}

export interface Teacher {
  id: string;
  photo: string;
  name: string;
  designation: string;
  qualification: string;
  phone: string;
  biography: string;
  email: string;
  createdAt?: string;
}

export interface Student {
  id: string;
  photo: string;
  name: string;
  roll: string;
  class: string;
  session: string;
  guardianName: string;
  guardianPhone: string;
  address: string;
  gender: string;
  dob?: string;
  createdAt?: string;
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  date: string;
  category: "General" | "Exam" | "Holiday" | "Admission";
  important: boolean;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  studentName: string;
  roll: string;
  class: string;
  date: string; // YYYY-MM-DD
  status: "Present" | "Absent" | "Late";
}

export interface ExamResult {
  id: string;
  studentId: string;
  studentName: string;
  roll: string;
  class: string;
  term: "First Term" | "Mid Term" | "Final Exam";
  subjectGrades: {
    quran: number;
    bangla: number;
    english: number;
    math: number;
    arabic: number;
    moral: number;
  };
  totalMarks: number;
  grade: string;
  gpa: number;
  remarks: string;
  createdAt: string;
}

export interface LibraryBook {
  id: string;
  bookName: string;
  author: string;
  category: "কুরআন মাজীদ" | "বাংলা" | "ইংরেজি" | "গণিত" | "সমাজ" | "আরবি" | "সিলেবাস" | "খাতা" | "কলম" | "ডাস্টার" | "স্লেট";
  class: "Play" | "Nursery" | "First" | "Second" | "Third";
  availability: boolean;
  coverPhoto: string;
  totalQuantity: number;
  borrowedQuantity: number;
}

export interface BookTransaction {
  id: string;
  bookId: string;
  bookName: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  borrowDate: string;
  returnDate?: string;
  status: "Borrowed" | "Returned";
}

export interface AdmissionForm {
  id: string;
  studentName: string;
  fatherName: string;
  motherName: string;
  dob: string;
  class: "Play" | "Nursery" | "First" | "Second" | "Third";
  gender: "Male" | "Female";
  phone: string;
  address: string;
  photoUrl: string;
  paymentMethod: "bKash" | "Nagad" | "Rocket" | "Bank Transfer";
  transactionId: string;
  amount: number;
  paymentStatus: "Verified" | "Pending";
  submissionDate: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  phone: string;
  message: string;
  date: string;
  read: boolean;
}

export interface GalleryItem {
  id: string;
  url: string;
  category: "Campus" | "Event" | "Classroom" | "Sports";
  title: string;
  date: string;
}

export interface SystemSettings {
  websiteName: string;
  banglaName: string;
  address: string;
  email: string;
  phone: string;
  introduction: string;
  targetMissions: string[];
  islamicEducation: string;
  moralEducation: string;
  advices: string;
  logoUrl?: string;
  logoSize?: "small" | "medium" | "large" | "super-size";
  logoShape?: "circle" | "square" | "rounded-xl" | "polygon";
  logoBorderColor?: string;
  logoGlow?: boolean;
  webBgColor?: string;
  headerBgColor?: string;
  headerBgPhoto?: string;
  headerOverlayOpacity?: string;
  primaryAccentColor?: string;
  secondaryAccentColor?: string;
  sectionBgColor?: string;
  sectionTextColor?: string;
  sectionTitleColor?: string;
  animationStyle?: "disabled" | "smooth" | "bouncy" | "ultra-premium";
  animationDuration?: string;
  fontFamily?: "inter" | "noto-bengali" | "space-grotesk" | "playfair" | "outfit" | "mono";
  fontSizeLevel?: "small" | "medium" | "large" | "extra-large";
  premiumStyleMode?: "flat" | "glass" | "bordered" | "glowing" | "minimalist";
  headingWeight?: "regular" | "semibold" | "bold" | "black";
  showLiveClock?: boolean;
  liveClockFormat?: "12hour" | "24hour" | "bangla";
  showDate?: boolean;
  dateFormat?: "gregorian" | "bangla" | "both";
}
