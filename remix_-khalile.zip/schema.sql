-- =====================================================================
-- Database Schema for: Khalil Noor Kashemul Uloom Noorani KG Madrasa
-- (খলিলে নূর কাশেমুল উলুম নূরানী কেজি মাদ্রাসা)
-- Target Database: MySQL 8.0+ / MariaDB 10.4+
-- Generated for Academic and Staging Deployments
-- =====================================================================

CREATE DATABASE IF NOT EXISTS `madrasha_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `madrasha_db`;

-- 1. SETTINGS TABLE
CREATE TABLE IF NOT EXISTS `settings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `websiteName` VARCHAR(255) NOT NULL,
  `banglaName` VARCHAR(255) NOT NULL,
  `address` TEXT NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `introduction` TEXT NOT NULL,
  `islamicEducation` TEXT NOT NULL,
  `moralEducation` TEXT NOT NULL,
  `advices` TEXT NOT NULL,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. USERS TABLE
CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(50) PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `email` VARCHAR(100) UNIQUE NOT NULL,
  `phone` VARCHAR(20) NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('admin', 'teacher', 'student', 'guardian') NOT NULL DEFAULT 'guardian',
  `avatarUrl` VARCHAR(255) NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. ADMINS TABLE
CREATE TABLE IF NOT EXISTS `admins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `userId` VARCHAR(50) NOT NULL,
  `permissions` TEXT NULL,
  FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. TEACHERS TABLE
CREATE TABLE IF NOT EXISTS `teachers` (
  `id` VARCHAR(50) PRIMARY KEY,
  `photo` VARCHAR(255) NOT NULL,
  `name` VARCHAR(150) NOT NULL,
  `designation` VARCHAR(100) NOT NULL,
  `qualification` VARCHAR(200) NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `biography` TEXT NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. STUDENTS TABLE
CREATE TABLE IF NOT EXISTS `students` (
  `id` VARCHAR(50) PRIMARY KEY,
  `photo` VARCHAR(255) NOT NULL,
  `name` VARCHAR(150) NOT NULL,
  `roll` VARCHAR(20) NOT NULL,
  `class` VARCHAR(50) NOT NULL,
  `session` VARCHAR(10) NOT NULL,
  `guardianName` VARCHAR(150) NOT NULL,
  `guardianPhone` VARCHAR(20) NOT NULL,
  `address` TEXT NOT NULL,
  `gender` ENUM('Male', 'Female') NOT NULL,
  `dob` DATE NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_class_roll` (`class`, `roll`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. ATTENDANCE TABLE
CREATE TABLE IF NOT EXISTS `attendance` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `studentId` VARCHAR(50) NOT NULL,
  `studentName` VARCHAR(150) NOT NULL,
  `roll` VARCHAR(20) NOT NULL,
  `class` VARCHAR(50) NOT NULL,
  `date` DATE NOT NULL,
  `status` ENUM('Present', 'Absent', 'Late') NOT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`studentId`) REFERENCES `students`(`id`) ON DELETE CASCADE,
  INDEX `idx_date_class` (`date`, `class`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. REPORTS (EXAM RESULTS) TABLE
CREATE TABLE IF NOT EXISTS `reports` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `studentId` VARCHAR(50) NOT NULL,
  `studentName` VARCHAR(150) NOT NULL,
  `roll` VARCHAR(20) NOT NULL,
  `class` VARCHAR(50) NOT NULL,
  `term` ENUM('First Term', 'Mid Term', 'Final Exam') NOT NULL,
  `quran` INT NOT NULL DEFAULT 0,
  `bangla` INT NOT NULL DEFAULT 0,
  `english` INT NOT NULL DEFAULT 0,
  `math` INT NOT NULL DEFAULT 0,
  `arabic` INT NOT NULL DEFAULT 0,
  `moral` INT NOT NULL DEFAULT 0,
  `totalMarks` INT NOT NULL DEFAULT 0,
  `grade` VARCHAR(5) NOT NULL,
  `gpa` DECIMAL(3,2) NOT NULL DEFAULT 0.00,
  `remarks` TEXT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`studentId`) REFERENCES `students`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. BOOKS (LIBRARY CATALOG) TABLE
CREATE TABLE IF NOT EXISTS `books` (
  `id` VARCHAR(50) PRIMARY KEY,
  `bookName` VARCHAR(200) NOT NULL,
  `author` VARCHAR(150) NOT NULL,
  `category` ENUM('কুরআন মাজীদ', 'বাংলা', 'ইংরেজি', 'গণিত', 'সমাজ', 'আরবি', 'সিলেবাস', 'খাতা', 'কলম', 'ডাস্টার', 'সলেবট') NOT NULL,
  `class` ENUM('Play', 'Nursery', 'First', 'Second', 'Third') NOT NULL,
  `availability` TINYINT(1) DEFAULT 1,
  `coverPhoto` VARCHAR(255) NULL,
  `totalQuantity` INT NOT NULL DEFAULT 1,
  `borrowedQuantity` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. BOOK TRANSACTIONS (LIBRARY BORROW/RETURN) TABLE
CREATE TABLE IF NOT EXISTS `book_transactions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `bookId` VARCHAR(50) NOT NULL,
  `bookName` VARCHAR(200) NOT NULL,
  `userId` VARCHAR(50) NOT NULL,
  `userName` VARCHAR(150) NOT NULL,
  `userRole` VARCHAR(30) NOT NULL,
  `borrowDate` DATE NOT NULL,
  `returnDate` DATE NULL,
  `status` ENUM('Borrowed', 'Returned') NOT NULL DEFAULT 'Borrowed',
  FOREIGN KEY (`bookId`) REFERENCES `books`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. ADMISSIONS TABLE
CREATE TABLE IF NOT EXISTS `admissions` (
  `id` VARCHAR(50) PRIMARY KEY,
  `studentName` VARCHAR(150) NOT NULL,
  `fatherName` VARCHAR(150) NOT NULL,
  `motherName` VARCHAR(150) NOT NULL,
  `dob` DATE NOT NULL,
  `class` ENUM('Play', 'Nursery', 'First', 'Second', 'Third') NOT NULL,
  `gender` ENUM('Male', 'Female') NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `address` TEXT NOT NULL,
  `photoUrl` VARCHAR(255) NOT NULL,
  `paymentMethod` ENUM('bKash', 'Nagad', 'Rocket', 'Bank Transfer') NOT NULL,
  `transactionId` VARCHAR(100) UNIQUE NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `paymentStatus` ENUM('Verified', 'Pending') NOT NULL DEFAULT 'Pending',
  `submissionDate` DATE NOT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. PAYMENTS TABLE
CREATE TABLE IF NOT EXISTS `payments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `studentName` VARCHAR(150) NOT NULL,
  `class` VARCHAR(50) NOT NULL,
  `method` VARCHAR(50) NOT NULL,
  `txid` VARCHAR(100) NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `type` VARCHAR(100) NOT NULL,
  `date` DATE NOT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'Verified',
  INDEX `idx_tx` (`txid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. GALLERY TABLE
CREATE TABLE IF NOT EXISTS `gallery` (
  `id` VARCHAR(50) PRIMARY KEY,
  `url` VARCHAR(255) NOT NULL,
  `category` ENUM('Campus', 'Event', 'Classroom', 'Sports') NOT NULL,
  `title` VARCHAR(200) NOT NULL,
  `date` DATE NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13. NOTICES TABLE
CREATE TABLE IF NOT EXISTS `notices` (
  `id` VARCHAR(50) PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `content` TEXT NOT NULL,
  `date` DATE NOT NULL,
  `category` ENUM('General', 'Exam', 'Holiday', 'Admission') NOT NULL,
  `important` TINYINT(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 14. CONTACTS TABLE
CREATE TABLE IF NOT EXISTS `contacts` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `message` TEXT NOT NULL,
  `date` DATE NOT NULL,
  `read` TINYINT(1) DEFAULT 0,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
-- PRELOAD DEMO ENTRIES
-- =====================================================================

INSERT INTO `settings` 
  (`id`, `websiteName`, `banglaName`, `address`, `email`, `phone`, `introduction`, `islamicEducation`, `moralEducation`, `advices`)
VALUES 
  (1, 
   'Khalil Noor Kashemul Uloom Noorani KG Madrasa', 
   'খলিলে নূর কাশেমুল উলুম নূরানী কেজি মাদ্রাসা', 
   'ঢেমুশিয়া, বাজারপাড়া, চকরিয়া, কক্সবাজার', 
   'khalilenurmadrasha65@gmail.com', 
   '01812345678', 
   'খলিলে নূর কাশেমুল উলুম নূরানী কেজি মাদ্রাসা কক্সবাজার জেলার চকরিয়া উপজেলার ঐতিহ্যবাহী ঢেমুশিয়া ইউনিয়নে অবস্থিত একটি স্বনামধন্য দ্বীনি ও আধুনিক শিক্ষাপ্রতিষ্ঠান।', 
   'আমাদের মাদ্রাসায় তাজবিদ সহকারে কুরআন মজিদ নাজেরা, হিফজ এবং মৌলিক আকাইদ-ফিকাহ সম্পর্কিত বাস্তবসম্মত দ্বীনি তালীম প্রদান করা হয়।', 
   'আদর্শ সমাজ বিনির্মাণে নৈতিক শিক্ষার বিকল্প নেই। খেলাধুলা ও দ্বীনি শৃঙ্খলার মাধ্যমে শিক্ষার্থীদের উচ্চ নৈতিক চরিত্রের অধিকারী হিসেবে বিনির্মাণ করা হয়।', 
   'সন্তানদের পবিত্র ও ইসলামিক পরিবেশে গড়ে তুলুন। ইহকাল ও পরকালের মুক্তির জন্য দ্বীনি তালিম অপরিহার্য।'
  ) ON DUPLICATE KEY UPDATE `id`=`id`;

-- Inserts default admin user (Password: md_admin123_hash)
INSERT INTO `users` 
  (`id`, `name`, `email`, `phone`, `password_hash`, `role`, `avatarUrl`)
VALUES 
  ('admin_1', 
   'মাওলানা হাফেজ মোঃ ছিদ্দিকুল্লাহ', 
   'khalilenurmadrasha65@gmail.com', 
   '01812345678', 
   '$2b$10$7zHeH7T3dskgHghy6pI7UOHz1vA3q5lHWeM1c1L9PzP9LpLpLpLpK', -- simulated BCrypt hash
   'admin', 
   'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200'
  ) ON DUPLICATE KEY UPDATE `id`=`id`;
