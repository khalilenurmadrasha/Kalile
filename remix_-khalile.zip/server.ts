import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { 
  User, Teacher, Student, Notice, AttendanceRecord, ExamResult, 
  LibraryBook, BookTransaction, AdmissionForm, ContactMessage, 
  GalleryItem, SystemSettings 
} from "./src/types";

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

const DATA_DIR = path.join(process.cwd(), "data");
const DB_FILE = path.join(DATA_DIR, "db.json");

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Default Seed Data
const DEFAULT_SETTINGS: SystemSettings = {
  websiteName: "Khalil Noor Kashemul Uloom Noorani KG Madrasa",
  banglaName: "খলিলে নূর কাশেমুল উলুম নূরানী কেজি মাদ্রাসা",
  address: "ঢেমুশিয়া, বাজারপাড়া, চকরিয়া, কক্সবাজার",
  email: "khalilenurmadrasha65@gmail.com",
  phone: "01812345678",
  introduction: "খলিলে নূর কাশেমুল উলুম নূরানী কেজি মাদ্রাসা কক্সবাজার জেলার চকরিয়া উপজেলার ঐতিহ্যবাহী ঢেমুশিয়া ইউনিয়নে অবস্থিত একটি স্বনামধন্য দ্বীনি ও আধুনিক শিক্ষাপ্রতিষ্ঠান। এটি শিক্ষার্থীদের ইসলামিক মূল্যবোধ ও আধুনিক শিক্ষার সুষম সমন্বয়ে গড়ে তোলার লক্ষ্যে নিরলস কাজ করে যাচ্ছে।",
  targetMissions: [
    "শুদ্ধ ও বিশুদ্ধরূপে পবিত্র কুরআন তিলাওয়াত শিক্ষা দেওয়া।",
    "ইসলামিক তাহজিব-তামাদ্দুন তথা সুন্নাতভিত্তিক জীবনযাপনে অভ্যস্ত করা।",
    "নৈতিকতা ও মূল্যবোধ সম্পন্ন আদর্শ নাগরিক হিসেবে গড়ে তোলা।",
    "নূরানী পদ্ধতির মাধ্যমে স্বল্প সময়ে বাংলা, ইংরেজি ও গণিত শিক্ষা নিশ্চিত করা।"
  ],
  islamicEducation: "আমাদের মাদ্রাসায় তাজবিদ সহকারে কুরআন মজিদ নাজেরা, হিফজ এবং মৌলিক আকাইদ-ফিকাহ সম্পর্কিত বাস্তবসম্মত দ্বীনি তালীম প্রদান করা হয়।",
  moralEducation: "আদর্শ সমাজ বিনির্মাণে নৈতিক শিক্ষার বিকল্প নেই। খেলাধুলা ও দ্বীনি শৃঙ্খলার মাধ্যমে শিক্ষার্থীদের উচ্চ নৈতিক চরিত্রের অধিকারী হিসেবে বিনির্মাণ করা হয়।",
  advices: "সন্তানদের পবিত্র ও ইসলামিক পরিবেশে গড়ে তুলুন। ইহকাল ও পরকালের মুক্তির জন্য দ্বীনি তালিম অপরিহার্য। নিয়মিত মাদ্রাসায় পাঠানো নিশ্চিত করুন ও অভিভাবকদের সার্বিক তদারকি কাম্য।",
  logoUrl: "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=120",
  logoSize: "medium",
  logoShape: "circle",
  logoBorderColor: "#10b981",
  logoGlow: true,
  webBgColor: "#f8fafc",
  headerBgColor: "#0f172a",
  headerBgPhoto: "",
  headerOverlayOpacity: "40",
  primaryAccentColor: "#059669",
  secondaryAccentColor: "#d97706",
  sectionBgColor: "#ffffff",
  sectionTextColor: "#334155",
  sectionTitleColor: "#0f172a",
  animationStyle: "smooth",
  animationDuration: "0.3s",
  fontFamily: "noto-bengali",
  fontSizeLevel: "medium",
  premiumStyleMode: "glass",
  headingWeight: "bold"
};

const INITIAL_TEACHERS: Teacher[] = [
  {
    id: "t_1",
    name: "মাওলানা হাফেজ মোঃ ছিদ্দিকুল্লাহ",
    designation: "মুহতামিম / প্রধান শিক্ষক",
    qualification: "কামিল (হাদীস), হাফেজ-এ-কুরআন",
    phone: "01823456781",
    biography: "মাদ্রাসার সার্বিক উন্নয়নে দ্বীনি নিষ্ঠার সাথে দায়িত্ব পালন করছেন।",
    email: "mohammad.siddik@gmail.com",
    photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200"
  },
  {
    id: "t_2",
    name: "হাফেজ মোঃ আব্দুল হাই",
    designation: "সহকারী শিক্ষক (নূরানী বিভাগ)",
    qualification: "ফাযিল, নূরানী প্রশিক্ষণপ্রাপ্ত",
    phone: "01823456782",
    biography: "নূরানী পদ্ধতিতে শিশুদের পরম যত্ন সহকারে প্রাথমিক দ্বীনি শিক্ষা দান করেন।",
    email: "abdul.hai@gmail.com",
    photo: "https://images.unsplash.com/photo-1628157582853-a796fa650a6a?auto=format&fit=crop&q=80&w=200"
  },
  {
    id: "t_3",
    name: "জনাব মেহেরুন্নেসা লাকী",
    designation: "শিক্ষিকা (কেজি ও জেনারেল বিভাগ)",
    qualification: "বি.এ (সম্মান), বি.এড",
    phone: "01823456783",
    biography: "বাংলা, ইংরেজি এবং গণিত বিষয়াবলি আধুনিক উপায়ে চমৎকারভাবে পড়ান।",
    email: "meherun.lucky@gmail.com",
    photo: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200"
  }
];

const INITIAL_STUDENTS: Student[] = [
  {
    id: "s_1",
    photo: "https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=150",
    name: "মোঃ সাজ্জাদ হোসাইন কায়সার",
    roll: "১০১",
    class: "Play",
    session: "২০২৬",
    guardianName: "মোঃ জুনাইদ",
    guardianPhone: "01711112221",
    address: "বাজারপাড়া, ঢেমুশিয়া, চকরিয়া, কক্সবাজার",
    gender: "Male",
    dob: "২০২০-০২-১৫"
  },
  {
    id: "s_2",
    photo: "https://images.unsplash.com/photo-1518887570146-0612132dd618?auto=format&fit=crop&q=80&w=150",
    name: "ফাতেমা আরিশা জেরিন",
    roll: "১০২",
    class: "Nursery",
    session: "২০২৬",
    guardianName: "মোঃ নুরুল আমিন",
    guardianPhone: "01711112222",
    address: "পশ্চিম ঢেমুশিয়া, চকরিয়া",
    gender: "Female",
    dob: "২০১৯-০৫-২০"
  },
  {
    id: "s_3",
    photo: "https://images.unsplash.com/photo-1503919545889-aef636e10ad4?auto=format&fit=crop&q=80&w=150",
    name: "মোঃ মোস্তফা কামাল",
    roll: "২০১",
    class: "First",
    session: "২০২৬",
    guardianName: "মোঃ কামাল উদ্দিন",
    guardianPhone: "01711112223",
    address: "বাজারপাড়া, চকরিয়া",
    gender: "Male",
    dob: "২০১৮-০৯-০৫"
  },
  {
    id: "s_4",
    photo: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?auto=format&fit=crop&q=80&w=150",
    name: "আয়েশা সিদ্দিকা তানিয়া",
    roll: "৩০১",
    class: "Second",
    session: "২০২৬",
    guardianName: "হাফেজ মোঃ ইউনুস",
    guardianPhone: "01711112224",
    address: "ঢেমুশিয়া চিলখালী, চকরিয়া",
    gender: "Female",
    dob: "২০১৭-১২-১২"
  }
];

const INITIAL_BOOKS: LibraryBook[] = [
  { id: "b_1", bookName: "সহজ নূরানী কায়দা", author: "মাওলানা ক্বারী বেলায়েত হোসাইন", category: "কুরআন মাজীদ", class: "Play", availability: true, totalQuantity: 50, borrowedQuantity: 12, coverPhoto: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=120" },
  { id: "b_2", bookName: "এসো আরবী শিখি", author: "মাওলানা আবু তাহের মেসবাহ", category: "আরবি", class: "First", availability: true, totalQuantity: 30, borrowedQuantity: 6, coverPhoto: "https://images.unsplash.com/photo-1513001900722-370f803f498d?auto=format&fit=crop&q=80&w=120" },
  { id: "b_3", bookName: "আমার বাংলা বই - প্রথম শ্রেণী", author: "এনসিটিবি", category: "বাংলা", class: "First", availability: true, totalQuantity: 40, borrowedQuantity: 5, coverPhoto: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&q=80&w=120" },
  { id: "b_4", bookName: "প্রাথমিক গণিত - দ্বিতীয় শ্রেণী", author: "এনসিটিবি", category: "গণিত", class: "Second", availability: true, totalQuantity: 35, borrowedQuantity: 2, coverPhoto: "https://images.unsplash.com/photo-1596495578065-6e0763fa1141?auto=format&fit=crop&q=80&w=120" },
  { id: "b_5", bookName: "ইসলামিক শিশু শিক্ষা খাতা ও ডাস্টার সেট", author: "মাদ্রাসা প্রকাশনা", category: "খাতা", class: "Play", availability: true, totalQuantity: 100, borrowedQuantity: 0, coverPhoto: "https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&q=80&w=120" }
];

const INITIAL_NOTICES: Notice[] = [
  {
    id: "n_1",
    title: "২০২৬ শিক্ষাবর্ষে নূরানী কেজি বিভাগে নতুন ভর্তি কার্যক্রম চলছে",
    content: "সম্মানিত অভিভাবক ও সুধী সমাজ, আমাদের খলিলে নূর কাশেমুল উলুম নূরানী কেজি মাদ্রাসায় প্লে, নার্সারী ও প্রথম থেকে তৃতীয় শ্রেণী পর্যন্ত সীমিত আসনে ছাত্র-ছাত্রী ভর্তি চলছে। বিস্তারিত তথ্যের জন্য যোগাযোগ করুন অথবা অনলাইন পোর্টালে আবেদন সম্পন্ন করুন। অনলাইন আবেদনের সময় বিকাশ/নগদ এর মাধ্যমে ফি পরিশোধ করা বাধ্যতামূলক।",
    date: "২০২৬-০৫-২৫",
    category: "Admission",
    important: true
  },
  {
    id: "n_2",
    title: "প্রথম সাময়িক পরীক্ষা গ্রহণের নোটিশ",
    content: "আগামী ১৫ই জুন ২০২৬ থেকে সকল শ্রেণীর প্রথম সাময়িক পরীক্ষা শুরু হতে যাচ্ছে। পরীক্ষার সিলেবাস ও সময়সূচী ইতিমধ্যে নোটিশ বোর্ডে ও শিক্ষার্থীদের ডায়েরীতে প্রদান করা হয়েছে। শিক্ষার্থীদের শতভাগ উপস্থিতি ও অভিভাবকদের নিবিড় তদারকি কামনা করছি।",
    date: "২০২৬-০৫-৩০",
    category: "Exam",
    important: true
  },
  {
    id: "n_3",
    title: "পবিত্র ঈদুল আযহা উপলক্ষে মাদ্রাসা বন্ধের ঘোষণা",
    content: "পবিত্র ঈদুল আযহা উপলক্ষে আগামী ৪ঠা জুন থেকে ১৪ই জুন ২০২৬ পর্যন্ত মাদ্রাসার সকল দ্বীনি ও কেজি শ্রেণীর পাঠদান বন্ধ থাকবে। ১৫ই জুন রোজ সোমবার থেকে নির্ধারিত সময়ে নিয়মিত ক্লাস ও পরীক্ষা আরম্ভ হবে।",
    date: "2026-06-01",
    category: "Holiday",
    important: false
  }
];

const INITIAL_GALLERY: GalleryItem[] = [
  { id: "g_1", url: "https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&q=80&w=600", category: "Campus", title: "মাদ্রাসার মনোরম দ্বীনি পরিবেশ", date: "২০২৬-০১-১৫" },
  { id: "g_2", url: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=600", category: "Classroom", title: "নূরানী পদ্ধতিতে শিশুদের ক্লাস গ্রহণ", date: "২০২৬-০২-১০" },
  { id: "g_3", url: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&q=80&w=600", category: "Event", title: "বাৎসরিক ইসলামিক কুইজ প্রতিযোগিতা", date: "২০২৬-০৩-০৫" },
  { id: "g_4", url: "https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&q=80&w=600", category: "Sports", title: "শিক্ষার্থীদের ইসলামিক খেলাধুলা", date: "২০২৬-০৩-২০" }
];

const INITIAL_ADMISSIONS: AdmissionForm[] = [
  {
    id: "adm_1",
    studentName: "মোঃ আরাফাত সিদ্দিক",
    fatherName: "মোঃ সালাহউদ্দিন",
    motherName: "বিলকিস বেগম",
    dob: "২০২১-০৪-১২",
    class: "Play",
    gender: "Male",
    phone: "01819876543",
    address: "বাজারপাড়া, ঢেমুশিয়া",
    photoUrl: "https://images.unsplash.com/photo-1503919545889-aef636e10ad4?auto=format&fit=crop&q=80&w=150",
    paymentMethod: "bKash",
    transactionId: "BKX987HFE2",
    amount: 1200,
    paymentStatus: "Verified",
    submissionDate: "২০২৬-০৫-২৮"
  }
];

const INITIAL_EXAM_RESULTS: ExamResult[] = [
  {
    id: "r_1",
    studentId: "s_1",
    studentName: "মোঃ সাজ্জাদ হোসাইন কায়সার",
    roll: "১০১",
    class: "Play",
    term: "First Term",
    subjectGrades: { quran: 95, bangla: 88, english: 85, math: 92, arabic: 90, moral: 98 },
    totalMarks: 548,
    grade: "A+",
    gpa: 5.0,
    remarks: "চমৎকার ফলাফল। কুরআন পাঠে অত্যন্ত মনোযোগী।",
    createdAt: "২০২৬-০৫-২৫"
  },
  {
    id: "r_2",
    studentId: "s_3",
    studentName: "মোঃ মোস্তফা কামাল",
    roll: "২০১",
    class: "First",
    term: "First Term",
    subjectGrades: { quran: 88, bangla: 78, english: 80, math: 85, arabic: 84, moral: 90 },
    totalMarks: 505,
    grade: "A",
    gpa: 4.5,
    remarks: "খুব ভালো, হাতের লেখা আরও সুন্দর করা প্রয়োজন।",
    createdAt: "২০২৬-০৫-২৫"
  }
];

const INITIAL_ATTENDANCE: AttendanceRecord[] = [
  { id: "att_1", studentId: "s_1", studentName: "মোঃ সাজ্জাদ হোসাইন কায়সার", roll: "১০১", class: "Play", date: "2026-06-01", status: "Present" },
  { id: "att_2", studentId: "s_2", studentName: "ফাতেমা আরিশা জেরিন", roll: "১০২", class: "Nursery", date: "2026-06-01", status: "Present" },
  { id: "att_3", studentId: "s_3", studentName: "মোঃ মোস্তফা কামাল", roll: "২০১", class: "First", date: "2026-06-01", status: "Absent" },
  { id: "att_4", studentId: "s_4", studentName: "আয়েশা সিদ্দিকা তানিয়া", roll: "৩০১", class: "Second", date: "2026-06-01", status: "Present" }
];

const INITIAL_PAYMENTS = [
  { id: "p_1", studentName: "মোঃ আরাফাত সিদ্দিক", class: "Play", method: "bKash", txid: "BKX987HFE2", amount: 1200, type: "Admission Fee", date: "২০২৬-০৫-২৮", status: "Verified" },
  { id: "p_2", studentName: "মোঃ সাজ্জাদ হোসাইন কায়সার", class: "Play", method: "Nagad", txid: "NGD6652GFT", amount: 800, type: "Tuition Fee", date: "২০২৬-০৫-৩০", status: "Verified" }
];

const INITIAL_CONTACT_MESSAGES: ContactMessage[] = [
  { id: "c_1", name: "মোহাম্মদ ইউসুফ", phone: "01824123412", message: "আসসালামু আলাইকুম, প্লে শ্রেণীর ক্লাস কি সকাল ৮টা থেকে শুরু হয়? অনুগ্রহ করে জানাবেন।", date: "২০২৬-০৫-৩১", read: false }
];

// Combine all into Single DB
interface DatabaseSchema {
  settings: SystemSettings;
  teachers: Teacher[];
  students: Student[];
  books: LibraryBook[];
  notices: Notice[];
  gallery: GalleryItem[];
  admissions: AdmissionForm[];
  results: ExamResult[];
  attendance: AttendanceRecord[];
  payments: typeof INITIAL_PAYMENTS;
  contacts: ContactMessage[];
}

const INITIAL_DB: DatabaseSchema = {
  settings: DEFAULT_SETTINGS,
  teachers: INITIAL_TEACHERS,
  students: INITIAL_STUDENTS,
  books: INITIAL_BOOKS,
  notices: INITIAL_NOTICES,
  gallery: INITIAL_GALLERY,
  admissions: INITIAL_ADMISSIONS,
  results: INITIAL_EXAM_RESULTS,
  attendance: INITIAL_ATTENDANCE,
  payments: INITIAL_PAYMENTS,
  contacts: INITIAL_CONTACT_MESSAGES
};

// Helper functions to read/write DB
function readDB(): DatabaseSchema {
  try {
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, "utf-8");
      return JSON.parse(raw);
    }
  } catch (err) {
    console.error("Error reading database file, resetting to initial", err);
  }
  
  // Write default db if not existing
  writeDB(INITIAL_DB);
  return INITIAL_DB;
}

function writeDB(db: DatabaseSchema) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), "utf-8");
  } catch (err) {
    console.error("Error writing to database", err);
  }
}

// REST API Router & Services

// Standard authentication bypass rule: admin if khalilenurmadrasha65@gmail.com
app.post("/api/auth/login", (req, res) => {
  const { email, password, phone, type } = req.body;
  const db = readDB();

  // Rules based login
  if (type === "phone") {
    // Lookup by phone
    const student = db.students.find(s => s.guardianPhone === phone);
    const teacher = db.teachers.find(t => t.phone === phone);
    
    if (phone === "01812345678") {
      return res.json({
        success: true,
        user: {
          id: "admin_1",
          email: "khalilenurmadrasha65@gmail.com",
          name: "মাওলানা হাফেজ মোঃ ছিদ্দিকুল্লাহ (Admin/Principal)",
          phone: "01812345678",
          role: "admin",
          createdAt: "2026-06-01T09:00:00Z"
        }
      });
    }

    if (phone === "01823456781") { // also teacher (siddikullah)
      return res.json({
        success: true,
        user: {
          id: "t_1",
          email: "hfmdsiddikramu1@gmail.com",
          name: "মাওলানা হাফেজ মোঃ ছিদ্দিকুল্লাহ",
          phone: "01823456781",
          role: "teacher"
        }
      });
    }

    if (student) {
      return res.json({
        success: true,
        user: {
          id: student.id,
          email: `${student.id}@madrasha.com`,
          name: student.guardianName + " (Guardian of " + student.name + ")",
          phone: student.guardianPhone,
          role: "guardian",
          studentDetails: student
        }
      });
    }

    if (teacher) {
      return res.json({
        success: true,
        user: {
          id: teacher.id,
          email: teacher.email,
          name: teacher.name + " (Teacher)",
          phone: teacher.phone,
          role: "teacher"
        }
      });
    }

    // Default mock success student
    return res.json({
      success: true,
      user: {
        id: "s_default",
        email: "student@madrasha.com",
        name: "অভিভাবক (সম্মানিত অভিভাবক)",
        phone: phone,
        role: "guardian"
      }
    });
  }

  // Email / Generic login
  if (!email) {
    return res.status(400).json({ error: "Email or Phone is required" });
  }

  const normalizedEmail = email.toLowerCase().trim();
  
  if (normalizedEmail === "khalilenurmadrasha65@gmail.com") {
    return res.json({
      success: true,
      user: {
        id: "admin_1",
        email: normalizedEmail,
        name: "মাওলানা হাফেজ মোঃ ছিদ্দিকুল্লাহ (Admin)",
        role: "admin",
        createdAt: "2026-06-01T09:00:00Z"
      }
    });
  }

  if (normalizedEmail === "hfmdsiddikramu1@gmail.com") {
    return res.json({
      success: true,
      user: {
        id: "t_1",
        email: normalizedEmail,
        name: "মাওলানা হাফেজ মোঃ ছিদ্দিকুল্লাহ (Principal)",
        role: "teacher"
      }
    });
  }

  // Teacher lookup
  const teacher = db.teachers.find(t => t.email.toLowerCase() === normalizedEmail);
  if (teacher) {
    return res.json({
      success: true,
      user: {
        id: teacher.id,
        email: teacher.email,
        name: teacher.name,
        role: "teacher"
      }
    });
  }

  // Default student/guardian if other email
  return res.json({
    success: true,
    user: {
      id: "s_100",
      email: normalizedEmail,
      name: "মোহাম্মদ কায়সার (অভিভাবক)",
      role: "guardian"
    }
  });
});

// App settings endpoint
app.get("/api/settings", (req, res) => {
  const db = readDB();
  res.json(db.settings);
});

app.post("/api/settings", (req, res) => {
  const db = readDB();
  db.settings = { ...db.settings, ...req.body };
  writeDB(db);
  res.json({ success: true, settings: db.settings });
});

// Notice management endpoints
app.get("/api/notices", (req, res) => {
  const db = readDB();
  res.json(db.notices);
});

app.post("/api/notices", (req, res) => {
  const db = readDB();
  const newNotice: Notice = {
    id: "n_" + Date.now().toString(),
    title: req.body.title,
    content: req.body.content,
    date: new Date().toISOString().split("T")[0],
    category: req.body.category || "General",
    important: req.body.important || false
  };
  db.notices.unshift(newNotice);
  writeDB(db);
  res.json({ success: true, notice: newNotice });
});

app.delete("/api/notices/:id", (req, res) => {
  const db = readDB();
  db.notices = db.notices.filter(n => n.id !== req.params.id);
  writeDB(db);
  res.json({ success: true });
});

// Student Endpoints
app.get("/api/students", (req, res) => {
  const db = readDB();
  res.json(db.students);
});

app.post("/api/students", (req, res) => {
  const db = readDB();
  const newStudent: Student = {
    id: "s_" + Date.now().toString(),
    ...req.body,
    roll: req.body.roll || (db.students.length + 101).toString()
  };
  db.students.push(newStudent);
  writeDB(db);
  res.json({ success: true, student: newStudent });
});

app.put("/api/students/:id", (req, res) => {
  const db = readDB();
  const idx = db.students.findIndex(s => s.id === req.params.id);
  if (idx !== -1) {
    db.students[idx] = { ...db.students[idx], ...req.body };
    writeDB(db);
    return res.json({ success: true, student: db.students[idx] });
  }
  res.status(404).json({ error: "Student not found" });
});

app.delete("/api/students/:id", (req, res) => {
  const db = readDB();
  db.students = db.students.filter(s => s.id !== req.params.id);
  writeDB(db);
  res.json({ success: true });
});

// CSV Raw Import for Students or Attendance
app.post("/api/students/import-csv", (req, res) => {
  const { csvText } = req.body;
  if (!csvText) return res.status(400).json({ error: "CSV content is empty" });

  const db = readDB();
  const lines = csvText.split("\n");
  let importedCount = 0;

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    // Simple split comma
    const parts = line.split(",");
    if (parts.length >= 4) {
      const name = parts[0]?.trim();
      const roll = parts[1]?.trim();
      const className = parts[2]?.trim();
      const guardianName = parts[3]?.trim();
      const guardianPhone = parts[4]?.trim() || "018XXXXXXXX";
      const address = parts[5]?.trim() || "চকরিয়া, কক্সবাজার";

      if (name && roll && className) {
        db.students.push({
          id: "s_imp_" + Date.now() + "_" + Math.floor(Math.random() * 1000),
          name,
          roll,
          class: className,
          guardianName: guardianName || "অভিভাবক",
          guardianPhone,
          address,
          session: "২০২৬",
          photo: "https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=150",
          gender: "Male"
        });
        importedCount++;
      }
    }
  }

  writeDB(db);
  res.json({ success: true, count: importedCount, students: db.students });
});

// Teacher Endpoints
app.get("/api/teachers", (req, res) => {
  const db = readDB();
  res.json(db.teachers);
});

app.post("/api/teachers", (req, res) => {
  const db = readDB();
  const newTeacher: Teacher = {
    id: "t_" + Date.now().toString(),
    ...req.body
  };
  db.teachers.push(newTeacher);
  writeDB(db);
  res.json({ success: true, teacher: newTeacher });
});

app.put("/api/teachers/:id", (req, res) => {
  const db = readDB();
  const idx = db.teachers.findIndex(t => t.id === req.params.id);
  if (idx !== -1) {
    db.teachers[idx] = { ...db.teachers[idx], ...req.body };
    writeDB(db);
    return res.json({ success: true, teacher: db.teachers[idx] });
  }
  res.status(404).json({ error: "Teacher not found" });
});

app.delete("/api/teachers/:id", (req, res) => {
  const db = readDB();
  db.teachers = db.teachers.filter(t => t.id !== req.params.id);
  writeDB(db);
  res.json({ success: true });
});

// Library Endpoints
app.get("/api/books", (req, res) => {
  const db = readDB();
  res.json(db.books);
});

app.post("/api/books", (req, res) => {
  const db = readDB();
  const newBook: LibraryBook = {
    id: "b_" + Date.now().toString(),
    borrowedQuantity: 0,
    ...req.body
  };
  db.books.push(newBook);
  writeDB(db);
  res.json({ success: true, book: newBook });
});

app.post("/api/books/borrow", (req, res) => {
  const { bookId, userId, userName, userRole } = req.body;
  const db = readDB();
  const book = db.books.find(b => b.id === bookId);
  
  if (book && book.totalQuantity > book.borrowedQuantity) {
    book.borrowedQuantity += 1;
    if (book.borrowedQuantity >= book.totalQuantity) {
      book.availability = false;
    }
    
    // Add transaction history
    if (!db["transactions"]) {
      db["transactions"] = [];
    }

    db["transactions"].push({
      id: "tx_" + Date.now().toString(),
      bookId,
      bookName: book.bookName,
      userId: userId || "usr_1",
      userName: userName || "সাধারন পাঠক",
      userRole: userRole || "guardian",
      borrowDate: new Date().toISOString().split("T")[0],
      status: "Borrowed"
    });

    writeDB(db);
    return res.json({ success: true, book });
  }
  res.status(400).json({ error: "Book is out of stock" });
});

app.post("/api/books/return", (req, res) => {
  const { bookId, txId } = req.body;
  const db = readDB();
  const book = db.books.find(b => b.id === bookId);
  
  if (book && book.borrowedQuantity > 0) {
    book.borrowedQuantity -= 1;
    book.availability = true;
    
    if (db["transactions"]) {
      const tx = db["transactions"].find((t: any) => t.bookId === bookId && t.status === "Borrowed");
      if (tx) {
        tx.status = "Returned";
        tx.returnDate = new Date().toISOString().split("T")[0];
      }
    }
    
    writeDB(db);
    return res.json({ success: true, book });
  }
  res.status(400).json({ error: "Book count error" });
});

app.delete("/api/books/:id", (req, res) => {
  const db = readDB();
  db.books = db.books.filter(b => b.id !== req.params.id);
  writeDB(db);
  res.json({ success: true });
});

// Admission Forms & Online Admission & Gated Payments
app.get("/api/admissions", (req, res) => {
  const db = readDB();
  res.json(db.admissions);
});

app.post("/api/admissions/register", (req, res) => {
  const db = readDB();
  const admission: AdmissionForm = {
    id: "adm_" + Date.now().toString(),
    ...req.body,
    paymentStatus: "Verified", // Pre-verified after submitting with payment gateway details
    submissionDate: new Date().toISOString().split("T")[0]
  };

  db.admissions.unshift(admission);

  // Auto-create a student from admission
  const newStudent: Student = {
    id: "s_" + Date.now().toString(),
    name: admission.studentName,
    photo: admission.photoUrl || "https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=150",
    roll: (db.students.length + 101).toString(),
    class: admission.class,
    session: "২০২৬",
    guardianName: admission.fatherName,
    guardianPhone: admission.phone,
    address: admission.address,
    gender: admission.gender,
    dob: admission.dob
  };
  db.students.push(newStudent);

  // Add Payment History log
  db.payments.unshift({
    id: "p_" + Date.now().toString(),
    studentName: admission.studentName,
    class: admission.class,
    method: admission.paymentMethod,
    txid: admission.transactionId,
    amount: admission.amount,
    type: "Admission Fee",
    date: new Date().toISOString().split("T")[0],
    status: "Verified"
  });

  writeDB(db);
  res.json({ success: true, admission, student: newStudent });
});

app.put("/api/admissions/:id", (req, res) => {
  const db = readDB();
  const idx = db.admissions.findIndex(a => a.id === req.params.id);
  if (idx !== -1) {
    db.admissions[idx] = { ...db.admissions[idx], ...req.body };
    writeDB(db);
    return res.json({ success: true, admission: db.admissions[idx] });
  }
  res.status(404).json({ error: "Admission form not found" });
});

// Daily roll call / Attendance Management Endpoints
app.get("/api/attendance", (req, res) => {
  const db = readDB();
  res.json(db.attendance);
});

app.post("/api/attendance/bulk", (req, res) => {
  const records = req.body.records; // Array of AttendanceRecord
  if (!records || !Array.isArray(records)) {
    return res.status(400).json({ error: "No records submitted" });
  }

  const db = readDB();
  const dateStr = new Date().toISOString().split("T")[0];
  
  // Exclude current date duplicate entries first
  db.attendance = db.attendance.filter(a => a.date !== dateStr);

  records.forEach((rec: any) => {
    db.attendance.push({
      id: "att_" + Date.now() + "_" + Math.floor(Math.random() * 100),
      studentId: rec.studentId,
      studentName: rec.studentName,
      roll: rec.roll,
      class: rec.class,
      date: dateStr,
      status: rec.status || "Present"
    });
  });

  writeDB(db);
  res.json({ success: true, recordsCount: records.length });
});

// Result sheets & report cards Endpoints
app.get("/api/results", (req, res) => {
  const db = readDB();
  res.json(db.results);
});

app.post("/api/results", (req, res) => {
  const db = readDB();
  const newResult: ExamResult = {
    id: "r_" + Date.now().toString(),
    ...req.body,
    createdAt: new Date().toISOString().split("T")[0]
  };
  db.results.unshift(newResult);
  writeDB(db);
  res.json({ success: true, result: newResult });
});

app.delete("/api/results/:id", (req, res) => {
  const db = readDB();
  db.results = db.results.filter(r => r.id !== req.params.id);
  writeDB(db);
  res.json({ success: true });
});

// Payments & Revenues statistics
app.get("/api/payments", (req, res) => {
  const db = readDB();
  res.json(db.payments);
});

app.post("/api/payments", (req, res) => {
  const db = readDB();
  const { studentName, class: className, method, txid, amount, type } = req.body;
  const newPay = {
    id: "p_" + Date.now().toString(),
    studentName: studentName || "অজ্ঞাত ছাত্র",
    class: className || "Play",
    method: method || "bKash",
    txid: txid || "TXID_MOCK",
    amount: Number(amount || 0),
    type: type || "Tuition Fee",
    date: new Date().toISOString().split("T")[0],
    status: "Verified"
  };
  db.payments.unshift(newPay);
  writeDB(db);
  res.json({ success: true, payment: newPay });
});

// Contacts Inbox 
app.get("/api/contacts", (req, res) => {
  const db = readDB();
  res.json(db.contacts);
});

app.post("/api/contacts", (req, res) => {
  const db = readDB();
  const newMsg: ContactMessage = {
    id: "c_" + Date.now().toString(),
    name: req.body.name,
    phone: req.body.phone,
    message: req.body.message,
    date: new Date().toISOString().split("T")[0],
    read: false
  };
  db.contacts.unshift(newMsg);
  writeDB(db);
  res.json({ success: true, message: newMsg });
});

app.post("/api/contacts/read/:id", (req, res) => {
  const db = readDB();
  const msg = db.contacts.find(c => c.id === req.params.id);
  if (msg) {
    msg.read = true;
    writeDB(db);
  }
  res.json({ success: true });
});

// Photos / Gallery API
app.get("/api/gallery", (req, res) => {
  const db = readDB();
  res.json(db.gallery);
});

app.post("/api/gallery", (req, res) => {
  const db = readDB();
  const newItem: GalleryItem = {
    id: "g_" + Date.now().toString(),
    url: req.body.url || "https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&q=80&w=600",
    category: req.body.category || "Campus",
    title: req.body.title || "গ্যালারী ছবি",
    date: new Date().toISOString().split("T")[0]
  };
  db.gallery.unshift(newItem);
  writeDB(db);
  res.json({ success: true, item: newItem });
});

app.delete("/api/gallery/:id", (req, res) => {
  const db = readDB();
  db.gallery = db.gallery.filter(g => g.id !== req.params.id);
  writeDB(db);
  res.json({ success: true });
});

// Integration support with MySQL DB schema files and static installation setup
app.get("/api/downloads/schema", (req, res) => {
  const schemaPath = path.join(process.cwd(), "schema.sql");
  if (fs.existsSync(schemaPath)) {
    res.setHeader('Content-Type', 'text/plain');
    res.setHeader('Content-Disposition', 'attachment; filename=madrasha_schema.sql');
    return res.sendFile(schemaPath);
  }
  res.status(404).send("Schema SQL files not generated yet.");
});

// Vite & Static file configurations
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[MADRASHA APPMAN] Server running on http://localhost:${PORT}`);
  });
}

startServer();
